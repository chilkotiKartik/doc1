# Backend Architecture

Status: implemented. This describes the layout as it actually is.

## Layout

```
backend/
  main.py                  # FastAPI app + CORS + router registration - the entrypoint, at top level
  db.py                     # engine/session setup
  config/
    settings.py
  routers/                 # HTTP layer only: request/response wiring, no business logic
    deps.py                # get_session, get_current_user, require_role
    auth.py                # /api/auth/* - signup/login/me/logout, any role
    users.py               # /api/users/* - admin-only user management
  schemas/                 # Pydantic request/response DTOs, separate from routing
    auth.py
    user.py
  services/                # business logic: orchestrates models + utils, no HTTP concerns
    auth_service.py
    user_service.py
  models/                  # SQLAlchemy ORM models only
    base.py
    user.py
    revoked_token.py
  utils/                   # generic, stateless helpers with no DB/business knowledge
    security.py            # hash_password/verify_password
  tests/                   # flat, one file per layer being tested
    conftest.py            # shared `client`/`db_session` fixtures (FastAPI TestClient +
                            # direct DB access, backed by one shared in-memory SQLite engine)
    test_security.py       # tests utils/
    test_auth_service.py   # tests services/auth_service.py
    test_user_service.py   # tests services/user_service.py
    test_api_auth.py       # tests routers/auth.py end-to-end
    test_api_users.py      # tests routers/users.py end-to-end
  manage.py
  requirements.txt
  Dockerfile
```

This replaced an earlier `core/`+`api/` layout where `core.models`/`core.services`
buried imports behind a namespace nothing outside the backend used, `main.py`
sat under `api/` instead of at the entrypoint, and `security.py` (a stateless
utility) lived inside `services/` alongside logic that actually orchestrates
the domain (`auth_service.py`).

## No audience split — one API, roles do the work

There are two frontends (`frontend/internal-app`, `frontend/customer-website`),
but as of 2026-09-05 **there is no separate `/api/internal/*` vs
`/api/customer/*` API split** - both call the exact same `/api/auth/*`
endpoints. This replaces an earlier design (separate prefixes, each surface
rejecting the other's accounts at login) that turned out to be unnecessary
complexity: with one shared `User` table and role-based signup already in
place, an "audience" isn't a real thing at the API level - it's just a
`role` value on the same row, and restriction belongs on the specific
endpoints that need it (`require_role`), not on which URL prefix you used to
log in.

- `models/user.py` — one `User` table serves every role (`rep`, `manager`,
  `finance`, `admin`, `customer`). Same columns, same class, always has
  been - this didn't change.
- `services/auth_service.py` — `signup`/`authenticate`/`create_access_token`/
  `resolve_user_from_token` are role-agnostic; they take or return whatever
  role the user has, with no notion of "internal" or "customer" baked in.
  Unchanged by this.
- `schemas/auth.py` — `SignupRequest`, `LoginRequest`, `UserResponse`,
  `AuthResponse`: one shape each, used by the one shared router. There used
  to be two signup schemas (an internal one with a `role` field, a customer
  one without); once internal signup stopped accepting a role too, they
  were identical, so keeping two names for one shape stopped making sense.
- `routers/auth.py` — one router, `/api/auth/*`, no role checks at all.
  `login` never rejects based on role - it returns a token reflecting
  whatever role the account actually has. `routers/deps.py`'s
  `get_current_user`/`require_role` are what gate access to specific
  endpoints that need it (see `routers/users.py`, admin-only), not login.

If customer-only data ever appears (a billing address, a company name -
nothing a staff user has), that's the signal to split `models`/`schemas` by
audience, not before - and even then, the API surface itself doesn't need
to split just because the data does.

## Signup and role assignment

Decided 2026-09-05, **superseding an earlier approach** (an `is_approved`
flag + a pending/approve workflow for internal signups - removed entirely,
not just deprecated, since it would have become permanently-unreachable
dead code under the model below).

**Every signup, through either surface, always creates a `Role.CUSTOMER`
account, immediately usable.** Nobody can self-declare a privileged role at
signup - not rep, not manager, not admin. An admin changes a specific
user's role afterward via a general-purpose endpoint, and that role change
*is* the approval - there's no separate pending/approve step, because
nothing privileged was ever self-requested in the first place.

- `services/auth_service.signup()` takes no `role` parameter - every call
  creates `Role.CUSTOMER`. `schemas/auth.py`'s `SignupRequest` has no
  `role` field.
- `routers/auth.py`'s `login` does not check role at all (this used to
  reject a `Role.CUSTOMER` account when internal/customer were separate
  endpoints - removed once they were unified, see the section above -
  a customer who hasn't been promoted gets a perfectly normal `200` login,
  just with `role: "customer"` in the response; restriction happens at
  `require_role`-gated endpoints, not at login).
- `services/user_service.py` (distinct from `auth_service.py`, which stays
  scoped to login/signup/tokens - this is admin user-management, a
  different concern) - `list_all_users()` and `change_user_role()`, exposed
  as `GET /api/users` and `PATCH /api/users/{id}/role` (`routers/users.py`),
  both gated by `require_role(Role.ADMIN)`. `change_user_role` accepts any
  role including `customer` - it's a demotion path too, not just promotion.
- **Bootstrap problem:** if nobody can self-provision a privileged role,
  where does the first admin come from? `manage.py`'s `seed_users()`
  creates its `DEMO_USERS` with their real role directly (bypassing signup
  entirely) - that's the only path to a first admin.

## Rule of thumb for where new code goes

Stated explicitly so future additions land in the right place without
re-litigating this each time:

- **`models/`** — what the data *is* (columns, relationships). No logic beyond
  what SQLAlchemy needs.
- **`utils/`** — generic functions with no opinion about DealFlow360's domain.
  Could be copy-pasted into an unrelated project and still make sense.
  (password hashing, generic string/date helpers, etc.)
- **`services/`** — what the app *does*: business rules, orchestration across
  models, calls into `utils/`. This is where "authenticate a user," "compute
  a risk score," "route an approval" live. No FastAPI/HTTP imports here -
  a service function should be fully testable without spinning up the app
  (see `tests/test_auth_service.py`, which never touches `TestClient`).
- **`routers/`** — HTTP only: parses requests via `schemas/`, calls a
  `services/` function, and translates whatever it raises into an HTTP
  status code. No business logic, no direct SQLAlchemy queries beyond what
  a dependency (`deps.py`) provides.
- **`schemas/`** — Pydantic shapes for what crosses the HTTP boundary. Not the
  same as `models/`: a schema can hide/rename/combine model fields for the
  API contract.

Each layer only depends on the ones before it in this list — `routers` can
import `services`, `services` can import `models`/`utils`, but `models`/
`utils` never import `services` or `routers`. That's the actual test for
"did this file end up in the right folder."

### Worked example: `get_current_user`

`routers/deps.py`'s `get_current_user` used to inline the business rule
"given a token, resolve it to a real user, or fail" directly in the FastAPI
dependency - meaning that rule could only be exercised through a full HTTP
request in tests, and couldn't be reused anywhere that isn't a web request.

It's now split across the boundary:

```python
# services/auth_service.py - the business rule, framework-agnostic
def resolve_user_from_token(session, token: str) -> User:
    payload = decode_access_token(token)          # raises InvalidToken
    user = session.get(User, payload.user_id)
    if user is None:
        raise InvalidToken("Token no longer matches a known user")
    return user

# routers/deps.py - HTTP translation only
def get_current_user(credentials=..., session=...) -> User:
    if credentials is None:
        raise HTTPException(401, "Missing bearer token")
    try:
        return auth_service.resolve_user_from_token(session, credentials.credentials)
    except auth_service.InvalidToken as exc:
        raise HTTPException(401, str(exc)) from exc
```

`resolve_user_from_token` is directly unit-tested in `tests/test_auth_service.py`
(valid token, garbage token, token for a since-deleted user) with no FastAPI
involved at all; `test_api_auth.py` only needs to check the HTTP-level 401
translation, not re-verify the resolution logic.

## Logout (token revocation)

Decided 2026-09-05: JWT was chosen over a DB-backed session specifically to
avoid server-side state per request (see the conversation that led to
choosing JWT). Real early revocation is fundamentally in tension with that -
there's no way to invalidate a signed token before its own expiry without
checking *something* server-side. Kept deliberately minimal rather than
reintroducing a full session table:

- `create_access_token` adds a `jti` (JWT ID, a random UUID) claim to every
  token, in addition to `sub`/`role`/`exp`.
- `models/revoked_token.py` - `RevokedToken(jti, expires_at)`, one row per
  logged-out token. `expires_at` is copied from the token's own expiry so a
  row is safe to delete once that time passes (no cleanup job exists yet -
  the table just grows slowly until one is added).
- `resolve_user_from_token` (used by every authenticated request via
  `get_current_user`) now does one extra indexed lookup: is this jti
  revoked? If so, `InvalidToken`, same as a bad signature or expired token.
- `POST /api/auth/logout` - authenticated (must be a currently-valid,
  non-revoked token to call logout at all, reusing `get_current_user`'s
  existing checks), revokes only the token used to call it. Not "log out
  everywhere" - a user with two devices logging out on one doesn't affect
  the other's token.
- `routers/deps.py` gained `get_bearer_token` (extracted out of
  `get_current_user`) so the logout handlers can get the raw token string
  (to decode its jti) via the same dependency `get_current_user` already
  uses - FastAPI dependency caching means it's only actually resolved once
  per request even though both are declared.

This is the smallest amount of server-side state that makes logout actually
revoke something, rather than "logout" only ever meaning "the frontend threw
its copy of the token away" (which was already true for free, and doesn't
protect against a leaked/captured token).
