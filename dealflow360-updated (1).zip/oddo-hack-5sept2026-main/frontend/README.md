# Frontend

Two separate frontends, sharing one backend (`../backend`) through separate API surfaces:

- **`internal-app/`** — Expo (React Native + TypeScript) app for internal people (rep, manager, finance, admin). Uses the `/api/internal/*` endpoints.
- **`customer-website/`** — customer-facing web frontend (not started yet). Will use separate, customer-facing endpoints, not `/api/internal/*`.

See each folder's own README for setup instructions.
