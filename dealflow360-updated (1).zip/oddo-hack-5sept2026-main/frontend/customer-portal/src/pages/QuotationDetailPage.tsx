import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { api, ApiError, type Quotation } from "../api/client";

const STATUS_COPY: Record<string, { label: string; tone: "safe" | "warn" | "danger"; sub: string }> = {
  draft: { label: "Being prepared", tone: "warn", sub: "Your sales contact is still putting this together." },
  pending_manager: {
    label: "Under internal review",
    tone: "warn",
    sub: "Your request is being reviewed on our side — we'll update this shortly.",
  },
  pending_finance: {
    label: "Under internal review",
    tone: "warn",
    sub: "Your request is being reviewed on our side — we'll update this shortly.",
  },
  under_negotiation: {
    label: "Reviewing your request",
    tone: "warn",
    sub: "We just received your proposal and are checking it now.",
  },
  confirmed: {
    label: "Ready for your confirmation",
    tone: "safe",
    sub: "These terms are approved. Confirm below, or propose a different discount first.",
  },
  rejected: { label: "Not available", tone: "danger", sub: "This quotation is no longer active." },
};

export function QuotationDetailPage() {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const quotationId = Number(id);

  const [quotation, setQuotation] = useState<Quotation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [justUpdated, setJustUpdated] = useState(false);

  const [negotiatingLineId, setNegotiatingLineId] = useState<number | null>(null);
  const [proposedDiscount, setProposedDiscount] = useState(0);
  const [note, setNote] = useState("");

  async function refresh() {
    setError(null);
    try {
      const q = await api.getMyQuotation(quotationId);
      setQuotation(q);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load this quotation");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quotationId]);

  function startNegotiating(lineId: number, currentDiscount: number) {
    setNegotiatingLineId(lineId);
    setProposedDiscount(currentDiscount);
  }

  async function sendCounterOffer() {
    if (negotiatingLineId === null) return;
    setBusy(true);
    setError(null);
    try {
      await api.counterOffer(quotationId, negotiatingLineId, proposedDiscount, note || undefined);
      setNegotiatingLineId(null);
      setNote("");
      await refresh();
      setJustUpdated(true);
      setTimeout(() => setJustUpdated(false), 600);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not send your request");
    } finally {
      setBusy(false);
    }
  }

  async function handleConfirm() {
    setBusy(true);
    setError(null);
    try {
      await api.confirm(quotationId);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not confirm this quotation");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="page spinner-text">Loading...</div>;
  if (!quotation) return <div className="page error-banner">{error ?? "Quotation not found."}</div>;

  const canNegotiate = quotation.status === "confirmed" || quotation.status === "under_negotiation";
  const canConfirm = quotation.status === "confirmed" && !quotation.customer_confirmed_at;
  const status = STATUS_COPY[quotation.status] ?? { label: quotation.status, tone: "warn" as const, sub: "" };

  return (
    <div>
      <div className="top-bar">
        <div className="brand">
          Deal<span>Flow360</span>
        </div>
        <div className="top-bar-user">
          <span>{user?.name}</span>
        </div>
      </div>

      <div className="page">
        <div className="page-header fade-in">
          <h1>Quotation #{quotation.id}</h1>
          <p>Prepared for your review.</p>
        </div>

        {error && <div className="error-banner">{error}</div>}

        {quotation.customer_confirmed_at && (
          <div className="info-banner fade-in">
            ✓ You confirmed this quotation on {new Date(quotation.customer_confirmed_at).toLocaleString()}.
          </div>
        )}

        <div className={`score-strip ${status.tone} ${justUpdated ? "success-flash" : ""} fade-in`}>
          <div>
            <div className="status-line">{status.label}</div>
            <div className="status-sub">{status.sub}</div>
          </div>
          <div style={{ fontSize: 22, fontWeight: 800 }}>${quotation.grand_total.toLocaleString()}</div>
        </div>

        <div className="card fade-in">
          <h2 style={{ fontSize: 13, textTransform: "uppercase", letterSpacing: "0.05em", color: "var(--color-text-muted)", margin: "0 0 16px 0" }}>
            Line items
          </h2>

          {quotation.lines.map((line) => (
            <div key={line.id} className={`line-item ${negotiatingLineId === line.id ? "negotiating" : ""}`}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div>
                  <div className="line-item-title">{line.product_name}</div>
                  <div className="line-item-meta">
                    {line.quantity} × ${line.unit_price.toLocaleString()} · {line.discount_pct}% off
                  </div>
                </div>
                <div className="line-item-price">${line.net_total.toLocaleString()}</div>
              </div>

              {canNegotiate && negotiatingLineId !== line.id && (
                <div style={{ marginTop: 10 }}>
                  <button
                    className="btn btn-outline"
                    style={{ padding: "6px 14px", fontSize: 12 }}
                    onClick={() => startNegotiating(line.id, line.discount_pct)}
                  >
                    Propose a different discount
                  </button>
                </div>
              )}

              {negotiatingLineId === line.id && (
                <div className="counter-panel">
                  <div className="form-row">
                    <label>Your proposed discount</label>
                    <div className="slider-row">
                      <input
                        type="range"
                        min={0}
                        max={40}
                        step={0.5}
                        value={proposedDiscount}
                        onChange={(e) => setProposedDiscount(Number(e.target.value))}
                      />
                      <span className="slider-value">{proposedDiscount}%</span>
                    </div>
                  </div>
                  <div className="form-row">
                    <label>Note (optional)</label>
                    <textarea rows={2} value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. need this to fit our budget" />
                  </div>
                  <div style={{ display: "flex", gap: 10 }}>
                    <button className="btn" disabled={busy} onClick={sendCounterOffer}>
                      {busy ? "Sending..." : "Send this request"}
                    </button>
                    <button className="btn btn-outline" disabled={busy} onClick={() => setNegotiatingLineId(null)}>
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}

          <div style={{ textAlign: "right", marginTop: 6, fontSize: 18, fontWeight: 800 }}>
            Total: ${quotation.grand_total.toLocaleString()}
          </div>
        </div>

        {canConfirm && (
          <div className="card fade-in">
            <button className="btn btn-safe btn-block" disabled={busy} onClick={handleConfirm}>
              Confirm quotation
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
