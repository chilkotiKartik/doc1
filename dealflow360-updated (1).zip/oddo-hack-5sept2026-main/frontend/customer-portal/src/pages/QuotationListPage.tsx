import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { api, ApiError, type Quotation } from "../api/client";

const STATUS_LABEL: Record<string, string> = {
  draft: "Being prepared",
  pending_manager: "Under internal review",
  pending_finance: "Under internal review",
  under_negotiation: "Reviewing your request",
  confirmed: "Ready for you to confirm",
  rejected: "Not available",
};

const STATUS_TONE: Record<string, "safe" | "warn" | "danger" | "neutral"> = {
  draft: "neutral",
  pending_manager: "warn",
  pending_finance: "warn",
  under_negotiation: "warn",
  confirmed: "safe",
  rejected: "danger",
};

export function QuotationListPage() {
  const { user, logout } = useAuth();
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .listMyQuotations()
      .then(setQuotations)
      .catch((err) => setError(err instanceof ApiError ? err.message : "Could not load your quotations"))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="top-bar">
        <div className="brand">
          Deal<span>Flow360</span>
        </div>
        <div className="top-bar-user">
          <span>{user?.name}</span>
          <button className="btn btn-outline" onClick={() => logout()} style={{ padding: "6px 14px", fontSize: 12 }}>
            Sign out
          </button>
        </div>
      </div>

      <div className="page">
        <div className="page-header fade-in">
          <h1>Your quotations</h1>
          <p>Review pricing, ask for a different discount, or confirm when you're ready.</p>
        </div>

        {error && <div className="error-banner">{error}</div>}

        <div className="card fade-in">
          {loading ? (
            <p className="spinner-text">Loading...</p>
          ) : quotations.length === 0 ? (
            <div className="empty-state">No quotations have been shared with you yet.</div>
          ) : (
            quotations.map((q) => (
              <Link to={`/quotations/${q.id}`} key={q.id} style={{ textDecoration: "none", color: "inherit" }}>
                <div className="quote-list-item">
                  <div>
                    <div style={{ fontWeight: 700 }}>Quotation #{q.id}</div>
                    <div style={{ fontSize: 13, color: "var(--color-text-muted)" }}>
                      ${q.grand_total.toLocaleString()}
                    </div>
                  </div>
                  <span className={`badge badge-${STATUS_TONE[q.status] ?? "neutral"}`}>
                    {STATUS_LABEL[q.status] ?? q.status}
                  </span>
                </div>
              </Link>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
