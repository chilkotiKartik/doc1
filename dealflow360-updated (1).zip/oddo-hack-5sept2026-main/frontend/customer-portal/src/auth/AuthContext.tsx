import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, setAuthToken, type UserResponse } from "../api/client";

interface AuthContextValue {
  user: UserResponse | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const STORAGE_KEY = "dealflow360_portal_token";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserResponse | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) {
      setLoading(false);
      return;
    }
    setAuthToken(saved);
    api
      .me()
      .then(setUser)
      .catch(() => {
        localStorage.removeItem(STORAGE_KEY);
        setAuthToken(null);
      })
      .finally(() => setLoading(false));
  }, []);

  async function login(email: string, password: string) {
    const res = await api.login(email, password);
    if (res.user.role !== "customer") {
      // A staff account trying to log into the customer portal - reject
      // client-side too, even though every portal API call would also
      // 403 for a non-customer role. Fail fast with a clear message
      // instead of letting them land on an empty "no quotations" screen.
      throw new Error("This portal is for customer accounts only.");
    }
    localStorage.setItem(STORAGE_KEY, res.token);
    setAuthToken(res.token);
    setUser(res.user);
  }

  async function logout() {
    try {
      await api.logout();
    } catch {
      // token may already be invalid - clearing local state is what matters
    }
    localStorage.removeItem(STORAGE_KEY);
    setAuthToken(null);
    setUser(null);
  }

  return <AuthContext.Provider value={{ user, loading, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
