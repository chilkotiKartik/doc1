// Deliberately narrower than the internal app's client - a customer login
// can only ever call /api/auth/* and /api/portal/*. There is no code path
// here that could even attempt to hit /api/quotations/* or /api/catalog/*
// - those endpoints exist on the same backend but are a completely
// separate, staff-only surface that this app doesn't know about.

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export interface UserResponse {
  id: number;
  name: string;
  email: string;
  role: string;
}

export interface AuthResponse {
  token: string;
  user: UserResponse;
}

export type QuotationStatus =
  | "draft"
  | "pending_manager"
  | "pending_finance"
  | "confirmed"
  | "rejected"
  | "under_negotiation";

export type Routing = "none" | "manager" | "manager_finance";

export interface QuotationLine {
  id: number;
  product_id: number;
  product_name: string;
  category_name: string;
  quantity: number;
  unit_price: number;
  discount_pct: number;
  net_total: number;
  margin_pct: number;
  overage_pts: number;
  ceiling_pct: number;
  risk_contribution: number;
  hard_flag: boolean;
}

export interface Quotation {
  id: number;
  customer_id: number;
  customer_name: string;
  rep_id: number;
  status: QuotationStatus;
  blended_risk_score: number;
  hard_flag: boolean;
  routing: Routing;
  grand_total: number;
  customer_confirmed_at: string | null;
  lines: QuotationLine[];
}

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

let authToken: string | null = null;

export function setAuthToken(token: string | null) {
  authToken = token;
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {};
  if (authToken) headers["Authorization"] = `Bearer ${authToken}`;
  if (body !== undefined) headers["Content-Type"] = "application/json";

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return undefined as T;
  const text = await res.text();
  const data = text ? JSON.parse(text) : undefined;

  if (!res.ok) {
    const message = (data && (data.detail ?? JSON.stringify(data))) || res.statusText;
    throw new ApiError(res.status, String(message));
  }
  return data as T;
}

export const api = {
  signup: (name: string, email: string, password: string) =>
    request<AuthResponse>("POST", "/api/auth/signup", { name, email, password }),
  login: (email: string, password: string) => request<AuthResponse>("POST", "/api/auth/login", { email, password }),
  me: () => request<UserResponse>("GET", "/api/auth/me"),
  logout: () => request<void>("POST", "/api/auth/logout"),

  listMyQuotations: () => request<Quotation[]>("GET", "/api/portal/quotations"),
  getMyQuotation: (id: number) => request<Quotation>("GET", `/api/portal/quotations/${id}`),
  counterOffer: (id: number, lineId: number, discountPct: number, note?: string) =>
    request<Quotation>("POST", `/api/portal/quotations/${id}/counter`, {
      line_id: lineId,
      discount_pct: discountPct,
      note,
    }),
  confirm: (id: number) => request<Quotation>("POST", `/api/portal/quotations/${id}/confirm`),
};

export { ApiError };
