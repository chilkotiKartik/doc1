import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth/AuthContext";
import { LoginPage } from "./pages/LoginPage";
import { QuotationListPage } from "./pages/QuotationListPage";
import { QuotationDetailPage } from "./pages/QuotationDetailPage";

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="page spinner-text">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        path="/"
        element={
          <RequireAuth>
            <QuotationListPage />
          </RequireAuth>
        }
      />
      <Route
        path="/quotations/:id"
        element={
          <RequireAuth>
            <QuotationDetailPage />
          </RequireAuth>
        }
      />
    </Routes>
  );
}
