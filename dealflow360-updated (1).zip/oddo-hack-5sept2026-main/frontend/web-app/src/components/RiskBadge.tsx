import type { Routing } from "../api/client";

export function routingLabel(routing: Routing): string {
  switch (routing) {
    case "none":
      return "No approval needed";
    case "manager":
      return "Manager approval";
    case "manager_finance":
      return "Manager + Finance";
  }
}

export function routingTone(routing: Routing): "safe" | "warn" | "danger" {
  switch (routing) {
    case "none":
      return "safe";
    case "manager":
      return "warn";
    case "manager_finance":
      return "danger";
  }
}

export function RiskBadge({ routing }: { routing: Routing }) {
  const tone = routingTone(routing);
  return <span className={`badge badge-${tone}`}>{routingLabel(routing)}</span>;
}

export function StatusBadge({ status }: { status: string }) {
  const toneByStatus: Record<string, "safe" | "warn" | "danger" | "neutral"> = {
    draft: "neutral",
    pending_manager: "warn",
    pending_finance: "warn",
    confirmed: "safe",
    rejected: "danger",
  };
  const tone = toneByStatus[status] ?? "neutral";
  const label = status.replace(/_/g, " ");
  return <span className={`badge badge-${tone}`}>{label}</span>;
}
