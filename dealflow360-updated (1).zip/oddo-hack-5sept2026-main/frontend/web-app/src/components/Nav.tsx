import { NavLink } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export function Nav() {
  const { user, logout } = useAuth();
  if (!user) return null;

  const canApprove = user.role === "manager" || user.role === "finance" || user.role === "admin";
  const canBuildQuotes = user.role === "rep" || user.role === "admin";
  const canSeeDealHealth = user.role === "manager" || user.role === "admin";

  return (
    <nav className="nav">
      <div className="nav-brand">
        Deal<span>Flow360</span>
      </div>
      <div className="nav-links">
        {canBuildQuotes && (
          <NavLink to="/quotations" className={({ isActive }) => (isActive ? "active" : "")}>
            Quotations
          </NavLink>
        )}
        {canApprove && (
          <NavLink to="/approvals" className={({ isActive }) => (isActive ? "active" : "")}>
            Approvals
          </NavLink>
        )}
        {canSeeDealHealth && (
          <NavLink to="/deal-health" className={({ isActive }) => (isActive ? "active" : "")}>
            Deal Health
          </NavLink>
        )}
      </div>
      <div className="nav-user">
        <span>{user.name}</span>
        <span className="role-pill">{user.role}</span>
        <button className="btn btn-outline btn-sm" onClick={() => logout()}>
          Log out
        </button>
      </div>
    </nav>
  );
}
