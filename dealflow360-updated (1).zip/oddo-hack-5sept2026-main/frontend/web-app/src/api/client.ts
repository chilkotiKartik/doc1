// Thin, typed wrapper around the DealFlow360 backend. One file that knows
// the API's shapes, so pages never construct fetch() calls by hand and
// every type here matches a real backend/schemas/*.py class - not
// speculative, copied from the actual Pydantic response models.

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export type Role = "rep" | "manager" | "finance" | "admin" | "customer";

export interface UserResponse {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface AuthResponse {
  token: string;
  user: UserResponse;
}

export interface ProductCategory {
  id: number;
  name: string;
}

export interface Product {
  id: number;
  name: string;
  category_id: number;
  unit_cost: number;
  list_price: number;
  is_subscription: boolean;
}

export interface DiscountTier {
  id: number;
  name: string;
  overall_ceiling_pct: number;
}

export interface CategoryCeiling {
  id: number;
  tier_id: number;
  category_id: number;
  max_discount_pct: number;
  margin_weight: number;
}

export interface Customer {
  id: number;
  name: string;
  tier_id: number;
  tier_name: string;
}

export type QuotationStatus =
  | "draft"
  | "pending_manager"
  | "pending_finance"
  | "confirmed"
  | "rejected";

export type Routing = "none" | "manager" | "manager_finance";

export interface QuotationLine {
  id: number;
  product_id: number;
  product_name: string;
  category_name: string;
  quantity: number;
  unit_price: number;
  discount_pct: number;
  net_total: number;
  margin_pct: number;
  overage_pts: number;
  ceiling_pct: number;
  risk_contribution: number;
  hard_flag: boolean;
}

export interface Quotation {
  id: number;
  customer_id: number;
  customer_name: string;
  rep_id: number;
  status: QuotationStatus;
  blended_risk_score: number;
  hard_flag: boolean;
  routing: Routing;
  grand_total: number;
  lines: QuotationLine[];
}

export type ApprovalLevel = "manager" | "finance";
export type ApprovalStatus = "pending" | "approved" | "rejected" | "returned";

export interface ApprovalStep {
  id: number;
  quotation_id: number;
  level: ApprovalLevel;
  status: ApprovalStatus;
  actor_id: number | null;
  reason: string | null;
  created_at: string;
  acted_at: string | null;
}

export interface AuditLogEntry {
  id: number;
  quotation_id: number;
  user_id: number | null;
  action: string;
  details: string | null;
  created_at: string;
}

export interface DiscountAnomaly {
  quotation_id: number;
  rep_id: number;
  rep_name: string;
  customer_name: string;
  this_deal_avg_discount: number;
  rep_mean_discount: number;
  rep_stdev_discount: number;
  z_score: number;
  sample_size: number;
}

export interface StalledDeal {
  quotation_id: number;
  rep_id: number;
  rep_name: string;
  customer_name: string;
  status: string;
  days_inactive: number;
  grand_total: number;
}

export interface CrossSellSuggestion {
  product_id: number;
  product_name: string;
  category_name: string;
  list_price: number;
  margin_pct: number;
  lift: number;
  confidence: number;
  co_occurrence_count: number;
  margin_delta_if_added: number;
}

export interface Warehouse {
  id: number;
  name: string;
  shipping_weight: number;
}

export interface LineAllocation {
  quotation_line_id: number;
  product_id: number;
  product_name: string;
  warehouse_id: number | null;
  warehouse_name: string;
  quantity: number;
  is_backorder: boolean;
}

export interface SplitPlan {
  lines: LineAllocation[];
  shipment_count: number;
  estimated_shipping_cost: number;
  total_backordered_units: number;
}

class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

let authToken: string | null = null;

export function setAuthToken(token: string | null) {
  authToken = token;
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {};
  if (authToken) headers["Authorization"] = `Bearer ${authToken}`;
  if (body !== undefined) headers["Content-Type"] = "application/json";

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return undefined as T;

  const text = await res.text();
  const data = text ? JSON.parse(text) : undefined;

  if (!res.ok) {
    const message = (data && (data.detail ?? JSON.stringify(data))) || res.statusText;
    throw new ApiError(res.status, String(message));
  }
  return data as T;
}

export const api = {
  // auth
  signup: (name: string, email: string, password: string) =>
    request<AuthResponse>("POST", "/api/auth/signup", { name, email, password }),
  login: (email: string, password: string) =>
    request<AuthResponse>("POST", "/api/auth/login", { email, password }),
  me: () => request<UserResponse>("GET", "/api/auth/me"),
  logout: () => request<void>("POST", "/api/auth/logout"),

  // catalog
  listCategories: () => request<ProductCategory[]>("GET", "/api/catalog/categories"),
  listProducts: () => request<Product[]>("GET", "/api/catalog/products"),
  createCategory: (name: string) => request<ProductCategory>("POST", "/api/catalog/categories", { name }),
  createProduct: (payload: Omit<Product, "id">) => request<Product>("POST", "/api/catalog/products", payload),

  // governance
  listTiers: () => request<DiscountTier[]>("GET", "/api/governance/tiers"),
  createTier: (name: string, overall_ceiling_pct: number) =>
    request<DiscountTier>("POST", "/api/governance/tiers", { name, overall_ceiling_pct }),
  listCeilings: (tierId?: number) =>
    request<CategoryCeiling[]>("GET", `/api/governance/ceilings${tierId ? `?tier_id=${tierId}` : ""}`),
  setCeiling: (payload: { tier_id: number; category_id: number; max_discount_pct: number; margin_weight?: number }) =>
    request<CategoryCeiling>("PUT", "/api/governance/ceilings", payload),

  // customers
  listCustomers: () => request<Customer[]>("GET", "/api/customers"),
  createCustomer: (name: string, tier_id: number) => request<Customer>("POST", "/api/customers", { name, tier_id }),

  // quotations
  createQuotation: (customer_id: number) => request<Quotation>("POST", "/api/quotations", { customer_id }),
  getQuotation: (id: number) => request<Quotation>("GET", `/api/quotations/${id}`),
  listQuotations: (filter?: "mine" | "pending_manager" | "pending_finance") =>
    request<Quotation[]>("GET", `/api/quotations${filter ? `?${filter}=true` : ""}`),
  addLine: (quotationId: number, product_id: number, quantity: number, discount_pct: number) =>
    request<Quotation>("POST", `/api/quotations/${quotationId}/lines`, { product_id, quantity, discount_pct }),
  updateLine: (quotationId: number, lineId: number, payload: { quantity?: number; discount_pct?: number }) =>
    request<Quotation>("PATCH", `/api/quotations/${quotationId}/lines/${lineId}`, payload),
  removeLine: (quotationId: number, lineId: number) =>
    request<Quotation>("DELETE", `/api/quotations/${quotationId}/lines/${lineId}`),
  submitForApproval: (quotationId: number) => request<Quotation>("POST", `/api/quotations/${quotationId}/submit`),
  decideApproval: (quotationId: number, level: ApprovalLevel, decision: ApprovalStatus, reason?: string) =>
    request<Quotation>("POST", `/api/quotations/${quotationId}/approvals/${level}`, { decision, reason }),
  listApprovals: (quotationId: number) => request<ApprovalStep[]>("GET", `/api/quotations/${quotationId}/approvals`),
  listAuditLog: (quotationId: number) => request<AuditLogEntry[]>("GET", `/api/quotations/${quotationId}/audit-log`),

  // deal health
  listAnomalies: () => request<DiscountAnomaly[]>("GET", "/api/deal-health/anomalies"),
  listStalled: () => request<StalledDeal[]>("GET", "/api/deal-health/stalled"),

  // cross-sell
  getCrossSell: (quotationId: number) =>
    request<CrossSellSuggestion[]>("GET", `/api/quotations/${quotationId}/cross-sell`),

  // warehouses / fulfillment
  listWarehouses: () => request<Warehouse[]>("GET", "/api/warehouses"),
  getSplitSuggestion: (quotationId: number) => request<SplitPlan>("GET", `/api/quotations/${quotationId}/split`),
  acceptSplit: (quotationId: number) => request<SplitPlan>("POST", `/api/quotations/${quotationId}/split/accept`),
};

export { ApiError };
