import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, ApiError, type Customer, type Quotation } from "../api/client";
import { RiskBadge, StatusBadge } from "../components/RiskBadge";

export function QuotationListPage() {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | "">("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  async function refresh() {
    setLoading(true);
    setError(null);
    try {
      const [qs, cs] = await Promise.all([api.listQuotations("mine"), api.listCustomers()]);
      setQuotations(qs);
      setCustomers(cs);
      if (cs.length > 0 && selectedCustomerId === "") setSelectedCustomerId(cs[0].id);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load quotations");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleCreate() {
    if (selectedCustomerId === "") return;
    setCreating(true);
    setError(null);
    try {
      const quotation = await api.createQuotation(selectedCustomerId);
      window.location.href = `/quotations/${quotation.id}`;
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not create quotation");
      setCreating(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Quotations</h1>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="card">
        <h2>New quotation</h2>
        <div className="inline-form">
          <div className="form-row">
            <label htmlFor="customer">Customer</label>
            <select
              id="customer"
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(Number(e.target.value))}
            >
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.tier_name})
                </option>
              ))}
            </select>
          </div>
          <button className="btn" onClick={handleCreate} disabled={creating || selectedCustomerId === ""}>
            {creating ? "Creating..." : "Build quotation"}
          </button>
        </div>
      </div>

      <div className="card">
        <h2>Your quotations</h2>
        {loading ? (
          <p className="spinner-text">Loading...</p>
        ) : quotations.length === 0 ? (
          <div className="empty-state">No quotations yet - create one above.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Customer</th>
                <th>Total</th>
                <th>Risk score</th>
                <th>Routing</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {quotations.map((q) => (
                <tr key={q.id}>
                  <td>{q.customer_name}</td>
                  <td>${q.grand_total.toLocaleString()}</td>
                  <td>{q.blended_risk_score}</td>
                  <td>
                    <RiskBadge routing={q.routing} />
                  </td>
                  <td>
                    <StatusBadge status={q.status} />
                  </td>
                  <td>
                    <Link to={`/quotations/${q.id}`}>Open →</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
