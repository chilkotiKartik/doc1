import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  api,
  ApiError,
  type AuditLogEntry,
  type CrossSellSuggestion,
  type Product,
  type Quotation,
  type SplitPlan,
} from "../api/client";
import { RiskBadge, StatusBadge, routingTone } from "../components/RiskBadge";

export function QuotationBuilderPage() {
  const { id } = useParams<{ id: string }>();
  const quotationId = Number(id);

  const [quotation, setQuotation] = useState<Quotation | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [auditLog, setAuditLog] = useState<AuditLogEntry[]>([]);
  const [crossSell, setCrossSell] = useState<CrossSellSuggestion[]>([]);
  const [splitPlan, setSplitPlan] = useState<SplitPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [newProductId, setNewProductId] = useState<number | "">("");
  const [newQuantity, setNewQuantity] = useState(1);
  const [newDiscount, setNewDiscount] = useState(0);

  async function refresh() {
    setError(null);
    try {
      const [q, ps, log] = await Promise.all([
        api.getQuotation(quotationId),
        api.listProducts(),
        api.listAuditLog(quotationId),
      ]);
      setQuotation(q);
      setProducts(ps);
      setAuditLog(log);
      if (ps.length > 0 && newProductId === "") setNewProductId(ps[0].id);

      if (q.status === "draft" && q.lines.length > 0) {
        api.getCrossSell(quotationId).then(setCrossSell).catch(() => setCrossSell([]));
      } else {
        setCrossSell([]);
      }

      if (q.status === "confirmed") {
        api.getSplitSuggestion(quotationId).then(setSplitPlan).catch(() => setSplitPlan(null));
      } else {
        setSplitPlan(null);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load this quotation");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quotationId]);

  const isDraft = quotation?.status === "draft";

  async function handleAddLine() {
    if (newProductId === "") return;
    setBusy(true);
    setError(null);
    try {
      await api.addLine(quotationId, newProductId, newQuantity, newDiscount);
      setNewQuantity(1);
      setNewDiscount(0);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not add line");
    } finally {
      setBusy(false);
    }
  }

  async function handleDiscountChange(lineId: number, discount: number) {
    setBusy(true);
    setError(null);
    try {
      await api.updateLine(quotationId, lineId, { discount_pct: discount });
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not update discount");
    } finally {
      setBusy(false);
    }
  }

  async function handleRemoveLine(lineId: number) {
    setBusy(true);
    setError(null);
    try {
      await api.removeLine(quotationId, lineId);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not remove line");
    } finally {
      setBusy(false);
    }
  }

  async function handleSubmit() {
    setBusy(true);
    setError(null);
    try {
      await api.submitForApproval(quotationId);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not submit for approval");
    } finally {
      setBusy(false);
    }
  }

  async function handleAddSuggestion(productId: number) {
    setBusy(true);
    setError(null);
    try {
      await api.addLine(quotationId, productId, 1, 0);
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not add this suggestion");
    } finally {
      setBusy(false);
    }
  }

  async function handleAcceptSplit() {
    setBusy(true);
    setError(null);
    try {
      const plan = await api.acceptSplit(quotationId);
      setSplitPlan(plan);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not accept this split");
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="page spinner-text">Loading quotation...</div>;
  if (!quotation) return <div className="page error-banner">Quotation not found.</div>;

  const tone = routingTone(quotation.routing);

  return (
    <div className="page">
      <div className="page-header">
        <h1>Quotation #{quotation.id} — {quotation.customer_name}</h1>
        <StatusBadge status={quotation.status} />
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className={`score-panel ${tone}`}>
        <div>
          <div className="score-label">Blended discount risk score</div>
          <div className="score-value">{quotation.blended_risk_score}</div>
        </div>
        <div>
          <RiskBadge routing={quotation.routing} />
          {quotation.hard_flag && (
            <div style={{ marginTop: 6, fontSize: 12, fontWeight: 700 }}>
              ⚠ At least one line broke its own category ceiling
            </div>
          )}
        </div>
        <div className="score-explain">
          Every line is checked against its own category's ceiling for this customer's tier, then every
          overage is weighted and summed — a few lines that are each only a little over their own limit
          can still push this score up, even if none of them look alarming alone.
        </div>
      </div>

      <div className="card">
        <h2>Line items</h2>
        {quotation.lines.length === 0 ? (
          <div className="empty-state">No products added yet.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Qty</th>
                <th>Discount %</th>
                <th>Ceiling %</th>
                <th>Overage</th>
                <th>Net total</th>
                <th>Margin %</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {quotation.lines.map((line) => (
                <tr key={line.id}>
                  <td>{line.product_name}</td>
                  <td>{line.category_name}</td>
                  <td>{line.quantity}</td>
                  <td style={{ width: 110 }}>
                    <input
                      type="number"
                      step="0.5"
                      min={0}
                      max={100}
                      defaultValue={line.discount_pct}
                      disabled={!isDraft || busy}
                      onBlur={(e) => {
                        const val = Number(e.target.value);
                        if (val !== line.discount_pct) handleDiscountChange(line.id, val);
                      }}
                    />
                  </td>
                  <td>{line.ceiling_pct}%</td>
                  <td>
                    {line.hard_flag ? (
                      <span className="line-flag-hard">+{line.overage_pts} pts (hard flag)</span>
                    ) : line.overage_pts > 0 ? (
                      <span className="line-flag-over">+{line.overage_pts} pts</span>
                    ) : (
                      <span className="line-flag-ok">within limit</span>
                    )}
                  </td>
                  <td>${line.net_total.toLocaleString()}</td>
                  <td>{line.margin_pct}%</td>
                  <td>
                    {isDraft && (
                      <button className="btn btn-outline btn-sm" disabled={busy} onClick={() => handleRemoveLine(line.id)}>
                        Remove
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        <div style={{ textAlign: "right", marginTop: 12, fontWeight: 700 }}>
          Grand total: ${quotation.grand_total.toLocaleString()}
        </div>
      </div>

      {isDraft && crossSell.length > 0 && (
        <div className="card elevated">
          <h2 className="section-title">Suggested add-ons</h2>
          <p style={{ fontSize: 12, color: "var(--color-text-muted)", marginTop: -8, marginBottom: 14 }}>
            Ranked by how much more often these are bought alongside what's already on this quote, versus
            their overall popularity — and filtered to healthy-margin products only.
          </p>
          {crossSell.map((s) => (
            <div className="cross-sell-card" key={s.product_id}>
              <div>
                <div style={{ fontWeight: 700 }}>{s.product_name}</div>
                <div className="cross-sell-meta">
                  {s.category_name} · ${s.list_price.toLocaleString()} · {s.margin_pct}% margin · co-bought{" "}
                  {s.co_occurrence_count}× historically
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <span className="lift-pill">{s.lift}× lift</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "var(--color-safe)" }}>
                  +${s.margin_delta_if_added.toLocaleString()} margin
                </span>
                <button className="btn btn-sm" disabled={busy} onClick={() => handleAddSuggestion(s.product_id)}>
                  Add to quote
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {quotation.status === "confirmed" && splitPlan && (
        <div className="card elevated">
          <h2 className="section-title">Fulfillment — suggested warehouse split</h2>
          <div className="split-summary-strip">
            <div className="split-summary-item">
              <div className="split-summary-value">{splitPlan.shipment_count}</div>
              <div className="split-summary-label">Shipments</div>
            </div>
            <div className="split-summary-item">
              <div className="split-summary-value">${splitPlan.estimated_shipping_cost}</div>
              <div className="split-summary-label">Est. shipping cost</div>
            </div>
            <div className="split-summary-item">
              <div className="split-summary-value">{splitPlan.total_backordered_units}</div>
              <div className="split-summary-label">Backordered units</div>
            </div>
          </div>

          {Object.entries(
            splitPlan.lines.reduce<Record<string, typeof splitPlan.lines>>((groups, line) => {
              const key = line.warehouse_name;
              (groups[key] ??= []).push(line);
              return groups;
            }, {}),
          ).map(([warehouseName, lines]) => (
            <div className={`warehouse-group ${lines[0].is_backorder ? "backorder" : ""}`} key={warehouseName}>
              <div className="warehouse-group-header">
                <div className="warehouse-group-title">{warehouseName}</div>
                {lines[0].is_backorder && <span className="badge badge-danger">Needs restock</span>}
              </div>
              {lines.map((line) => (
                <div key={line.quotation_line_id} style={{ fontSize: 13, padding: "3px 0" }}>
                  {line.product_name} — {line.quantity} units
                </div>
              ))}
            </div>
          ))}

          <button className="btn btn-safe" style={{ marginTop: 6 }} disabled={busy} onClick={handleAcceptSplit}>
            Accept suggested split
          </button>
          <p style={{ fontSize: 12, color: "var(--color-text-muted)", marginTop: 10, marginBottom: 0 }}>
            Cheapest-warehouse-first allocation, computed fresh from live stock. This is a transparent
            heuristic, not a claim of the mathematically optimal split — minimizing split shipments at scale
            is a known hard problem, so a manual override always remains available if this isn't right.
          </p>
        </div>
      )}

      {isDraft && (
        <div className="card">
          <h2>Add a product</h2>
          <div className="inline-form">
            <div className="form-row">
              <label htmlFor="product">Product</label>
              <select id="product" value={newProductId} onChange={(e) => setNewProductId(Number(e.target.value))}>
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (${p.list_price})
                  </option>
                ))}
              </select>
            </div>
            <div className="form-row" style={{ minWidth: 80 }}>
              <label htmlFor="qty">Qty</label>
              <input
                id="qty"
                type="number"
                min={1}
                value={newQuantity}
                onChange={(e) => setNewQuantity(Number(e.target.value))}
              />
            </div>
            <div className="form-row" style={{ minWidth: 100 }}>
              <label htmlFor="discount">Discount %</label>
              <input
                id="discount"
                type="number"
                min={0}
                max={100}
                step="0.5"
                value={newDiscount}
                onChange={(e) => setNewDiscount(Number(e.target.value))}
              />
            </div>
            <button className="btn" onClick={handleAddLine} disabled={busy || newProductId === ""}>
              Add line
            </button>
          </div>
        </div>
      )}

      {isDraft && (
        <div className="card">
          <button
            className="btn"
            style={{ width: "100%" }}
            disabled={busy || quotation.lines.length === 0}
            onClick={handleSubmit}
          >
            Submit for approval
          </button>
          <p style={{ fontSize: 12, color: "var(--color-text-muted)", marginTop: 10, marginBottom: 0 }}>
            The system decides automatically whether this needs Manager, Manager + Finance, or no approval
            at all — based on the risk score above, recomputed fresh at the moment you submit.
          </p>
        </div>
      )}

      <div className="card">
        <h2>Audit trail</h2>
        {auditLog.length === 0 ? (
          <div className="empty-state">No activity yet.</div>
        ) : (
          auditLog.map((entry) => (
            <div className="audit-item" key={entry.id}>
              <span className="audit-time">{new Date(entry.created_at).toLocaleString()}</span>
              <span className="audit-action">{entry.action.replace(/_/g, " ")}</span>
              <span>{entry.details}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
