import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, ApiError, type DiscountAnomaly, type StalledDeal } from "../api/client";

export function DealHealthPage() {
  const [anomalies, setAnomalies] = useState<DiscountAnomaly[]>([]);
  const [stalled, setStalled] = useState<StalledDeal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<"anomalies" | "stalled">("anomalies");

  useEffect(() => {
    Promise.all([api.listAnomalies(), api.listStalled()])
      .then(([a, s]) => {
        setAnomalies(a);
        setStalled(s);
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : "Could not load deal health data"))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="page">
      <div className="page-header">
        <h1>Deal health</h1>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div className="metric-grid">
        <div className="metric-card">
          <div className="metric-label">Discount anomalies</div>
          <div className="metric-value">{anomalies.length}</div>
          <div className="metric-sub">Unusual for that rep's own history</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Stalled deals</div>
          <div className="metric-value">{stalled.length}</div>
          <div className="metric-sub">Inactive 5+ days, still open</div>
        </div>
        <div className="metric-card">
          <div className="metric-label">Total value at risk</div>
          <div className="metric-value">${stalled.reduce((sum, s) => sum + s.grand_total, 0).toLocaleString()}</div>
          <div className="metric-sub">Sum of stalled deal totals</div>
        </div>
      </div>

      <div className="tab-row">
        <button className={`tab-btn ${tab === "anomalies" ? "active" : ""}`} onClick={() => setTab("anomalies")}>
          Discount anomalies
        </button>
        <button className={`tab-btn ${tab === "stalled" ? "active" : ""}`} onClick={() => setTab("stalled")}>
          Stalled deals
        </button>
      </div>

      {loading ? (
        <p className="spinner-text">Loading...</p>
      ) : tab === "anomalies" ? (
        <div className="card">
          <h2 className="section-title">Sorted by how far outside the rep's own pattern</h2>
          {anomalies.length === 0 ? (
            <div className="empty-state">No unusual discounts right now.</div>
          ) : (
            anomalies.map((a) => {
              const severity = Math.abs(a.z_score) >= 3 ? "high" : "medium";
              return (
                <div className="anomaly-row" key={a.quotation_id}>
                  <div>
                    <div style={{ fontWeight: 700 }}>
                      {a.rep_name} — {a.customer_name}
                    </div>
                    <div className="explain-line">
                      This deal averages {a.this_deal_avg_discount}% discount. {a.rep_name.split(" ")[0]}'s own
                      historical average is {a.rep_mean_discount}% (based on {a.sample_size} past confirmed
                      deals) — this one is {Math.abs(a.z_score)}σ away.
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <span className={`z-score-tag ${severity}`}>z = {a.z_score}</span>
                    <Link to={`/quotations/${a.quotation_id}`}>Open →</Link>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        <div className="card">
          <h2 className="section-title">Sorted by days since last activity</h2>
          {stalled.length === 0 ? (
            <div className="empty-state">Nothing has gone quiet.</div>
          ) : (
            stalled.map((s) => (
              <div className="anomaly-row" key={s.quotation_id}>
                <div>
                  <div style={{ fontWeight: 700 }}>
                    {s.customer_name} — {s.rep_name}
                  </div>
                  <div className="explain-line">
                    ${s.grand_total.toLocaleString()} · status: {s.status.replace(/_/g, " ")}
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <span className="z-score-tag high">{s.days_inactive} days</span>
                  <Link to={`/quotations/${s.quotation_id}`}>Open →</Link>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
