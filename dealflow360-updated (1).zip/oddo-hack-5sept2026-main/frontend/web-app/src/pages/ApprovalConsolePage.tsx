import { useEffect, useState } from "react";
import { useAuth } from "../auth/AuthContext";
import { api, ApiError, type ApprovalLevel, type Quotation } from "../api/client";
import { RiskBadge, StatusBadge } from "../components/RiskBadge";

export function ApprovalConsolePage() {
  const { user } = useAuth();
  const [queue, setQueue] = useState<Quotation[]>([]);
  const [selected, setSelected] = useState<Quotation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  // Admin can see/decide both queues for testing; Manager/Finance only see
  // their own level - matches the backend's role gate on the decide
  // endpoint exactly, so nothing here can queue up an action the API
  // would reject anyway.
  const level: ApprovalLevel = user?.role === "finance" ? "finance" : "manager";

  async function refresh() {
    setLoading(true);
    setError(null);
    try {
      const filter = level === "manager" ? "pending_manager" : "pending_finance";
      const items = await api.listQuotations(filter);
      setQueue(items);
      if (selected) {
        const stillPending = items.find((q) => q.id === selected.id);
        setSelected(stillPending ?? null);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load the approval queue");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [level]);

  async function decide(decision: "approved" | "rejected" | "returned") {
    if (!selected) return;
    setBusy(true);
    setError(null);
    try {
      await api.decideApproval(selected.id, level, decision, reason || undefined);
      setReason("");
      await refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not record this decision");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Approval queue — {level === "manager" ? "Manager" : "Finance"}</h1>
      </div>

      {error && <div className="error-banner">{error}</div>}

      <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20 }}>
        <div className="card" style={{ padding: 0 }}>
          <h2 style={{ padding: "18px 22px 0 22px" }}>Pending ({queue.length})</h2>
          {loading ? (
            <p className="spinner-text">Loading...</p>
          ) : queue.length === 0 ? (
            <div className="empty-state">Nothing waiting on you right now.</div>
          ) : (
            <div>
              {queue.map((q) => (
                <div
                  key={q.id}
                  onClick={() => setSelected(q)}
                  style={{
                    padding: "14px 22px",
                    borderBottom: "1px solid var(--color-border)",
                    cursor: "pointer",
                    background: selected?.id === q.id ? "#f0f1ff" : "transparent",
                  }}
                >
                  <div style={{ fontWeight: 700 }}>{q.customer_name}</div>
                  <div style={{ fontSize: 12, color: "var(--color-text-muted)", margin: "4px 0" }}>
                    ${q.grand_total.toLocaleString()} · score {q.blended_risk_score}
                  </div>
                  <RiskBadge routing={q.routing} />
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          {!selected ? (
            <div className="card empty-state">Select a quotation from the queue to review it.</div>
          ) : (
            <>
              <div className="card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <h2 style={{ margin: 0 }}>
                    {selected.customer_name} — Quotation #{selected.id}
                  </h2>
                  <StatusBadge status={selected.status} />
                </div>
                <table style={{ marginTop: 14 }}>
                  <thead>
                    <tr>
                      <th>Product</th>
                      <th>Category</th>
                      <th>Discount</th>
                      <th>Ceiling</th>
                      <th>Overage</th>
                      <th>Risk contribution</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selected.lines.map((line) => (
                      <tr key={line.id}>
                        <td>{line.product_name}</td>
                        <td>{line.category_name}</td>
                        <td>{line.discount_pct}%</td>
                        <td>{line.ceiling_pct}%</td>
                        <td>
                          {line.hard_flag ? (
                            <span className="line-flag-hard">+{line.overage_pts} pts (hard flag)</span>
                          ) : line.overage_pts > 0 ? (
                            <span className="line-flag-over">+{line.overage_pts} pts</span>
                          ) : (
                            <span className="line-flag-ok">within limit</span>
                          )}
                        </td>
                        <td>{line.risk_contribution}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div style={{ textAlign: "right", marginTop: 10, fontWeight: 700 }}>
                  Blended score: {selected.blended_risk_score} · Total: ${selected.grand_total.toLocaleString()}
                </div>
              </div>

              <div className="card">
                <h2>Decision</h2>
                <div className="form-row">
                  <label htmlFor="reason">Reason (optional, recorded in the audit trail)</label>
                  <textarea id="reason" rows={2} value={reason} onChange={(e) => setReason(e.target.value)} />
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button className="btn btn-safe" disabled={busy} onClick={() => decide("approved")}>
                    Approve
                  </button>
                  <button className="btn btn-outline" disabled={busy} onClick={() => decide("returned")}>
                    Return for revision
                  </button>
                  <button className="btn btn-danger" disabled={busy} onClick={() => decide("rejected")}>
                    Reject
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
