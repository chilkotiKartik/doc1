import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth/AuthContext";
import { Nav } from "./components/Nav";
import { LoginPage } from "./pages/LoginPage";
import { QuotationListPage } from "./pages/QuotationListPage";
import { QuotationBuilderPage } from "./pages/QuotationBuilderPage";
import { ApprovalConsolePage } from "./pages/ApprovalConsolePage";
import { DealHealthPage } from "./pages/DealHealthPage";

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="page spinner-text">Loading...</div>;
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function HomeRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const canApproveOnly = user.role === "manager" || user.role === "finance";
  return <Navigate to={canApproveOnly ? "/approvals" : "/quotations"} replace />;
}

export default function App() {
  const { user } = useAuth();

  return (
    <>
      {user && <Nav />}
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/" element={<HomeRedirect />} />
        <Route
          path="/quotations"
          element={
            <RequireAuth>
              <QuotationListPage />
            </RequireAuth>
          }
        />
        <Route
          path="/quotations/:id"
          element={
            <RequireAuth>
              <QuotationBuilderPage />
            </RequireAuth>
          }
        />
        <Route
          path="/approvals"
          element={
            <RequireAuth>
              <ApprovalConsolePage />
            </RequireAuth>
          }
        />
        <Route
          path="/deal-health"
          element={
            <RequireAuth>
              <DealHealthPage />
            </RequireAuth>
          }
        />
      </Routes>
    </>
  );
}
