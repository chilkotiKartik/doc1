# Backend

DealFlow360 backend service: models, business logic (Blended Discount Risk Engine, approval routing, warehouse split, billing, upsell, deal health), and API routes for both the internal app and customer portal.

See `/doc` at repo root for the full PRD and architecture.
