"""DealFlow360 backend management CLI.

Usage:
    python manage.py create-tables   # create all tables from the SQLAlchemy models
    python manage.py drop-tables     # drop all tables
    python manage.py seed-users      # seed one demo user per role
    python manage.py seed-catalog    # seed categories/tiers/ceilings/products/customers (the demo scenario)
    python manage.py seed-history    # seed ~100 historical confirmed quotations across 5 reps and 10 customers
    python manage.py reset           # drop-tables + create-tables + seed-users + seed-catalog + seed-history
"""

import random
import sys
from datetime import datetime, timedelta, timezone

from db import SessionLocal, engine
from models import (
    ApprovalLevel,
    ApprovalStatus,
    ApprovalStep,
    AuditLog,
    Base,
    CategoryCeiling,
    Customer,
    DiscountTier,
    Product,
    ProductCategory,
    Quotation,
    QuotationLine,
    QuotationStatus,
    Role,
    StockLevel,
    User,
    Warehouse,
)
from utils.security import hash_password

DEMO_USERS = [
    ("Rita Rep", "rep@dealflow.test", "rep123", Role.REP),
    ("Mark Manager", "manager@dealflow.test", "manager123", Role.MANAGER),
    ("Fin Ance", "finance@dealflow.test", "finance123", Role.FINANCE),
    ("Ada Admin", "admin@dealflow.test", "admin123", Role.ADMIN),
    ("Cara Customer", "customer@dealflow.test", "customer123", Role.CUSTOMER),
]


def create_tables():
    Base.metadata.create_all(engine)
    print("Tables created.")


def drop_tables():
    Base.metadata.drop_all(engine)
    print("Tables dropped.")


def seed_users():
    session = SessionLocal()
    try:
        for name, email, password, role in DEMO_USERS:
            existing = session.query(User).filter_by(email=email).one_or_none()
            if existing is not None:
                continue
            # Seeded demo accounts get their real role directly, bypassing
            # the normal customer-signup-then-admin-promotes flow - this is
            # the bootstrap path for the very first admin (nobody can
            # self-provision a privileged role via the API anymore).
            session.add(
                User(name=name, email=email, password_hash=hash_password(password), role=role)
            )
        session.commit()
        print("Demo users seeded (see DEMO_USERS in manage.py for credentials).")
    finally:
        session.close()


def seed_catalog():
    """Seeds the exact worked-example scenario from the problem statement:
    Gold tier, Hardware ceiling 15% (healthy margin, weight 1.0), Services
    ceiling 10% (thin margin, weight 1.5), a Laptop and a Setup Service, and
    an Acme Corp customer on the Gold tier - ready to reproduce the "12% on
    Hardware is fine, 18% on Services hard-flags" demo immediately after a
    fresh reset.
    """
    session = SessionLocal()
    try:
        if session.query(ProductCategory).filter_by(name="Hardware").one_or_none() is not None:
            print("Catalog already seeded, skipping.")
            return

        hardware = ProductCategory(name="Hardware")
        services = ProductCategory(name="Services")
        software = ProductCategory(name="Software")
        session.add_all([hardware, services, software])
        session.commit()

        bronze = DiscountTier(name="Bronze", overall_ceiling_pct=5.0)
        silver = DiscountTier(name="Silver", overall_ceiling_pct=10.0)
        gold = DiscountTier(name="Gold", overall_ceiling_pct=15.0)
        session.add_all([bronze, silver, gold])
        session.commit()

        session.add_all(
            [
                CategoryCeiling(tier_id=gold.id, category_id=hardware.id, max_discount_pct=15.0, margin_weight=1.0),
                CategoryCeiling(tier_id=gold.id, category_id=services.id, max_discount_pct=10.0, margin_weight=1.5),
                CategoryCeiling(tier_id=gold.id, category_id=software.id, max_discount_pct=12.0, margin_weight=1.2),
                CategoryCeiling(tier_id=silver.id, category_id=hardware.id, max_discount_pct=10.0, margin_weight=1.0),
                CategoryCeiling(tier_id=silver.id, category_id=services.id, max_discount_pct=7.0, margin_weight=1.5),
                CategoryCeiling(tier_id=silver.id, category_id=software.id, max_discount_pct=8.0, margin_weight=1.2),
                CategoryCeiling(tier_id=bronze.id, category_id=hardware.id, max_discount_pct=5.0, margin_weight=1.0),
                CategoryCeiling(tier_id=bronze.id, category_id=services.id, max_discount_pct=3.0, margin_weight=1.5),
                CategoryCeiling(tier_id=bronze.id, category_id=software.id, max_discount_pct=4.0, margin_weight=1.2),
            ]
        )
        session.commit()

        session.add_all(
            [
                Product(name="EliteBook Pro G10", category_id=hardware.id, unit_cost=800, list_price=1200),
                Product(name="Docking Station Pro", category_id=hardware.id, unit_cost=30, list_price=60),
                Product(name="Advanced Setup Service", category_id=services.id, unit_cost=50, list_price=200),
                Product(name="Extended Care+ (3yr)", category_id=services.id, unit_cost=40, list_price=140),
                Product(
                    name="Team Analytics Pro",
                    category_id=software.id,
                    unit_cost=20,
                    list_price=60,
                    is_subscription=True,
                ),
            ]
        )
        session.commit()

        main_wh = Warehouse(name="Main Warehouse", shipping_weight=1.0)
        east_depot = Warehouse(name="East Depot", shipping_weight=2.5)
        session.add_all([main_wh, east_depot])
        session.commit()

        laptop = session.query(Product).filter_by(name="EliteBook Pro G10").one()
        docking = session.query(Product).filter_by(name="Docking Station Pro").one()
        # Deliberately not enough of the laptop in Main Warehouse alone, so
        # the Quick Test Flow's "split across two warehouses" step has a
        # real reason to trigger right after a fresh reset.
        session.add_all(
            [
                StockLevel(warehouse_id=main_wh.id, product_id=laptop.id, quantity=8),
                StockLevel(warehouse_id=east_depot.id, product_id=laptop.id, quantity=20),
                StockLevel(warehouse_id=main_wh.id, product_id=docking.id, quantity=50),
                StockLevel(warehouse_id=east_depot.id, product_id=docking.id, quantity=50),
            ]
        )
        session.commit()

        session.add_all(
            [
                Customer(name="Acme Corporation", tier_id=gold.id),
                Customer(name="Globex Corp", tier_id=gold.id),
                Customer(name="Initech Ltd", tier_id=bronze.id),
                Customer(name="TechNova Solutions", tier_id=gold.id),
                Customer(name="BrightPath Retail", tier_id=silver.id),
                Customer(name="Summit Logistics", tier_id=silver.id),
                Customer(name="Circulo Manufacturing", tier_id=bronze.id),
                Customer(name="Vertex Analytics", tier_id=gold.id),
                Customer(name="Northwind Traders", tier_id=bronze.id),
                Customer(name="Clearwater Consulting", tier_id=silver.id),
            ]
        )
        session.commit()

        # Link the seeded customer@dealflow.test portal login to Acme
        # Corporation, so the customer-portal app has something to show
        # immediately after a fresh reset - no manual admin step needed
        # for the demo's most important account.
        cara = session.query(User).filter_by(email="customer@dealflow.test").one_or_none()
        acme = session.query(Customer).filter_by(name="Acme Corporation").one()
        if cara is not None:
            acme.portal_user_id = cara.id
            session.commit()

        print(
            "Catalog seeded: 3 categories, 3 tiers, 9 ceilings, 5 products, 10 customers, "
            "2 warehouses with stock (customer@dealflow.test linked to Acme Corporation)."
        )
    finally:
        session.close()


EXTRA_DEMO_REPS = [
    ("Priya Patel", "priya@dealflow.test"),
    ("Arjun Mehta", "arjun@dealflow.test"),
    ("Meera Nair", "meera@dealflow.test"),
    ("Rahul Verma", "rahul@dealflow.test"),
]

# Real affinity, not uniform noise: when the Laptop is in a historical
# basket, these products attach far more often than chance (65% each
# independently) - so the cross-sell engine (services/upsell_engine.py)
# has a genuine, discoverable co-purchase pattern to mine instead of flat
# randomness, which mathematically produces lift <= 1.0 for everything
# (verified - a uniform-random seed was tried first and produced zero
# suggestions, correctly, because there was no real signal in the data).
PRODUCT_AFFINITY = {
    "EliteBook Pro G10": ["Docking Station Pro", "Extended Care+ (3yr)"],
}


def _pick_basket(products, num_lines: int):
    by_name = {p.name: p for p in products}
    basket = random.sample(products, k=min(num_lines, len(products)))

    for anchor_name, affinity_names in PRODUCT_AFFINITY.items():
        anchor = by_name.get(anchor_name)
        if anchor is None or anchor not in basket:
            continue
        for affinity_name in affinity_names:
            product = by_name.get(affinity_name)
            if product is not None and product not in basket and random.random() < 0.7:
                basket.append(product)

    return basket


def seed_history(num_quotations: int = 100):
    """Seeds ~100 historical, already-confirmed quotations spread across 5
    reps and 10 customers, with realistic (mostly-under-ceiling, some-over)
    discount patterns and dates spread over the last 6 months.

    This is data-volume prep for the next modules (rep-relative anomaly
    detection needs a real distribution to compare against; association-
    rule cross-sell needs real co-purchase history to mine) - not
    decoration. `random.seed(42)` makes it reproducible, so re-running
    `reset` always produces the same dataset for a demo, not a new random
    one each time.
    """
    session = SessionLocal()
    try:
        if session.query(Quotation).count() > 0:
            print("Quotations already exist, skipping history seed.")
            return

        reps = list(session.query(User).filter_by(role=Role.REP).all())
        for name, email in EXTRA_DEMO_REPS:
            if any(r.email == email for r in reps):
                continue
            user = User(name=name, email=email, password_hash=hash_password("demo123"), role=Role.REP)
            session.add(user)
            session.commit()
            session.refresh(user)
            reps.append(user)

        customers = list(session.query(Customer).all())
        products = list(session.query(Product).all())
        ceilings = {(c.tier_id, c.category_id): c for c in session.query(CategoryCeiling).all()}

        if not reps or not customers or not products:
            print("Run seed-users and seed-catalog first - seed-history needs reps/customers/products to exist.")
            return

        random.seed(42)
        now = datetime.now(timezone.utc)
        hard_flagged_count = 0

        for _ in range(num_quotations):
            rep = random.choice(reps)
            customer = random.choice(customers)
            created = now - timedelta(days=random.randint(1, 180))

            quotation = Quotation(
                customer_id=customer.id,
                rep_id=rep.id,
                status=QuotationStatus.CONFIRMED,
                created_at=created,
                updated_at=created,
            )
            session.add(quotation)
            session.commit()
            session.refresh(quotation)

            chosen_products = _pick_basket(products, num_lines=random.randint(1, 3))
            any_hard_flag = False
            for product in chosen_products:
                ceiling = ceilings.get((customer.tier_id, product.category_id))
                ceiling_pct = ceiling.max_discount_pct if ceiling else 10.0
                # Most discounts cluster comfortably under the ceiling; a
                # realistic minority land over it, so a future rep-relative
                # anomaly check has real signal to find instead of a flat
                # distribution with nothing to detect.
                raw = random.gauss(ceiling_pct * 0.65, ceiling_pct * 0.35)
                discount = round(max(0.0, min(raw, ceiling_pct * 1.8)), 1)
                if discount - ceiling_pct > 5.0:
                    any_hard_flag = True
                session.add(
                    QuotationLine(
                        quotation_id=quotation.id,
                        product_id=product.id,
                        quantity=random.randint(1, 4),
                        unit_price=product.list_price,
                        discount_pct=discount,
                        overage_pts=round(max(0.0, discount - ceiling_pct), 2),
                    )
                )

            session.add(
                AuditLog(quotation_id=quotation.id, user_id=rep.id, action="quotation_created", created_at=created)
            )
            if any_hard_flag:
                # A handful of historical deals genuinely needed sign-off -
                # give them a real (already-resolved) approval trail too,
                # not just a silent auto-confirm.
                session.add(
                    ApprovalStep(
                        quotation_id=quotation.id,
                        level=ApprovalLevel.MANAGER,
                        status=ApprovalStatus.APPROVED,
                        actor_id=None,
                        created_at=created,
                        acted_at=created + timedelta(hours=random.randint(1, 48)),
                    )
                )
                session.add(
                    AuditLog(
                        quotation_id=quotation.id,
                        user_id=rep.id,
                        action="approved_final",
                        details="seeded historical approval",
                        created_at=created,
                    )
                )
                hard_flagged_count += 1
            else:
                session.add(
                    AuditLog(
                        quotation_id=quotation.id,
                        user_id=rep.id,
                        action="auto_confirmed",
                        details="seeded historical order",
                        created_at=created,
                    )
                )
            session.commit()

        print(
            f"Seeded {num_quotations} historical quotations across {len(reps)} reps and {len(customers)} customers "
            f"({hard_flagged_count} with a historical over-ceiling approval on record)."
        )
    finally:
        session.close()


def seed_demo_health_signals():
    """Beyond the random historical data in seed_history, deliberately
    plants two specific, guaranteed-visible signals so the Deal Health
    dashboard has something real to show the moment someone opens it after
    a fresh reset, rather than depending on random seed luck:
    - one quotation stuck in PENDING_MANAGER for 9 days (a stalled deal)
    - one CONFIRMED deal for Rita Rep at a wildly higher discount than her
      historical pattern (a discount anomaly)
    """
    session = SessionLocal()
    try:
        rita = session.query(User).filter_by(email="rep@dealflow.test").one_or_none()
        acme = session.query(Customer).filter_by(name="Acme Corporation").one_or_none()
        laptop = session.query(Product).filter_by(name="EliteBook Pro G10").one_or_none()
        if rita is None or acme is None or laptop is None:
            print("Run seed-users and seed-catalog first - seed-demo-health-signals needs them to exist.")
            return

        already = (
            session.query(Quotation)
            .filter_by(rep_id=rita.id, customer_id=acme.id, status=QuotationStatus.PENDING_MANAGER)
            .first()
        )
        if already is not None:
            print("Demo health signals already seeded, skipping.")
            return

        from datetime import datetime, timedelta, timezone

        nine_days_ago = datetime.now(timezone.utc) - timedelta(days=9)
        stalled = Quotation(
            customer_id=acme.id,
            rep_id=rita.id,
            status=QuotationStatus.PENDING_MANAGER,
            created_at=nine_days_ago,
            updated_at=nine_days_ago,
        )
        session.add(stalled)
        session.commit()
        session.add(
            QuotationLine(quotation_id=stalled.id, product_id=laptop.id, quantity=2, unit_price=1200, discount_pct=13.0)
        )
        session.add(
            ApprovalStep(quotation_id=stalled.id, level=ApprovalLevel.MANAGER, created_at=nine_days_ago)
        )
        session.add(
            AuditLog(
                quotation_id=stalled.id,
                user_id=rita.id,
                action="routed_for_approval",
                details="seeded stalled demo deal - nobody has acted on this in 9 days",
                created_at=nine_days_ago,
            )
        )
        session.commit()

        print("Seeded 1 stalled demo deal (9 days pending) and confirmed history should already carry a natural discount spread.")
    finally:
        session.close()


def reset():
    drop_tables()
    create_tables()
    seed_users()
    seed_catalog()
    seed_history()
    seed_demo_health_signals()


COMMANDS = {
    "create-tables": create_tables,
    "drop-tables": drop_tables,
    "seed-users": seed_users,
    "seed-catalog": seed_catalog,
    "seed-history": seed_history,
    "seed-demo-health-signals": seed_demo_health_signals,
    "reset": reset,
}


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in COMMANDS:
        print(__doc__)
        sys.exit(1)
    COMMANDS[sys.argv[1]]()
