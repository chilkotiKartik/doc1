"""End-to-end HTTP tests for the quotation lifecycle - signup/login through
real endpoints (not direct DB manipulation) wherever a real user would,
proving the whole loop works over the wire, not just at the service layer
(that's test_risk_engine.py's job).
"""

from models.user import Role


def _signup_and_promote(client, db_session, name, email, role: Role) -> str:
    client.post("/api/auth/signup", json={"name": name, "email": email, "password": "hunter2"})
    from models.user import User

    user = db_session.query(User).filter_by(email=email).one()
    user.role = role
    db_session.commit()
    resp = client.post("/api/auth/login", json={"email": email, "password": "hunter2"})
    return resp.json()["token"]


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _setup_gold_catalog(client, admin_token):
    """Hardware ceiling 15%, Services ceiling 10% - the same numbers as the
    problem statement's own worked example.
    """
    hw = client.post("/api/catalog/categories", json={"name": "Hardware"}, headers=_auth(admin_token)).json()
    svc = client.post("/api/catalog/categories", json={"name": "Services"}, headers=_auth(admin_token)).json()
    gold = client.post(
        "/api/governance/tiers", json={"name": "Gold", "overall_ceiling_pct": 15.0}, headers=_auth(admin_token)
    ).json()
    client.put(
        "/api/governance/ceilings",
        json={"tier_id": gold["id"], "category_id": hw["id"], "max_discount_pct": 15.0, "margin_weight": 1.0},
        headers=_auth(admin_token),
    )
    client.put(
        "/api/governance/ceilings",
        json={"tier_id": gold["id"], "category_id": svc["id"], "max_discount_pct": 10.0, "margin_weight": 1.5},
        headers=_auth(admin_token),
    )
    laptop = client.post(
        "/api/catalog/products",
        json={"name": "Laptop", "category_id": hw["id"], "unit_cost": 800, "list_price": 1200},
        headers=_auth(admin_token),
    ).json()
    setup_service = client.post(
        "/api/catalog/products",
        json={"name": "Setup Service", "category_id": svc["id"], "unit_cost": 50, "list_price": 200},
        headers=_auth(admin_token),
    ).json()
    customer = client.post(
        "/api/customers", json={"name": "Acme Corp", "tier_id": gold["id"]}, headers=_auth(admin_token)
    ).json()
    return {"hardware": hw, "services": svc, "gold": gold, "laptop": laptop, "setup_service": setup_service, "customer": customer}


def test_full_flow_hard_flagged_quote_routes_through_manager_and_finance(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep@dealflow.test", Role.REP)
    manager_token = _signup_and_promote(client, db_session, "Mark Manager", "manager@dealflow.test", Role.MANAGER)
    finance_token = _signup_and_promote(client, db_session, "Fin Ance", "finance@dealflow.test", Role.FINANCE)

    catalog = _setup_gold_catalog(client, admin_token)

    # Rep builds the quote from the spec's own worked example.
    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()
    assert quote["status"] == "draft"

    client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["laptop"]["id"], "quantity": 1, "discount_pct": 12.0},
        headers=_auth(rep_token),
    )
    after_second_line = client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["setup_service"]["id"], "quantity": 1, "discount_pct": 18.0},
        headers=_auth(rep_token),
    ).json()

    # Live margin/risk update after every line - not just at submit time.
    service_line = next(l for l in after_second_line["lines"] if l["product_name"] == "Setup Service")
    assert service_line["overage_pts"] == 8.0
    assert service_line["hard_flag"] is True
    assert after_second_line["hard_flag"] is True

    # Rep never explicitly "requests" approval - submitting just asks the
    # engine, which routes it automatically.
    submitted = client.post(f"/api/quotations/{quote['id']}/submit", headers=_auth(rep_token)).json()
    assert submitted["status"] == "pending_manager"
    assert submitted["routing"] == "manager_finance"

    # A rep cannot decide their own approval.
    forbidden = client.post(
        f"/api/quotations/{quote['id']}/approvals/manager",
        json={"decision": "approved"},
        headers=_auth(rep_token),
    )
    assert forbidden.status_code == 403

    # Manager approves - Finance step is created lazily, only now.
    after_manager = client.post(
        f"/api/quotations/{quote['id']}/approvals/manager",
        json={"decision": "approved"},
        headers=_auth(manager_token),
    ).json()
    assert after_manager["status"] == "pending_finance"

    approvals = client.get(f"/api/quotations/{quote['id']}/approvals", headers=_auth(rep_token)).json()
    assert [a["level"] for a in approvals] == ["manager", "finance"]
    assert approvals[0]["status"] == "approved"
    assert approvals[1]["status"] == "pending"

    # Finance cannot act on a manager-level step and vice versa.
    wrong_level = client.post(
        f"/api/quotations/{quote['id']}/approvals/manager",
        json={"decision": "approved"},
        headers=_auth(finance_token),
    )
    assert wrong_level.status_code in (403, 409)  # 403 if role-gated, 409 if no pending manager step left

    confirmed = client.post(
        f"/api/quotations/{quote['id']}/approvals/finance",
        json={"decision": "approved"},
        headers=_auth(finance_token),
    ).json()
    assert confirmed["status"] == "confirmed"

    audit_log = client.get(f"/api/quotations/{quote['id']}/audit-log", headers=_auth(rep_token)).json()
    actions = [entry["action"] for entry in audit_log]
    assert "quotation_created" in actions
    assert "routed_for_approval" in actions
    assert "approved" in actions
    assert "approved_final" in actions


def test_clean_quote_auto_confirms_with_no_approval_needed(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin2@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep2@dealflow.test", Role.REP)
    catalog = _setup_gold_catalog(client, admin_token)

    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()
    client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["laptop"]["id"], "quantity": 1, "discount_pct": 10.0},
        headers=_auth(rep_token),
    )

    submitted = client.post(f"/api/quotations/{quote['id']}/submit", headers=_auth(rep_token)).json()

    assert submitted["routing"] == "none"
    assert submitted["status"] == "confirmed"

    approvals = client.get(f"/api/quotations/{quote['id']}/approvals", headers=_auth(rep_token)).json()
    assert approvals == []  # no approval steps were ever created - the absence IS the signal


def test_manager_can_return_quote_for_revision(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin3@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep3@dealflow.test", Role.REP)
    manager_token = _signup_and_promote(client, db_session, "Mark Manager", "manager3@dealflow.test", Role.MANAGER)
    catalog = _setup_gold_catalog(client, admin_token)

    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()
    client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["setup_service"]["id"], "quantity": 1, "discount_pct": 13.0},
        headers=_auth(rep_token),
    )
    client.post(f"/api/quotations/{quote['id']}/submit", headers=_auth(rep_token))

    returned = client.post(
        f"/api/quotations/{quote['id']}/approvals/manager",
        json={"decision": "returned", "reason": "please reduce the service discount"},
        headers=_auth(manager_token),
    ).json()

    assert returned["status"] == "draft"

    # Back in draft, the rep can edit the line again.
    fixed = client.patch(
        f"/api/quotations/{quote['id']}/lines/{returned['lines'][0]['id']}",
        json={"discount_pct": 8.0},
        headers=_auth(rep_token),
    ).json()
    assert fixed["lines"][0]["overage_pts"] == 0.0


def test_cannot_edit_a_quotation_once_it_is_pending_approval(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin4@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep4@dealflow.test", Role.REP)
    catalog = _setup_gold_catalog(client, admin_token)

    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()
    client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["setup_service"]["id"], "quantity": 1, "discount_pct": 18.0},
        headers=_auth(rep_token),
    )
    client.post(f"/api/quotations/{quote['id']}/submit", headers=_auth(rep_token))

    blocked = client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["laptop"]["id"], "quantity": 1, "discount_pct": 5.0},
        headers=_auth(rep_token),
    )
    assert blocked.status_code == 409
