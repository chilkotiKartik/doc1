from datetime import timedelta

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session as DBSession

from models import Base
from models.user import Role, User
from services import auth_service
from utils.security import hash_password


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with DBSession(engine) as session:
        yield session


@pytest.fixture()
def rep_user(session):
    user = User(
        name="Rita Rep",
        email="rita@dealflow.test",
        password_hash=hash_password("hunter2"),
        role=Role.REP,
    )
    session.add(user)
    session.commit()
    return user


def test_authenticate_with_correct_credentials_returns_user(session, rep_user):
    user = auth_service.authenticate(session, email="rita@dealflow.test", password="hunter2")
    assert user.id == rep_user.id


def test_authenticate_with_wrong_password_raises(session, rep_user):
    with pytest.raises(auth_service.InvalidCredentials):
        auth_service.authenticate(session, email="rita@dealflow.test", password="wrong")


def test_authenticate_with_unknown_email_raises(session):
    with pytest.raises(auth_service.InvalidCredentials):
        auth_service.authenticate(session, email="nobody@dealflow.test", password="whatever")


def test_signup_creates_user_and_can_then_authenticate(session):
    user = auth_service.signup(session, name="New Person", email="new@dealflow.test", password="hunter2")

    assert user.id is not None
    authenticated = auth_service.authenticate(session, email="new@dealflow.test", password="hunter2")
    assert authenticated.id == user.id


def test_signup_always_creates_a_customer_account(session):
    user = auth_service.signup(session, name="New Person", email="new@dealflow.test", password="hunter2")

    assert user.role == Role.CUSTOMER


def test_signup_with_existing_email_raises(session, rep_user):
    with pytest.raises(auth_service.EmailAlreadyRegistered):
        auth_service.signup(session, name="Someone Else", email="rita@dealflow.test", password="whatever")


def test_access_token_round_trips_user_id_and_role(rep_user):
    token = auth_service.create_access_token(rep_user)

    payload = auth_service.decode_access_token(token)

    assert payload.user_id == rep_user.id
    assert payload.role == Role.REP


def test_access_token_is_not_a_db_lookup_it_is_self_contained(rep_user):
    # No DB session passed at all - decoding is pure, no state to query.
    token = auth_service.create_access_token(rep_user)
    payload = auth_service.decode_access_token(token)
    assert payload.user_id == rep_user.id


def test_tampered_token_is_rejected(rep_user):
    token = auth_service.create_access_token(rep_user)
    # Flip a character in the middle of the signature segment - flipping the
    # very last base64url character can land on a padding bit that doesn't
    # change the decoded signature bytes, so it isn't a reliable tamper.
    mid = len(token) // 2
    flipped_char = "a" if token[mid] != "a" else "b"
    tampered = token[:mid] + flipped_char + token[mid + 1 :]

    with pytest.raises(auth_service.InvalidToken):
        auth_service.decode_access_token(tampered)


def test_expired_token_is_rejected(rep_user):
    token = auth_service.create_access_token(rep_user, expires_delta=timedelta(seconds=-1))

    with pytest.raises(auth_service.InvalidToken):
        auth_service.decode_access_token(token)


def test_resolve_user_from_token_returns_the_user(session, rep_user):
    token = auth_service.create_access_token(rep_user)

    resolved = auth_service.resolve_user_from_token(session, token)

    assert resolved.id == rep_user.id


def test_resolve_user_from_token_rejects_invalid_token(session):
    with pytest.raises(auth_service.InvalidToken):
        auth_service.resolve_user_from_token(session, "not-a-real-jwt")


def test_resolve_user_from_token_rejects_deleted_user(session, rep_user):
    token = auth_service.create_access_token(rep_user)
    session.delete(rep_user)
    session.commit()

    with pytest.raises(auth_service.InvalidToken):
        auth_service.resolve_user_from_token(session, token)


def test_two_tokens_for_the_same_user_have_different_jti(rep_user):
    payload_a = auth_service.decode_access_token(auth_service.create_access_token(rep_user))
    payload_b = auth_service.decode_access_token(auth_service.create_access_token(rep_user))

    assert payload_a.jti != payload_b.jti


def test_revoked_token_is_rejected_by_resolve_user_from_token(session, rep_user):
    token = auth_service.create_access_token(rep_user)
    payload = auth_service.decode_access_token(token)

    auth_service.revoke_token(session, jti=payload.jti, expires_at=payload.exp)

    with pytest.raises(auth_service.InvalidToken):
        auth_service.resolve_user_from_token(session, token)


def test_revoking_a_token_does_not_affect_a_different_token_for_the_same_user(session, rep_user):
    token_a = auth_service.create_access_token(rep_user)
    token_b = auth_service.create_access_token(rep_user)
    payload_a = auth_service.decode_access_token(token_a)

    auth_service.revoke_token(session, jti=payload_a.jti, expires_at=payload_a.exp)

    with pytest.raises(auth_service.InvalidToken):
        auth_service.resolve_user_from_token(session, token_a)
    # token_b is unaffected - revoking one token doesn't log out all sessions.
    resolved = auth_service.resolve_user_from_token(session, token_b)
    assert resolved.id == rep_user.id


def test_revoking_the_same_jti_twice_is_idempotent(session, rep_user):
    token = auth_service.create_access_token(rep_user)
    payload = auth_service.decode_access_token(token)

    auth_service.revoke_token(session, jti=payload.jti, expires_at=payload.exp)
    auth_service.revoke_token(session, jti=payload.jti, expires_at=payload.exp)  # should not raise

    with pytest.raises(auth_service.InvalidToken):
        auth_service.resolve_user_from_token(session, token)
