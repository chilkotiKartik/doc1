from utils.security import hash_password, verify_password


def test_hash_password_is_not_plaintext():
    hashed = hash_password("correct horse battery staple")
    assert hashed != "correct horse battery staple"


def test_verify_password_accepts_correct_password():
    hashed = hash_password("correct horse battery staple")
    assert verify_password("correct horse battery staple", hashed) is True


def test_verify_password_rejects_wrong_password():
    hashed = hash_password("correct horse battery staple")
    assert verify_password("wrong password", hashed) is False


def test_same_password_hashes_differently_each_time():
    # salted - two hashes of the same password must differ, but both verify.
    hashed_a = hash_password("hunter2")
    hashed_b = hash_password("hunter2")
    assert hashed_a != hashed_b
    assert verify_password("hunter2", hashed_a) is True
    assert verify_password("hunter2", hashed_b) is True
