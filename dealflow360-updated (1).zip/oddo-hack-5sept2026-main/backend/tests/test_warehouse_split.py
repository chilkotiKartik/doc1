import pytest

from models import (
    Customer,
    DiscountTier,
    Product,
    ProductCategory,
    Quotation,
    QuotationLine,
    Role,
    StockLevel,
    User,
    Warehouse,
)
from services import warehouse_split
from utils.security import hash_password


@pytest.fixture()
def scenario(db_session):
    rep = User(name="Rita Rep", email="rita_wh@dealflow.test", password_hash=hash_password("x"), role=Role.REP)
    tier = DiscountTier(name="Gold", overall_ceiling_pct=15.0)
    category = ProductCategory(name="Hardware")
    db_session.add_all([rep, tier, category])
    db_session.commit()

    customer = Customer(name="Acme", tier_id=tier.id)
    product = Product(name="Laptop", category_id=category.id, unit_cost=800, list_price=1200)
    db_session.add_all([customer, product])
    db_session.commit()

    quotation = Quotation(customer_id=customer.id, rep_id=rep.id)
    db_session.add(quotation)
    db_session.commit()

    line = QuotationLine(quotation_id=quotation.id, product_id=product.id, quantity=15, unit_price=1200, discount_pct=0)
    db_session.add(line)
    db_session.commit()
    db_session.refresh(line)

    return {"quotation": quotation, "product": product, "line": line}


def test_single_warehouse_covers_the_whole_order(db_session, scenario):
    wh = Warehouse(name="Main", shipping_weight=1.0)
    db_session.add(wh)
    db_session.commit()
    db_session.add(StockLevel(warehouse_id=wh.id, product_id=scenario["product"].id, quantity=50))
    db_session.commit()

    plan = warehouse_split.suggest_split(db_session, scenario["quotation"].id)

    assert plan.shipment_count == 1
    assert plan.total_backordered_units == 0
    assert sum(a.quantity for a in plan.lines) == 15


def test_splits_across_two_warehouses_cheapest_first(db_session, scenario):
    cheap = Warehouse(name="Main Warehouse", shipping_weight=1.0)
    expensive = Warehouse(name="East Depot", shipping_weight=3.0)
    db_session.add_all([cheap, expensive])
    db_session.commit()

    # Cheap warehouse only has 10 of the 15 needed - the rest must come
    # from the more expensive one, in that specific order.
    db_session.add(StockLevel(warehouse_id=cheap.id, product_id=scenario["product"].id, quantity=10))
    db_session.add(StockLevel(warehouse_id=expensive.id, product_id=scenario["product"].id, quantity=20))
    db_session.commit()

    plan = warehouse_split.suggest_split(db_session, scenario["quotation"].id)

    assert plan.shipment_count == 2
    assert plan.total_backordered_units == 0
    by_warehouse = {a.warehouse_name: a.quantity for a in plan.lines}
    assert by_warehouse["Main Warehouse"] == 10
    assert by_warehouse["East Depot"] == 5


def test_insufficient_total_stock_produces_a_backorder(db_session, scenario):
    wh = Warehouse(name="Main", shipping_weight=1.0)
    db_session.add(wh)
    db_session.commit()
    db_session.add(StockLevel(warehouse_id=wh.id, product_id=scenario["product"].id, quantity=8))
    db_session.commit()

    plan = warehouse_split.suggest_split(db_session, scenario["quotation"].id)

    assert plan.total_backordered_units == 7
    backorder_lines = [a for a in plan.lines if a.is_backorder]
    assert len(backorder_lines) == 1
    assert backorder_lines[0].quantity == 7


def test_accept_allocation_persists_and_replaces_prior_acceptance(db_session, scenario):
    wh = Warehouse(name="Main", shipping_weight=1.0)
    db_session.add(wh)
    db_session.commit()
    db_session.add(StockLevel(warehouse_id=wh.id, product_id=scenario["product"].id, quantity=15))
    db_session.commit()

    warehouse_split.accept_allocation(db_session, scenario["quotation"].id)
    first = warehouse_split.get_accepted_allocation(db_session, scenario["quotation"].id)
    assert len(first) == 1

    # Restock changes, re-accepting should replace, not duplicate.
    warehouse_split.accept_allocation(db_session, scenario["quotation"].id)
    second = warehouse_split.get_accepted_allocation(db_session, scenario["quotation"].id)
    assert len(second) == 1


def test_no_warehouses_configured_backorders_everything(db_session, scenario):
    plan = warehouse_split.suggest_split(db_session, scenario["quotation"].id)
    assert plan.shipment_count == 0
    assert plan.total_backordered_units == 15
