"""Unit tests for services/risk_engine.py - fully DB-backed (via the shared
db_session fixture from conftest.py) but no HTTP/FastAPI involved at all,
per ARCHITECTURE.md's rule that services are testable without spinning up
the app.

test_hard_flag_scenario encodes the EXACT worked example that appears in
the problem statement and every planning doc: Gold tier, Hardware ceiling
15%, Services ceiling 10%, a Laptop at 12% (fine) and a Setup Service at
18% (8 points over -> hard flag). This is the proof that the scoring logic
is real, not a demo-only script - if anyone changes the formula and this
test still passes, the formula still matches the spec's own example.
"""

import pytest
from sqlalchemy import select

from models import (
    CategoryCeiling,
    Customer,
    DiscountTier,
    Product,
    ProductCategory,
    Quotation,
    QuotationLine,
    Role,
    User,
)
from services import risk_engine
from utils.security import hash_password


@pytest.fixture()
def rep(db_session):
    user = User(name="Rita Rep", email="rita@dealflow.test", password_hash=hash_password("x"), role=Role.REP)
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


@pytest.fixture()
def gold_customer(db_session):
    """Gold tier: Hardware ceiling 15% (weight 1.0), Services ceiling 10%
    (weight 1.5 - thinner margins weigh more heavily in the blended score,
    matching the brief's own framing of Services as the stricter category).
    """
    hardware = ProductCategory(name="Hardware")
    services = ProductCategory(name="Services")
    gold = DiscountTier(name="Gold", overall_ceiling_pct=15.0)
    db_session.add_all([hardware, services, gold])
    db_session.commit()

    db_session.add_all(
        [
            CategoryCeiling(tier_id=gold.id, category_id=hardware.id, max_discount_pct=15.0, margin_weight=1.0),
            CategoryCeiling(tier_id=gold.id, category_id=services.id, max_discount_pct=10.0, margin_weight=1.5),
        ]
    )
    customer = Customer(name="Acme Corp", tier_id=gold.id)
    db_session.add(customer)
    db_session.commit()
    db_session.refresh(customer)
    return {"customer": customer, "tier": gold, "hardware": hardware, "services": services}


def _make_quotation(db_session, customer_id: int, rep_id: int) -> Quotation:
    q = Quotation(customer_id=customer_id, rep_id=rep_id)
    db_session.add(q)
    db_session.commit()
    db_session.refresh(q)
    return q


def _add_line(db_session, quotation_id: int, product: Product, quantity: int, discount_pct: float) -> QuotationLine:
    line = QuotationLine(
        quotation_id=quotation_id,
        product_id=product.id,
        quantity=quantity,
        unit_price=product.list_price,
        discount_pct=discount_pct,
    )
    db_session.add(line)
    db_session.commit()
    db_session.refresh(line)
    return line


def test_empty_quotation_scores_zero_and_routes_nowhere(db_session, gold_customer, rep):
    q = _make_quotation(db_session, gold_customer["customer"].id, rep.id)

    result = risk_engine.score_quotation(db_session, q)

    assert result.blended_score == 0.0
    assert result.hard_flag is False
    assert result.routing == risk_engine.ROUTING_NONE
    assert result.lines == []


def test_hard_flag_scenario_matches_the_spec_worked_example(db_session, gold_customer, rep):
    """Laptop (Hardware) at 12% - within the 15% ceiling, fine.
    Setup Service (Services) at 18% - 8 points over the 10% ceiling.
    This single line must hard-flag the whole quotation to Manager+Finance,
    regardless of what the order-average discount looks like.
    """
    hardware, services = gold_customer["hardware"], gold_customer["services"]
    laptop = Product(name="Laptop", category_id=hardware.id, unit_cost=800, list_price=1200)
    setup_service = Product(name="Setup Service", category_id=services.id, unit_cost=50, list_price=200)
    db_session.add_all([laptop, setup_service])
    db_session.commit()

    q = _make_quotation(db_session, gold_customer["customer"].id, rep.id)
    _add_line(db_session, q.id, laptop, quantity=1, discount_pct=12.0)
    _add_line(db_session, q.id, setup_service, quantity=1, discount_pct=18.0)

    result = risk_engine.score_quotation(db_session, q)

    laptop_line = next(l for l in result.lines if l.product_name == "Laptop")
    service_line = next(l for l in result.lines if l.product_name == "Setup Service")

    assert laptop_line.overage_pts == 0.0
    assert laptop_line.hard_flag is False

    assert service_line.overage_pts == 8.0
    assert service_line.hard_flag is True

    assert result.hard_flag is True
    assert result.routing == risk_engine.ROUTING_MANAGER_FINANCE


def test_many_small_overages_escalate_even_though_no_single_line_is_alarming(db_session, gold_customer, rep):
    """Five Service lines, each only 3 points over the 10% ceiling (well
    under the 5pt single-line hard-flag threshold) - none alarming alone.
    Weighted by Services' 1.5 margin_weight and summed, they still cross
    the Manager-approval threshold. This is the exact "blended" scenario
    the brief describes: small violations spread across many lines must
    not slip through unnoticed.
    """
    services = gold_customer["services"]
    for i in range(5):
        product = Product(name=f"Install Labor {i}", category_id=services.id, unit_cost=50, list_price=1000)
        db_session.add(product)
    db_session.commit()

    products = list(db_session.execute(select(Product).where(Product.category_id == services.id)).scalars())
    q = _make_quotation(db_session, gold_customer["customer"].id, rep.id)
    for product in products:
        _add_line(db_session, q.id, product, quantity=1, discount_pct=13.0)  # 3 pts over the 10% ceiling

    result = risk_engine.score_quotation(db_session, q)

    assert all(l.overage_pts == 3.0 for l in result.lines)
    assert all(l.hard_flag is False for l in result.lines)  # no single line looks alarming
    assert result.hard_flag is False

    # Equal price/qty/discount -> equal value share (1/5 each):
    # risk_i = 3 * 1.5 * (1/5) = 0.9 per line; blended = 5 * 0.9 = 4.5
    assert result.blended_score == 4.5
    assert result.routing == risk_engine.ROUTING_MANAGER


def test_missing_ceiling_configuration_raises_instead_of_silently_allowing(db_session, gold_customer, rep):
    """A category with no CategoryCeiling row for this tier must fail loudly
    - silently treating "no rule" as "no limit" would defeat the entire
    point of the engine.
    """
    unconfigured_category = ProductCategory(name="Software")
    db_session.add(unconfigured_category)
    db_session.commit()

    product = Product(name="SaaS Seat", category_id=unconfigured_category.id, unit_cost=20, list_price=60)
    db_session.add(product)
    db_session.commit()

    q = _make_quotation(db_session, gold_customer["customer"].id, rep.id)
    _add_line(db_session, q.id, product, quantity=1, discount_pct=5.0)

    with pytest.raises(risk_engine.NoCeilingConfigured):
        risk_engine.score_quotation(db_session, q)
