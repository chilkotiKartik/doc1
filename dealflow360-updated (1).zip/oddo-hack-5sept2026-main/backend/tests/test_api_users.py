"""API-level tests for admin user-management (routers/users.py)."""


def _signup(client, email, name="Some User", password="hunter2"):
    """Signup always creates a Role.CUSTOMER account - just for existing in
    the user list, no login needed.
    """
    client.post("/api/auth/signup", json={"name": name, "email": email, "password": password})


def _signup_promote_and_login_as_rep(client, db_session, email, name="Some User", password="hunter2"):
    """A non-admin internal user, for testing the admin-only guard's 403."""
    from models.user import Role, User

    _signup(client, email, name, password)
    user = db_session.query(User).filter_by(email=email).one()
    user.role = Role.REP
    db_session.commit()
    return client.post("/api/auth/login", json={"email": email, "password": password}).json()["token"]


def _make_admin(client, db_session, email="admin@dealflow.test"):
    from models.user import Role, User

    client.post("/api/auth/signup", json={"name": "Ada Admin", "email": email, "password": "hunter2"})
    user = db_session.query(User).filter_by(email=email).one()
    user.role = Role.ADMIN
    db_session.commit()
    return client.post("/api/auth/login", json={"email": email, "password": "hunter2"}).json()["token"]


def test_admin_can_list_all_users(client, db_session):
    _signup(client, "cara@dealflow.test")
    admin_token = _make_admin(client, db_session)

    resp = client.get("/api/users", headers={"Authorization": f"Bearer {admin_token}"})

    assert resp.status_code == 200
    emails = {user["email"] for user in resp.json()}
    assert "cara@dealflow.test" in emails
    assert "admin@dealflow.test" in emails


def test_non_admin_cannot_list_users(client, db_session):
    token = _signup_promote_and_login_as_rep(client, db_session, "cara@dealflow.test")

    resp = client.get("/api/users", headers={"Authorization": f"Bearer {token}"})

    assert resp.status_code == 403


def test_admin_can_promote_a_customer_to_rep(client, db_session):
    signup_resp = client.post(
        "/api/auth/signup",
        json={"name": "Cara Customer", "email": "cara@dealflow.test", "password": "hunter2"},
    )
    user_id = signup_resp.json()["user"]["id"]
    admin_token = _make_admin(client, db_session)

    # Before promotion: login works fine (login is role-agnostic - see
    # test_api_auth.py), just returns role "customer".
    before = client.post("/api/auth/login", json={"email": "cara@dealflow.test", "password": "hunter2"})
    assert before.status_code == 200
    assert before.json()["user"]["role"] == "customer"

    resp = client.patch(
        f"/api/users/{user_id}/role",
        json={"role": "rep"},
        headers={"Authorization": f"Bearer {admin_token}"},
    )
    assert resp.status_code == 200
    assert resp.json()["role"] == "rep"

    # After promotion: same credentials now reflect the new role.
    after = client.post("/api/auth/login", json={"email": "cara@dealflow.test", "password": "hunter2"})
    assert after.status_code == 200
    assert after.json()["user"]["role"] == "rep"


def test_non_admin_cannot_change_a_role(client, db_session):
    token = _signup_promote_and_login_as_rep(client, db_session, "cara@dealflow.test")
    other_signup = client.post(
        "/api/auth/signup",
        json={"name": "Someone Else", "email": "other@dealflow.test", "password": "hunter2"},
    )
    other_id = other_signup.json()["user"]["id"]

    resp = client.patch(
        f"/api/users/{other_id}/role",
        json={"role": "rep"},
        headers={"Authorization": f"Bearer {token}"},
    )

    assert resp.status_code == 403


def test_admin_changing_role_of_unknown_user_returns_404(client, db_session):
    admin_token = _make_admin(client, db_session)

    resp = client.patch(
        "/api/users/9999/role",
        json={"role": "rep"},
        headers={"Authorization": f"Bearer {admin_token}"},
    )

    assert resp.status_code == 404
