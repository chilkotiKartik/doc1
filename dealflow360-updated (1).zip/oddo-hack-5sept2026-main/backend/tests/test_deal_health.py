from datetime import datetime, timedelta, timezone

import pytest

from models import Customer, DiscountTier, Product, ProductCategory, Quotation, QuotationLine, QuotationStatus, Role, User
from services import deal_health
from utils.security import hash_password


@pytest.fixture()
def base(db_session):
    rep = User(name="Rita", email="rita_dh@dealflow.test", password_hash=hash_password("x"), role=Role.REP)
    tier = DiscountTier(name="Gold", overall_ceiling_pct=15.0)
    category = ProductCategory(name="Hardware")
    db_session.add_all([rep, tier, category])
    db_session.commit()

    customer = Customer(name="Acme", tier_id=tier.id)
    product = Product(name="Laptop", category_id=category.id, unit_cost=800, list_price=1200)
    db_session.add_all([customer, product])
    db_session.commit()

    return {"rep": rep, "customer": customer, "product": product}


def _confirmed_quote_with_discount(db_session, base, discount_pct, days_ago=0):
    created = datetime.now(timezone.utc) - timedelta(days=days_ago)
    q = Quotation(
        customer_id=base["customer"].id,
        rep_id=base["rep"].id,
        status=QuotationStatus.CONFIRMED,
        created_at=created,
        updated_at=created,
    )
    db_session.add(q)
    db_session.commit()
    db_session.add(
        QuotationLine(quotation_id=q.id, product_id=base["product"].id, quantity=1, unit_price=1200, discount_pct=discount_pct)
    )
    db_session.commit()
    return q


def test_no_anomaly_with_consistent_discount_history(db_session, base):
    for _ in range(6):
        _confirmed_quote_with_discount(db_session, base, discount_pct=10.0)

    anomalies = deal_health.detect_discount_anomalies(db_session)

    assert anomalies == []


def test_flags_a_discount_far_outside_the_reps_own_history(db_session, base):
    # Rita's normal pattern: consistently around 8-10%.
    for pct in [8, 9, 10, 9, 8, 10]:
        _confirmed_quote_with_discount(db_session, base, discount_pct=pct)
    # Then one wildly different deal for the SAME rep.
    outlier = _confirmed_quote_with_discount(db_session, base, discount_pct=35.0)

    anomalies = deal_health.detect_discount_anomalies(db_session)

    assert len(anomalies) == 1
    assert anomalies[0].quotation_id == outlier.id
    assert anomalies[0].rep_name == "Rita"
    assert abs(anomalies[0].z_score) >= deal_health.ANOMALY_Z_THRESHOLD


def test_insufficient_history_does_not_flag_anything(db_session, base):
    # Only 2 past deals - below MIN_HISTORY_FOR_ANOMALY (4), so even a wild
    # swing shouldn't be trusted as a real anomaly yet.
    _confirmed_quote_with_discount(db_session, base, discount_pct=5.0)
    _confirmed_quote_with_discount(db_session, base, discount_pct=40.0)

    anomalies = deal_health.detect_discount_anomalies(db_session)

    assert anomalies == []


def test_stalled_deal_detection_flags_old_untouched_active_quotes(db_session, base):
    stalled = Quotation(
        customer_id=base["customer"].id,
        rep_id=base["rep"].id,
        status=QuotationStatus.PENDING_MANAGER,
        created_at=datetime.now(timezone.utc) - timedelta(days=10),
        updated_at=datetime.now(timezone.utc) - timedelta(days=10),
    )
    fresh = Quotation(
        customer_id=base["customer"].id,
        rep_id=base["rep"].id,
        status=QuotationStatus.DRAFT,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    db_session.add_all([stalled, fresh])
    db_session.commit()

    results = deal_health.detect_stalled_deals(db_session, stall_days=5)

    stalled_ids = [s.quotation_id for s in results]
    assert stalled.id in stalled_ids
    assert fresh.id not in stalled_ids


def test_confirmed_quotes_are_never_considered_stalled(db_session, base):
    old_but_confirmed = _confirmed_quote_with_discount(db_session, base, discount_pct=10.0, days_ago=20)

    results = deal_health.detect_stalled_deals(db_session, stall_days=5)

    assert all(s.quotation_id != old_but_confirmed.id for s in results)
