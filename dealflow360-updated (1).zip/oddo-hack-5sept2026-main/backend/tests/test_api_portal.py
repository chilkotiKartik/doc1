"""End-to-end tests for the customer negotiation loop (differentiator #2):
a customer counters a discount from the PORTAL, not the internal app, and
the exact same risk engine that scores a rep's edits re-scores it live -
auto-reopening approval with zero rep action if the counter breaches
thresholds.
"""

from models.user import Role
from tests.test_api_quotations import _auth, _setup_gold_catalog, _signup_and_promote


def _link_customer_portal_login(client, admin_token, customer_id, db_session, email, name):
    client.post("/api/auth/signup", json={"name": name, "email": email, "password": "hunter2"})
    from models.user import User

    user = db_session.query(User).filter_by(email=email).one()
    resp = client.patch(
        f"/api/customers/{customer_id}/link-portal-user?user_id={user.id}", headers=_auth(admin_token)
    )
    assert resp.status_code == 200
    login = client.post("/api/auth/login", json={"email": email, "password": "hunter2"})
    return login.json()["token"]


def test_portal_endpoints_reject_non_customer_roles(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin5@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep5@dealflow.test", Role.REP)

    resp = client.get("/api/portal/quotations", headers=_auth(rep_token))
    assert resp.status_code == 403

    resp = client.get("/api/portal/quotations", headers=_auth(admin_token))
    assert resp.status_code == 403


def test_customer_counter_offer_reenters_approval_automatically(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin6@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep6@dealflow.test", Role.REP)
    manager_token = _signup_and_promote(client, db_session, "Mark Manager", "manager6@dealflow.test", Role.MANAGER)
    catalog = _setup_gold_catalog(client, admin_token)
    customer_token = _link_customer_portal_login(
        client, admin_token, catalog["customer"]["id"], db_session, "buyer6@acme.test", "Buyer Six"
    )

    # Rep builds a clean quote (within limits) that auto-confirms with no
    # approval needed - this is the state a customer would actually see a
    # "Confirmed" quote link for.
    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()
    add_resp = client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["laptop"]["id"], "quantity": 1, "discount_pct": 10.0},
        headers=_auth(rep_token),
    ).json()
    line_id = add_resp["lines"][0]["id"]
    submitted = client.post(f"/api/quotations/{quote['id']}/submit", headers=_auth(rep_token)).json()
    assert submitted["status"] == "confirmed"
    assert submitted["routing"] == "none"

    # Customer sees it in their own portal.
    portal_list = client.get("/api/portal/quotations", headers=_auth(customer_token)).json()
    assert any(q["id"] == quote["id"] for q in portal_list)

    # Customer can't see or touch a DIFFERENT customer's data - not tested
    # here directly, but ownership is enforced by _get_owned_quotation.

    # Customer counters WAY past the Hardware ceiling (15%) from the
    # portal - this must land the quote right back in Manager's queue,
    # with the rep having done nothing.
    countered = client.post(
        f"/api/portal/quotations/{quote['id']}/counter",
        json={"line_id": line_id, "discount_pct": 20.0, "note": "need this to hit our budget"},
        headers=_auth(customer_token),
    ).json()

    assert countered["status"] == "pending_manager"
    assert countered["routing"] in ("manager", "manager_finance")
    assert countered["lines"][0]["discount_pct"] == 20.0
    assert countered["lines"][0]["overage_pts"] == 5.0  # 20% - 15% ceiling

    # It shows up in the Manager's queue exactly like a rep-triggered one.
    manager_queue = client.get("/api/quotations?pending_manager=true", headers=_auth(manager_token)).json()
    assert any(q["id"] == quote["id"] for q in manager_queue)

    # A rep cannot bypass this by editing internal endpoints while it's
    # under negotiation/pending - same draft-only guard as always.
    blocked = client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["setup_service"]["id"], "quantity": 1, "discount_pct": 5.0},
        headers=_auth(rep_token),
    )
    assert blocked.status_code == 409

    # Manager approves the customer's countered terms.
    approved = client.post(
        f"/api/quotations/{quote['id']}/approvals/manager",
        json={"decision": "approved"},
        headers=_auth(manager_token),
    ).json()
    assert approved["status"] in ("confirmed", "pending_finance")

    audit = client.get(f"/api/quotations/{quote['id']}/audit-log", headers=_auth(rep_token)).json()
    actions = [entry["action"] for entry in audit]
    assert "customer_countered" in actions
    assert "auto_reentered_approval" in actions


def test_customer_can_confirm_a_clean_quote_with_one_click(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin7@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep7@dealflow.test", Role.REP)
    catalog = _setup_gold_catalog(client, admin_token)
    customer_token = _link_customer_portal_login(
        client, admin_token, catalog["customer"]["id"], db_session, "buyer7@acme.test", "Buyer Seven"
    )

    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()
    client.post(
        f"/api/quotations/{quote['id']}/lines",
        json={"product_id": catalog["laptop"]["id"], "quantity": 1, "discount_pct": 5.0},
        headers=_auth(rep_token),
    )
    client.post(f"/api/quotations/{quote['id']}/submit", headers=_auth(rep_token))

    confirmed = client.post(f"/api/portal/quotations/{quote['id']}/confirm", headers=_auth(customer_token)).json()
    assert confirmed["customer_confirmed_at"] is not None


def test_customer_cannot_access_another_customers_quotation(client, db_session):
    admin_token = _signup_and_promote(client, db_session, "Ada Admin", "admin8@dealflow.test", Role.ADMIN)
    rep_token = _signup_and_promote(client, db_session, "Rita Rep", "rep8@dealflow.test", Role.REP)
    catalog = _setup_gold_catalog(client, admin_token)

    # A second, unrelated customer + portal login.
    other_customer = client.post(
        "/api/customers", json={"name": "Other Corp", "tier_id": catalog["gold"]["id"]}, headers=_auth(admin_token)
    ).json()
    stranger_token = _link_customer_portal_login(
        client, admin_token, other_customer["id"], db_session, "stranger@other.test", "Stranger"
    )

    quote = client.post(
        "/api/quotations", json={"customer_id": catalog["customer"]["id"]}, headers=_auth(rep_token)
    ).json()

    resp = client.get(f"/api/portal/quotations/{quote['id']}", headers=_auth(stranger_token))
    assert resp.status_code == 403
