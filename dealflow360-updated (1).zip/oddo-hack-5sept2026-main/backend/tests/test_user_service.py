import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session as DBSession

from models import Base
from models.user import Role, User
from services import user_service
from utils.security import hash_password


@pytest.fixture()
def session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with DBSession(engine) as session:
        yield session


@pytest.fixture()
def customer_user(session):
    user = User(
        name="Cara Customer",
        email="cara@dealflow.test",
        password_hash=hash_password("hunter2"),
        role=Role.CUSTOMER,
    )
    session.add(user)
    session.commit()
    return user


def test_list_all_users_returns_every_role(session, customer_user):
    session.add(
        User(name="Ada Admin", email="admin@dealflow.test", password_hash=hash_password("x"), role=Role.ADMIN)
    )
    session.commit()

    users = user_service.list_all_users(session)

    emails = {user.email for user in users}
    assert emails == {"cara@dealflow.test", "admin@dealflow.test"}


def test_change_user_role_promotes_customer_to_rep(session, customer_user):
    updated = user_service.change_user_role(session, customer_user.id, Role.REP)

    assert updated.role == Role.REP


def test_change_user_role_can_demote_back_to_customer(session, customer_user):
    user_service.change_user_role(session, customer_user.id, Role.ADMIN)

    demoted = user_service.change_user_role(session, customer_user.id, Role.CUSTOMER)

    assert demoted.role == Role.CUSTOMER


def test_change_user_role_with_unknown_id_raises(session):
    with pytest.raises(user_service.UserNotFound):
        user_service.change_user_role(session, 9999, Role.REP)
