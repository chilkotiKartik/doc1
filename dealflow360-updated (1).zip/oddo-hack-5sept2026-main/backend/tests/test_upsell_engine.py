import pytest

from models import Customer, DiscountTier, Product, ProductCategory, Quotation, QuotationLine, QuotationStatus, Role, User
from services import upsell_engine
from utils.security import hash_password


@pytest.fixture()
def catalog(db_session):
    rep = User(name="Rita", email="rita_up@dealflow.test", password_hash=hash_password("x"), role=Role.REP)
    tier = DiscountTier(name="Gold", overall_ceiling_pct=15.0)
    hardware = ProductCategory(name="Hardware")
    db_session.add_all([rep, tier, hardware])
    db_session.commit()

    customer = Customer(name="Acme", tier_id=tier.id)
    laptop = Product(name="Laptop", category_id=hardware.id, unit_cost=800, list_price=1200)  # 33% margin
    docking = Product(name="Docking Station", category_id=hardware.id, unit_cost=30, list_price=60)  # 50% margin
    cheap_cable = Product(name="Cheap Cable", category_id=hardware.id, unit_cost=18, list_price=20)  # 10% margin - below gate
    mouse = Product(name="Mouse", category_id=hardware.id, unit_cost=10, list_price=25)  # filler, unrelated basket
    db_session.add_all([customer, laptop, docking, cheap_cable, mouse])
    db_session.commit()

    return {"rep": rep, "customer": customer, "laptop": laptop, "docking": docking, "cheap_cable": cheap_cable, "mouse": mouse}


def _confirmed_order(db_session, catalog, product_ids):
    q = Quotation(customer_id=catalog["customer"].id, rep_id=catalog["rep"].id, status=QuotationStatus.CONFIRMED)
    db_session.add(q)
    db_session.commit()
    for pid in product_ids:
        product = db_session.get(Product, pid)
        db_session.add(QuotationLine(quotation_id=q.id, product_id=pid, quantity=1, unit_price=product.list_price, discount_pct=0))
    db_session.commit()
    return q


def test_no_history_returns_no_suggestions(db_session, catalog):
    suggestions = upsell_engine.suggest_cross_sell(db_session, [catalog["laptop"].id])
    assert suggestions == []


def test_frequently_co_bought_healthy_margin_product_is_suggested(db_session, catalog):
    # Laptop + Docking Station bought together 3 times historically.
    for _ in range(3):
        _confirmed_order(db_session, catalog, [catalog["laptop"].id, catalog["docking"].id])
    # Unrelated baskets (no laptop, no docking) dilute docking's overall
    # baseline popularity, so its co-occurrence WITH laptop specifically
    # is genuinely more than chance - this is what makes lift > 1 real
    # rather than a mechanical artifact of a too-small dataset.
    for _ in range(3):
        _confirmed_order(db_session, catalog, [catalog["mouse"].id, catalog["cheap_cable"].id])

    suggestions = upsell_engine.suggest_cross_sell(db_session, [catalog["laptop"].id])

    assert len(suggestions) == 1
    assert suggestions[0].product_name == "Docking Station"
    assert suggestions[0].lift == 2.0  # confidence 3/3=1.0 over baseline 3/6=0.5
    assert suggestions[0].co_occurrence_count == 3
    assert suggestions[0].margin_pct == 50.0


def test_low_margin_product_is_gated_out_even_if_frequently_co_bought(db_session, catalog):
    # Cheap Cable co-occurs with Laptop constantly, but its margin (10%)
    # is below MIN_MARGIN_PCT (15%) - it must never surface.
    for _ in range(5):
        _confirmed_order(db_session, catalog, [catalog["laptop"].id, catalog["cheap_cable"].id])

    suggestions = upsell_engine.suggest_cross_sell(db_session, [catalog["laptop"].id])

    assert all(s.product_name != "Cheap Cable" for s in suggestions)


def test_already_selected_products_are_never_suggested_again(db_session, catalog):
    for _ in range(3):
        _confirmed_order(db_session, catalog, [catalog["laptop"].id, catalog["docking"].id])

    suggestions = upsell_engine.suggest_cross_sell(db_session, [catalog["laptop"].id, catalog["docking"].id])

    assert all(s.product_id != catalog["docking"].id for s in suggestions)


def test_below_min_support_count_is_excluded(db_session, catalog):
    # Only co-occurs once - below MIN_SUPPORT_COUNT (2).
    _confirmed_order(db_session, catalog, [catalog["laptop"].id, catalog["docking"].id])

    suggestions = upsell_engine.suggest_cross_sell(db_session, [catalog["laptop"].id])

    assert suggestions == []
