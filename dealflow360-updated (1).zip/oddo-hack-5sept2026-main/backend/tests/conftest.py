import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from models import Base


@pytest.fixture()
def test_db():
    """The shared in-memory engine + sessionmaker backing both `client` (via
    the app's dependency override) and `db_session` (direct access, for test
    setup that doesn't have an HTTP endpoint - e.g. approving a user without
    needing a pre-approved admin to call the approve endpoint).
    """
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    yield sessionmaker(bind=engine, autoflush=False, autocommit=False)


@pytest.fixture()
def db_session(test_db):
    session = test_db()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def client(test_db):
    from main import app
    from routers.deps import get_session

    def override_get_session():
        session = test_db()
        try:
            yield session
        finally:
            session.close()

    app.dependency_overrides[get_session] = override_get_session

    with TestClient(app) as test_client:
        yield test_client

    app.dependency_overrides.clear()
