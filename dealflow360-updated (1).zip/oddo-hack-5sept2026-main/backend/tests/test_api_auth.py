"""API-level tests for the unified auth endpoints (routers/auth.py).
There is no internal/customer split anymore - one set of endpoints,
any role. Shared `client`/`db_session` fixtures are in conftest.py.
"""

from models.user import Role, User


def _promote(db_session, email: str, role: Role) -> None:
    """Every signup creates a Role.CUSTOMER account - this simulates an
    admin promoting one afterward, without going through the full
    admin-login + PATCH /api/users/{id}/role flow (that flow is tested
    end-to-end in test_api_users.py).
    """
    user = db_session.query(User).filter_by(email=email).one()
    user.role = role
    db_session.commit()


def test_signup_creates_user_and_returns_token(client):
    resp = client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert "token" in body
    assert body["user"]["email"] == "rita@dealflow.test"
    assert body["user"]["role"] == "customer"


def test_signup_ignores_a_role_field_if_sent(client):
    # SignupRequest has no `role` field at all - pydantic drops unknown
    # fields by default, so sending one doesn't error, and the created
    # user is still forced to Role.CUSTOMER server-side.
    resp = client.post(
        "/api/auth/signup",
        json={"name": "Sneaky", "email": "sneaky@dealflow.test", "password": "hunter2", "role": "admin"},
    )
    assert resp.status_code == 201
    assert resp.json()["user"]["role"] == "customer"


def test_signup_with_duplicate_email_returns_409(client):
    payload = {"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"}
    client.post("/api/auth/signup", json=payload)

    resp = client.post("/api/auth/signup", json=payload)

    assert resp.status_code == 409


def test_login_with_correct_credentials_returns_token(client):
    client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    )

    resp = client.post("/api/auth/login", json={"email": "rita@dealflow.test", "password": "hunter2"})

    assert resp.status_code == 200
    assert "token" in resp.json()


def test_login_works_regardless_of_role(client, db_session):
    """Login is role-agnostic - there's no separate internal/customer login
    to reject the "wrong" audience anymore. Whatever role the account has,
    login returns a token reflecting it; restriction happens per-endpoint
    (see test_api_users.py's admin-only checks), not at login.
    """
    client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    )
    _promote(db_session, "rita@dealflow.test", Role.ADMIN)

    resp = client.post("/api/auth/login", json={"email": "rita@dealflow.test", "password": "hunter2"})

    assert resp.status_code == 200
    assert resp.json()["user"]["role"] == "admin"


def test_login_with_wrong_password_returns_401(client):
    client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    )

    resp = client.post("/api/auth/login", json={"email": "rita@dealflow.test", "password": "wrong"})

    assert resp.status_code == 401


def test_login_with_unknown_email_returns_401(client):
    resp = client.post("/api/auth/login", json={"email": "nobody@dealflow.test", "password": "whatever"})
    assert resp.status_code == 401


def test_me_with_valid_token_returns_current_user(client):
    token = client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    ).json()["token"]

    resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})

    assert resp.status_code == 200
    assert resp.json()["email"] == "rita@dealflow.test"


def test_me_without_token_returns_401(client):
    resp = client.get("/api/auth/me")
    assert resp.status_code == 401


def test_me_with_garbage_token_returns_401(client):
    resp = client.get("/api/auth/me", headers={"Authorization": "Bearer not-a-real-jwt"})
    assert resp.status_code == 401


def test_logout_revokes_the_token(client):
    token = client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    ).json()["token"]

    logout_resp = client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token}"})
    assert logout_resp.status_code == 204

    me_resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert me_resp.status_code == 401


def test_logout_without_token_returns_401(client):
    resp = client.post("/api/auth/logout")
    assert resp.status_code == 401


def test_logout_with_garbage_token_returns_401(client):
    resp = client.post("/api/auth/logout", headers={"Authorization": "Bearer not-a-real-jwt"})
    assert resp.status_code == 401


def test_logout_an_already_revoked_token_returns_401(client):
    token = client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    ).json()["token"]
    client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token}"})

    resp = client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token}"})

    assert resp.status_code == 401


def test_logout_does_not_revoke_a_different_token_for_the_same_user(client):
    client.post(
        "/api/auth/signup",
        json={"name": "Rita Rep", "email": "rita@dealflow.test", "password": "hunter2"},
    )
    token_a = client.post(
        "/api/auth/login", json={"email": "rita@dealflow.test", "password": "hunter2"}
    ).json()["token"]
    token_b = client.post(
        "/api/auth/login", json={"email": "rita@dealflow.test", "password": "hunter2"}
    ).json()["token"]

    client.post("/api/auth/logout", headers={"Authorization": f"Bearer {token_a}"})

    resp = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token_b}"})
    assert resp.status_code == 200
