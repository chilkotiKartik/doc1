from sqlalchemy import String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class ProductCategory(Base):
    """A product grouping (Hardware, Services, Software/Subscriptions, ...).

    This is what CategoryCeiling keys off - "Gold customers get up to 15% off
    Hardware but only 10% off Services" needs a stable category identity, not
    a free-text string repeated on every product.
    """

    __tablename__ = "product_categories"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
