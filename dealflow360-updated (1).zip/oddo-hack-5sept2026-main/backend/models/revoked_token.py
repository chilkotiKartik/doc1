from datetime import datetime

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class RevokedToken(Base):
    """A logged-out token's jti, kept only until its own natural expiry -
    after that it would be rejected anyway, so a row past expires_at is
    safe to delete (no cleanup job exists yet; the table just grows slowly
    until one is added).
    """

    __tablename__ = "revoked_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)
    jti: Mapped[str] = mapped_column(String(36), unique=True, nullable=False, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
