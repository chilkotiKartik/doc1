from datetime import datetime
from enum import Enum

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy import Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class ApprovalLevel(str, Enum):
    MANAGER = "manager"
    FINANCE = "finance"


class ApprovalStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    RETURNED = "returned"  # sent back to the rep for revision


class ApprovalStep(Base):
    """One required approval step for a quotation. The risk engine decides
    *which* steps get created (services/quotation_service.route_for_approval)
    - a quotation that clears with no risk has zero rows here at all, which
    is itself the "no approval needed" signal, rather than a status flag
    that could drift out of sync with reality.
    """

    __tablename__ = "approval_steps"

    id: Mapped[int] = mapped_column(primary_key=True)
    quotation_id: Mapped[int] = mapped_column(ForeignKey("quotations.id"), nullable=False)
    level: Mapped[ApprovalLevel] = mapped_column(
        SAEnum(ApprovalLevel, values_callable=lambda enum_cls: [m.value for m in enum_cls]),
        nullable=False,
    )
    status: Mapped[ApprovalStatus] = mapped_column(
        SAEnum(ApprovalStatus, values_callable=lambda enum_cls: [m.value for m in enum_cls]),
        nullable=False,
        default=ApprovalStatus.PENDING,
    )
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    reason: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    acted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
