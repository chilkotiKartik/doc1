from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class Customer(Base):
    """The buying account (a company), distinct from `User`. A Customer has
    a discount tier; a portal-side `User` (role=customer) is the login that
    a specific person at that company uses to see and negotiate quotations.

    `portal_user_id` is nullable and optional on purpose: a Customer can
    exist (created by Admin/Rep while building a quotation) before anyone
    at that company has ever logged into the portal.
    """

    __tablename__ = "customers"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    tier_id: Mapped[int] = mapped_column(ForeignKey("discount_tiers.id"), nullable=False)
    portal_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
