from sqlalchemy import Float, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class QuotationLine(Base):
    """One product line on a quotation. `unit_price` is snapshotted from the
    product's list_price at the time the line is added/edited - so a later
    catalog price change never silently rewrites a quote a customer already
    saw.

    `overage_pts` and `risk_contribution` are written by
    services/risk_engine.score_quotation() every time the quote is
    recomputed - they are the per-line proof behind the quotation's overall
    blended_risk_score, not independently editable.

    Float, not Numeric - see models/product.py's docstring for why.
    """

    __tablename__ = "quotation_lines"

    id: Mapped[int] = mapped_column(primary_key=True)
    quotation_id: Mapped[int] = mapped_column(ForeignKey("quotations.id"), nullable=False)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), nullable=False)
    quantity: Mapped[int] = mapped_column(nullable=False, default=1)
    unit_price: Mapped[float] = mapped_column(Float, nullable=False)
    discount_pct: Mapped[float] = mapped_column(Float, nullable=False, default=0)

    # Written by the risk engine on every recompute - not user-editable.
    overage_pts: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    risk_contribution: Mapped[float] = mapped_column(Float, nullable=False, default=0)
