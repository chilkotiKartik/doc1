from sqlalchemy import Float, String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class Warehouse(Base):
    """`shipping_weight` is a relative cost factor (lower = cheaper to ship
    from), used by the greedy allocator to prefer cheaper warehouses first
    when splitting an order - see services/warehouse_split.py.
    """

    __tablename__ = "warehouses"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, nullable=False)
    shipping_weight: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)
