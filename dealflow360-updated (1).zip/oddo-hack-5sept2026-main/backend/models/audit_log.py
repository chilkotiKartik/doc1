from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class AuditLog(Base):
    """Append-only history of every state-changing action on a quotation
    (line added, submitted, approved, rejected, returned). Nothing ever
    updates or deletes a row here - services/quotation_service.py only ever
    inserts. This is what backs the "who did what, when, and why" trail the
    brief requires; it is deliberately its own table rather than reusing
    ApprovalStep, because not every logged action is an approval decision
    (e.g. "line added" has no approver).
    """

    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    quotation_id: Mapped[int] = mapped_column(ForeignKey("quotations.id"), nullable=False)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(80), nullable=False)
    details: Mapped[str | None] = mapped_column(String(2000), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
