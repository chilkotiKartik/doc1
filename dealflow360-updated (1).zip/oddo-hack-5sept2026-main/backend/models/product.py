from sqlalchemy import Float, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class Product(Base):
    """A sellable item. `unit_cost` + `list_price` are what let the risk
    engine and margin displays compute margin without guessing - both are
    required, not optional, because "what's the margin on this line" is a
    core feature, not an afterthought.

    Money/percentage fields use Float, not Numeric - Numeric round-trips as
    `decimal.Decimal` even under SQLite (asdecimal defaults to True), which
    would force every arithmetic line in the risk engine to mix Decimal and
    float. Float-precision cents are an acceptable tradeoff for a
    governance *score*, not a ledger of record.

    `is_subscription` marks recurring-billing products (handled by a later
    billing module); it's on the model now so quotation lines can already
    tell one-time and recurring lines apart.
    """

    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    category_id: Mapped[int] = mapped_column(ForeignKey("product_categories.id"), nullable=False)
    unit_cost: Mapped[float] = mapped_column(Float, nullable=False)
    list_price: Mapped[float] = mapped_column(Float, nullable=False)
    is_subscription: Mapped[bool] = mapped_column(default=False, nullable=False)
