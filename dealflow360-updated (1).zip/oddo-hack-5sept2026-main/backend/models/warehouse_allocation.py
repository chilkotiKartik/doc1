from sqlalchemy import Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class WarehouseAllocation(Base):
    """One row per (warehouse, product) chunk of a quotation's fulfillment
    plan, written once a rep/finance user accepts a suggested split (see
    services/warehouse_split.py's `accept_allocation`). `is_backorder=True`
    rows have `warehouse_id=None` - quantity that couldn't be filled from
    any warehouse's current stock.
    """

    __tablename__ = "warehouse_allocations"

    id: Mapped[int] = mapped_column(primary_key=True)
    quotation_id: Mapped[int] = mapped_column(ForeignKey("quotations.id"), nullable=False)
    quotation_line_id: Mapped[int] = mapped_column(ForeignKey("quotation_lines.id"), nullable=False)
    warehouse_id: Mapped[int | None] = mapped_column(ForeignKey("warehouses.id"), nullable=True)
    product_id: Mapped[int] = mapped_column(ForeignKey("products.id"), nullable=False)
    quantity: Mapped[int] = mapped_column(nullable=False)
    is_backorder: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
