from datetime import datetime, timezone
from enum import Enum

from sqlalchemy import DateTime, Float, ForeignKey, String
from sqlalchemy import Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class QuotationStatus(str, Enum):
    DRAFT = "draft"
    PENDING_MANAGER = "pending_manager"
    PENDING_FINANCE = "pending_finance"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    UNDER_NEGOTIATION = "under_negotiation"  # customer has countered; re-scoring in progress
    # Extended by later modules: fulfilling, billed.


class Quotation(Base):
    """One quote. `blended_risk_score` and `risk_breakdown` are always kept
    in sync with the current lines by services/risk_engine.py - they are
    never computed lazily in a router or trusted to be stale; every mutation
    to a line (by a rep OR by a customer counter-offer) goes through
    quotation_service, which recomputes both before returning.

    `risk_breakdown` is a JSON string (not a separate table) - it's a
    denormalized, human-readable explanation of *why* the current score is
    what it is (see risk_engine.score_quotation), read far more often than
    it's written, and never queried by its contents.

    `customer_confirmed_at` is separate from `status` on purpose: a
    quotation reaches CONFIRMED once internal approval clears, but the
    customer's own one-click "Confirm Quotation" (see routers/portal.py)
    is a distinct event worth its own timestamp, not just another status
    value - and it's cleared back to None the moment a new counter-offer
    is submitted, since a fresh counter means the customer hasn't actually
    confirmed these new terms yet.
    """

    __tablename__ = "quotations"

    id: Mapped[int] = mapped_column(primary_key=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), nullable=False)
    rep_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    status: Mapped[QuotationStatus] = mapped_column(
        SAEnum(QuotationStatus, values_callable=lambda enum_cls: [m.value for m in enum_cls]),
        nullable=False,
        default=QuotationStatus.DRAFT,
    )
    blended_risk_score: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    risk_breakdown: Mapped[str] = mapped_column(String, nullable=False, default="[]")
    customer_confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )
