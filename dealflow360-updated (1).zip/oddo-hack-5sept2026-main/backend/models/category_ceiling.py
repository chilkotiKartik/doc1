from sqlalchemy import Float, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class CategoryCeiling(Base):
    """The actual rule the risk engine checks every quotation line against:
    "for this tier, this category, the max discount is X%." One row per
    (tier, category) pair - admin-editable data, not a hardcoded constant,
    so changing "Gold Services ceiling from 10% to 12%" is a data update,
    not a code change.

    `margin_weight` scales how heavily an overage on this category counts
    toward the blended (cumulative) score - a category with thinner margins
    (Services) should weigh more than one with healthy margins (Hardware),
    so the same number of overage points hurts the score more where it
    actually hurts the business more.
    """

    __tablename__ = "category_ceilings"
    __table_args__ = (UniqueConstraint("tier_id", "category_id", name="uq_ceiling_tier_category"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    tier_id: Mapped[int] = mapped_column(ForeignKey("discount_tiers.id"), nullable=False)
    category_id: Mapped[int] = mapped_column(ForeignKey("product_categories.id"), nullable=False)
    max_discount_pct: Mapped[float] = mapped_column(Float, nullable=False)
    margin_weight: Mapped[float] = mapped_column(Float, nullable=False, default=1.0)
