from sqlalchemy import Float, String
from sqlalchemy.orm import Mapped, mapped_column

from models.base import Base


class DiscountTier(Base):
    """A customer tier (Bronze/Silver/Gold, ...). `overall_ceiling_pct` is
    kept for display/reference ("Gold = up to 15% on paper") but the risk
    engine never checks a line against this directly - it always looks up
    the tier+category-specific ceiling in CategoryCeiling instead. This is
    the field that matters for the "18% on a Service line still breaks its
    own limit even though the customer is Gold" scenario the brief
    describes.
    """

    __tablename__ = "discount_tiers"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    overall_ceiling_pct: Mapped[float] = mapped_column(Float, nullable=False)
