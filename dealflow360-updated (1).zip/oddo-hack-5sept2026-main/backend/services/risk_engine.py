"""The Blended Discount Risk Engine - the product's core differentiator.

Two checks, both required by the brief, both usually collapsed into a
single `if discount > X` check by simpler tools:

1. Per-line ceiling breach: every line is checked against its OWN
   category's ceiling for the customer's tier - not one order-wide limit.
   A Gold customer's order can still get flagged by one Service line even
   though 15% "sounds fine" for Gold on paper, because Services has its own
   stricter 10% ceiling.

2. Cumulative aggregate pattern: every line's overage (however small) is
   weighted by that category's margin sensitivity and its share of the
   order's value, then summed - so several lines that are each only a
   little over their own ceiling (2-3 points each) can still push the
   order into approval even though no single line looks alarming alone.

Deterministic on purpose (see ARCHITECTURE.md): a governance engine has to
be auditable line-by-line, not a black box a Finance approver has to trust
blindly. No ML lives here.
"""

from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.category_ceiling import CategoryCeiling
from models.customer import Customer
from models.product import Product
from models.product_category import ProductCategory
from models.quotation import Quotation
from models.quotation_line import QuotationLine

# Tunable governance constants. These are the exact numbers used in the
# worked example across every planning doc (Gold tier, Hardware 15%,
# Services 10%, an 18%-discounted Service line, several 2-3pt overages
# elsewhere) - kept as named constants here rather than admin-editable rows
# because "make ceilings/bands editable in an Admin screen" is explicitly a
# later module's scope, not this one's.
SINGLE_LINE_HARD_FLAG_PTS = 5.0
MANAGER_ONLY_SCORE_THRESHOLD = 3.0
FINANCE_SCORE_THRESHOLD = 10.0

ROUTING_NONE = "none"
ROUTING_MANAGER = "manager"
ROUTING_MANAGER_FINANCE = "manager_finance"


class NoCeilingConfigured(Exception):
    """Raised when a (tier, category) pair has no CategoryCeiling row - a
    data-setup gap, not a discount problem. Surfaced loudly: silently
    treating "no rule configured" as "no limit" would let anything through,
    which is the exact failure mode this engine exists to prevent.
    """


@dataclass(frozen=True)
class LineRiskResult:
    quotation_line_id: int
    product_name: str
    category_name: str
    discount_pct: float
    ceiling_pct: float
    overage_pts: float
    risk_contribution: float
    hard_flag: bool


@dataclass(frozen=True)
class RiskAssessment:
    blended_score: float
    hard_flag: bool
    routing: str  # ROUTING_NONE | ROUTING_MANAGER | ROUTING_MANAGER_FINANCE
    lines: list[LineRiskResult] = field(default_factory=list)


def _get_ceiling(session: DBSession, tier_id: int, category_id: int) -> CategoryCeiling:
    ceiling = session.execute(
        select(CategoryCeiling).where(
            CategoryCeiling.tier_id == tier_id, CategoryCeiling.category_id == category_id
        )
    ).scalar_one_or_none()
    if ceiling is None:
        raise NoCeilingConfigured(
            f"No discount ceiling configured for tier_id={tier_id}, category_id={category_id}"
        )
    return ceiling


def _route(blended_score: float, hard_flag: bool) -> str:
    if hard_flag or blended_score > FINANCE_SCORE_THRESHOLD:
        return ROUTING_MANAGER_FINANCE
    if blended_score > MANAGER_ONLY_SCORE_THRESHOLD:
        return ROUTING_MANAGER
    return ROUTING_NONE


def score_quotation(session: DBSession, quotation: Quotation) -> RiskAssessment:
    """Compute the blended risk assessment for every current line on
    `quotation`. Pure computation over the DB state - does NOT write
    anything back to the quotation or its lines; that persistence step
    belongs to quotation_service (see apply_risk_assessment), so this
    function stays trivially unit-testable against an in-memory session
    with no HTTP or ORM-mutation concerns involved.
    """
    lines = list(
        session.execute(
            select(QuotationLine).where(QuotationLine.quotation_id == quotation.id)
        ).scalars()
    )
    if not lines:
        return RiskAssessment(blended_score=0.0, hard_flag=False, routing=ROUTING_NONE, lines=[])

    customer = session.get(Customer, quotation.customer_id)

    def line_net_value(ln: QuotationLine) -> float:
        return ln.unit_price * ln.quantity * (1 - ln.discount_pct / 100)

    order_value = sum(line_net_value(ln) for ln in lines)
    # Guard against an all-zero-price order dividing by zero; such an order
    # has no meaningful margin risk to weight against anyway.
    order_value = order_value if order_value > 0 else 1.0

    results: list[LineRiskResult] = []
    overall_hard_flag = False
    blended_score = 0.0

    for line in lines:
        product = session.get(Product, line.product_id)
        category = session.get(ProductCategory, product.category_id)
        ceiling = _get_ceiling(session, customer.tier_id, product.category_id)

        overage = max(0.0, line.discount_pct - ceiling.max_discount_pct)
        risk_contribution = overage * ceiling.margin_weight * (line_net_value(line) / order_value)
        line_hard_flag = overage > SINGLE_LINE_HARD_FLAG_PTS

        overall_hard_flag = overall_hard_flag or line_hard_flag
        blended_score += risk_contribution

        results.append(
            LineRiskResult(
                quotation_line_id=line.id,
                product_name=product.name,
                category_name=category.name,
                discount_pct=line.discount_pct,
                ceiling_pct=ceiling.max_discount_pct,
                overage_pts=round(overage, 2),
                risk_contribution=round(risk_contribution, 2),
                hard_flag=line_hard_flag,
            )
        )

    blended_score = round(blended_score, 2)
    return RiskAssessment(
        blended_score=blended_score,
        hard_flag=overall_hard_flag,
        routing=_route(blended_score, overall_hard_flag),
        lines=results,
    )
