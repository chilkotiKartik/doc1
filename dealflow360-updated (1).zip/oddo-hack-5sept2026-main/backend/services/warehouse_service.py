from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.stock_level import StockLevel
from models.warehouse import Warehouse
from services import catalog_service


class WarehouseNotFound(Exception):
    pass


class DuplicateWarehouseName(Exception):
    pass


def create_warehouse(session: DBSession, name: str, shipping_weight: float = 1.0) -> Warehouse:
    existing = session.execute(select(Warehouse).where(Warehouse.name == name)).scalar_one_or_none()
    if existing is not None:
        raise DuplicateWarehouseName(f"Warehouse '{name}' already exists")
    warehouse = Warehouse(name=name, shipping_weight=shipping_weight)
    session.add(warehouse)
    session.commit()
    session.refresh(warehouse)
    return warehouse


def list_warehouses(session: DBSession) -> list[Warehouse]:
    return list(session.execute(select(Warehouse).order_by(Warehouse.shipping_weight.asc())).scalars())


def get_warehouse(session: DBSession, warehouse_id: int) -> Warehouse:
    warehouse = session.get(Warehouse, warehouse_id)
    if warehouse is None:
        raise WarehouseNotFound(f"No warehouse with id {warehouse_id}")
    return warehouse


def set_stock_level(session: DBSession, warehouse_id: int, product_id: int, quantity: int) -> StockLevel:
    """Create-or-update, same pattern as governance_service.set_category_ceiling
    - re-setting stock for the same (warehouse, product) pair updates it,
    since that's a normal restock/count-correction operation.
    """
    get_warehouse(session, warehouse_id)
    catalog_service.get_product(session, product_id)

    existing = session.execute(
        select(StockLevel).where(StockLevel.warehouse_id == warehouse_id, StockLevel.product_id == product_id)
    ).scalar_one_or_none()
    if existing is not None:
        existing.quantity = quantity
        session.commit()
        session.refresh(existing)
        return existing

    stock = StockLevel(warehouse_id=warehouse_id, product_id=product_id, quantity=quantity)
    session.add(stock)
    session.commit()
    session.refresh(stock)
    return stock


def list_stock(session: DBSession, warehouse_id: int | None = None) -> list[StockLevel]:
    stmt = select(StockLevel)
    if warehouse_id is not None:
        stmt = stmt.where(StockLevel.warehouse_id == warehouse_id)
    return list(session.execute(stmt).scalars())
