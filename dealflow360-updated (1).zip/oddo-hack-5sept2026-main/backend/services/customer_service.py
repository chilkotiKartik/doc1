"""Customer (buying account) management. Distinct from the User/auth model -
see models/customer.py's docstring.
"""

from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.customer import Customer
from services import governance_service


class CustomerNotFound(Exception):
    pass


class NoLinkedCustomerAccount(Exception):
    """A portal (role=customer) User exists but isn't linked to any
    Customer (buying account) yet - distinct from CustomerNotFound so
    routers/portal.py can return a clear "not set up yet" message instead
    of a generic 404.
    """


@dataclass(frozen=True)
class CustomerView:
    id: int
    name: str
    tier_id: int
    tier_name: str


def create_customer(session: DBSession, name: str, tier_id: int) -> Customer:
    governance_service.get_tier(session, tier_id)  # raises TierNotFound if invalid
    customer = Customer(name=name, tier_id=tier_id)
    session.add(customer)
    session.commit()
    session.refresh(customer)
    return customer


def get_customer(session: DBSession, customer_id: int) -> Customer:
    customer = session.get(Customer, customer_id)
    if customer is None:
        raise CustomerNotFound(f"No customer with id {customer_id}")
    return customer


def get_customer_view(session: DBSession, customer_id: int) -> CustomerView:
    customer = get_customer(session, customer_id)
    tier = governance_service.get_tier(session, customer.tier_id)
    return CustomerView(id=customer.id, name=customer.name, tier_id=tier.id, tier_name=tier.name)


def list_customers(session: DBSession) -> list[CustomerView]:
    customers = list(session.execute(select(Customer)).scalars())
    return [get_customer_view(session, c.id) for c in customers]


def link_portal_user(session: DBSession, customer_id: int, user_id: int) -> Customer:
    """Admin action: attach a portal login to a buying account, so that
    login can see and negotiate that account's quotations. One customer
    can have at most one linked portal user in this model (a real B2B
    account with multiple named contacts is a real future extension, not
    something the hackathon scope needs).
    """
    customer = get_customer(session, customer_id)
    customer.portal_user_id = user_id
    session.commit()
    session.refresh(customer)
    return customer


def get_customer_by_portal_user(session: DBSession, user_id: int) -> Customer:
    customer = session.execute(select(Customer).where(Customer.portal_user_id == user_id)).scalar_one_or_none()
    if customer is None:
        raise NoLinkedCustomerAccount(f"User {user_id} is not linked to any customer account yet")
    return customer
