"""Admin-facing catalog management: product categories and products. Plain
CRUD - the interesting logic (what a category's discount ceiling is) lives
in services/governance_service.py, not here.
"""

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.product import Product
from models.product_category import ProductCategory


class CategoryNotFound(Exception):
    pass


class ProductNotFound(Exception):
    pass


class DuplicateCategoryName(Exception):
    pass


def create_category(session: DBSession, name: str) -> ProductCategory:
    existing = session.execute(
        select(ProductCategory).where(ProductCategory.name == name)
    ).scalar_one_or_none()
    if existing is not None:
        raise DuplicateCategoryName(f"Category '{name}' already exists")
    category = ProductCategory(name=name)
    session.add(category)
    session.commit()
    session.refresh(category)
    return category


def list_categories(session: DBSession) -> list[ProductCategory]:
    return list(session.execute(select(ProductCategory)).scalars())


def get_category(session: DBSession, category_id: int) -> ProductCategory:
    category = session.get(ProductCategory, category_id)
    if category is None:
        raise CategoryNotFound(f"No category with id {category_id}")
    return category


def create_product(
    session: DBSession,
    name: str,
    category_id: int,
    unit_cost: float,
    list_price: float,
    is_subscription: bool = False,
) -> Product:
    get_category(session, category_id)  # raises CategoryNotFound if invalid
    product = Product(
        name=name,
        category_id=category_id,
        unit_cost=unit_cost,
        list_price=list_price,
        is_subscription=is_subscription,
    )
    session.add(product)
    session.commit()
    session.refresh(product)
    return product


def list_products(session: DBSession) -> list[Product]:
    return list(session.execute(select(Product)).scalars())


def get_product(session: DBSession, product_id: int) -> Product:
    product = session.get(Product, product_id)
    if product is None:
        raise ProductNotFound(f"No product with id {product_id}")
    return product
