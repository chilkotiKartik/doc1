"""Orchestrates the quotation lifecycle: building lines, routing for
approval, and recording approval decisions. The one rule this entire file
exists to enforce: **nothing changes a quotation's state without the risk
engine having just been asked, fresh, on the current data** - never a
cached score, never an assumption carried over from an earlier call.

No FastAPI imports - see ARCHITECTURE.md's layering rule. Fully testable
against a bare DB session.
"""

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.approval_step import ApprovalLevel, ApprovalStatus, ApprovalStep
from models.audit_log import AuditLog
from models.customer import Customer
from models.product import Product
from models.product_category import ProductCategory
from models.quotation import Quotation, QuotationStatus
from models.quotation_line import QuotationLine
from services import customer_service, risk_engine


class QuotationNotFound(Exception):
    pass


class LineNotFound(Exception):
    pass


class ProductNotFound(Exception):
    pass


class InvalidTransition(Exception):
    pass


class PermissionDenied(Exception):
    pass


# --- read-side view models (what routers/quotations.py actually returns) ---


@dataclass(frozen=True)
class QuotationLineView:
    id: int
    product_id: int
    product_name: str
    category_name: str
    quantity: int
    unit_price: float
    discount_pct: float
    net_total: float
    margin_pct: float
    overage_pts: float
    ceiling_pct: float
    risk_contribution: float
    hard_flag: bool


@dataclass(frozen=True)
class QuotationView:
    id: int
    customer_id: int
    customer_name: str
    rep_id: int
    status: str
    blended_risk_score: float
    hard_flag: bool
    routing: str
    grand_total: float
    customer_confirmed_at: datetime | None = None
    lines: list[QuotationLineView] = field(default_factory=list)


# --- internal helpers ---


def _log(session: DBSession, quotation_id: int, user_id: int | None, action: str, details: str | None = None) -> None:
    session.add(AuditLog(quotation_id=quotation_id, user_id=user_id, action=action, details=details))
    session.commit()


def _recompute_and_persist(session: DBSession, quotation: Quotation) -> risk_engine.RiskAssessment:
    """The one place a RiskAssessment is turned into database state. Called
    after every line mutation and again at submit/approval time - always
    fresh, never trusted from an earlier call.
    """
    assessment = risk_engine.score_quotation(session, quotation)

    lines_by_id = {
        line.id: line
        for line in session.execute(
            select(QuotationLine).where(QuotationLine.quotation_id == quotation.id)
        ).scalars()
    }
    for line_result in assessment.lines:
        line = lines_by_id[line_result.quotation_line_id]
        line.overage_pts = line_result.overage_pts
        line.risk_contribution = line_result.risk_contribution

    quotation.blended_risk_score = assessment.blended_score
    quotation.risk_breakdown = json.dumps(
        [
            {
                "product_name": r.product_name,
                "category_name": r.category_name,
                "discount_pct": r.discount_pct,
                "ceiling_pct": r.ceiling_pct,
                "overage_pts": r.overage_pts,
                "risk_contribution": r.risk_contribution,
                "hard_flag": r.hard_flag,
            }
            for r in assessment.lines
        ]
    )
    session.commit()
    return assessment


# --- write side: creating and editing a quotation ---


def create_quotation(session: DBSession, customer_id: int, rep_id: int) -> Quotation:
    quotation = Quotation(customer_id=customer_id, rep_id=rep_id, status=QuotationStatus.DRAFT)
    session.add(quotation)
    session.commit()
    session.refresh(quotation)
    _log(session, quotation.id, rep_id, "quotation_created")
    return quotation


def get_quotation(session: DBSession, quotation_id: int) -> Quotation:
    quotation = session.get(Quotation, quotation_id)
    if quotation is None:
        raise QuotationNotFound(f"No quotation with id {quotation_id}")
    return quotation


def _require_draft(quotation: Quotation) -> None:
    if quotation.status != QuotationStatus.DRAFT:
        raise InvalidTransition(
            f"Cannot edit a quotation in status '{quotation.status.value}' - only draft quotations can be edited"
        )


def add_line(
    session: DBSession, quotation_id: int, product_id: int, quantity: int, discount_pct: float, actor_id: int
) -> Quotation:
    quotation = get_quotation(session, quotation_id)
    _require_draft(quotation)

    product = session.get(Product, product_id)
    if product is None:
        raise ProductNotFound(f"No product with id {product_id}")

    line = QuotationLine(
        quotation_id=quotation.id,
        product_id=product_id,
        quantity=quantity,
        unit_price=product.list_price,
        discount_pct=discount_pct,
    )
    session.add(line)
    session.commit()

    _recompute_and_persist(session, quotation)
    _log(
        session,
        quotation.id,
        actor_id,
        "line_added",
        details=f"product={product.name} qty={quantity} discount={discount_pct}%",
    )
    return quotation


def update_line(
    session: DBSession,
    quotation_id: int,
    line_id: int,
    quantity: int | None,
    discount_pct: float | None,
    actor_id: int,
) -> Quotation:
    quotation = get_quotation(session, quotation_id)
    _require_draft(quotation)

    line = session.get(QuotationLine, line_id)
    if line is None or line.quotation_id != quotation.id:
        raise LineNotFound(f"No line with id {line_id} on quotation {quotation_id}")

    if quantity is not None:
        line.quantity = quantity
    if discount_pct is not None:
        line.discount_pct = discount_pct
    session.commit()

    _recompute_and_persist(session, quotation)
    _log(session, quotation.id, actor_id, "line_updated", details=f"line_id={line_id}")
    return quotation


def remove_line(session: DBSession, quotation_id: int, line_id: int, actor_id: int) -> Quotation:
    quotation = get_quotation(session, quotation_id)
    _require_draft(quotation)

    line = session.get(QuotationLine, line_id)
    if line is None or line.quotation_id != quotation.id:
        raise LineNotFound(f"No line with id {line_id} on quotation {quotation_id}")

    session.delete(line)
    session.commit()

    _recompute_and_persist(session, quotation)
    _log(session, quotation.id, actor_id, "line_removed", details=f"line_id={line_id}")
    return quotation


# --- approval routing ---


def submit_for_approval(session: DBSession, quotation_id: int, actor_id: int) -> Quotation:
    """Recompute once, then route based on what the engine says RIGHT NOW.
    A quotation with routing=none skips approval entirely and goes straight
    to Confirmed - the absence of any ApprovalStep row IS the "didn't need
    approval" signal, not a separate flag that could drift out of sync.
    """
    quotation = get_quotation(session, quotation_id)
    _require_draft(quotation)

    assessment = _recompute_and_persist(session, quotation)
    now = datetime.now(timezone.utc)

    if assessment.routing == risk_engine.ROUTING_NONE:
        quotation.status = QuotationStatus.CONFIRMED
        _log(session, quotation.id, actor_id, "auto_confirmed", details=f"score={assessment.blended_score}")
    else:
        # Both ROUTING_MANAGER and ROUTING_MANAGER_FINANCE start with a
        # Manager step. Whether Finance is ALSO needed is re-checked at the
        # moment Manager approves (see decide_approval) rather than decided
        # here and trusted later - the score can't have changed in between
        # (no line edits happen while pending approval), but re-asking the
        # engine every time is the whole point of this module.
        quotation.status = QuotationStatus.PENDING_MANAGER
        session.add(ApprovalStep(quotation_id=quotation.id, level=ApprovalLevel.MANAGER, created_at=now))
        _log(
            session,
            quotation.id,
            actor_id,
            "routed_for_approval",
            details=f"score={assessment.blended_score} routing={assessment.routing} hard_flag={assessment.hard_flag}",
        )

    session.commit()
    session.refresh(quotation)
    return quotation


def decide_approval(
    session: DBSession,
    quotation_id: int,
    level: ApprovalLevel,
    decision: ApprovalStatus,
    actor_id: int,
    reason: str | None = None,
) -> Quotation:
    """A Manager or Finance approver acts on the one pending step at their
    level. `decision` is one of APPROVED / REJECTED / RETURNED.
    """
    if decision not in (ApprovalStatus.APPROVED, ApprovalStatus.REJECTED, ApprovalStatus.RETURNED):
        raise InvalidTransition(f"'{decision.value}' is not a valid approval decision")

    quotation = get_quotation(session, quotation_id)

    step = session.execute(
        select(ApprovalStep).where(
            ApprovalStep.quotation_id == quotation_id,
            ApprovalStep.level == level,
            ApprovalStep.status == ApprovalStatus.PENDING,
        )
    ).scalar_one_or_none()
    if step is None:
        raise InvalidTransition(f"No pending {level.value} approval step for quotation {quotation_id}")

    step.status = decision
    step.actor_id = actor_id
    step.reason = reason
    step.acted_at = datetime.now(timezone.utc)
    session.commit()

    if decision == ApprovalStatus.REJECTED:
        quotation.status = QuotationStatus.REJECTED
        _log(session, quotation.id, actor_id, "rejected", details=f"level={level.value} reason={reason}")

    elif decision == ApprovalStatus.RETURNED:
        quotation.status = QuotationStatus.DRAFT
        _log(session, quotation.id, actor_id, "returned_for_revision", details=f"level={level.value} reason={reason}")

    else:  # APPROVED
        if level == ApprovalLevel.MANAGER:
            # Re-ask the engine rather than trust submit-time routing.
            assessment = risk_engine.score_quotation(session, quotation)
            if assessment.routing == risk_engine.ROUTING_MANAGER_FINANCE:
                quotation.status = QuotationStatus.PENDING_FINANCE
                session.add(
                    ApprovalStep(
                        quotation_id=quotation.id,
                        level=ApprovalLevel.FINANCE,
                        created_at=datetime.now(timezone.utc),
                    )
                )
                _log(session, quotation.id, actor_id, "approved", details="level=manager, escalated_to_finance")
            else:
                quotation.status = QuotationStatus.CONFIRMED
                _log(session, quotation.id, actor_id, "approved_final", details="level=manager")
        else:  # FINANCE
            quotation.status = QuotationStatus.CONFIRMED
            _log(session, quotation.id, actor_id, "approved_final", details="level=finance")

    session.commit()
    session.refresh(quotation)
    return quotation


# --- read side ---


def get_quotation_view(session: DBSession, quotation_id: int) -> QuotationView:
    quotation = get_quotation(session, quotation_id)
    customer = session.get(Customer, quotation.customer_id)
    assessment = risk_engine.score_quotation(session, quotation)
    result_by_line_id = {r.quotation_line_id: r for r in assessment.lines}

    lines = list(
        session.execute(
            select(QuotationLine).where(QuotationLine.quotation_id == quotation.id).order_by(QuotationLine.id)
        ).scalars()
    )

    line_views: list[QuotationLineView] = []
    grand_total = 0.0
    for line in lines:
        product = session.get(Product, line.product_id)
        category = session.get(ProductCategory, product.category_id)
        net_total = line.unit_price * line.quantity * (1 - line.discount_pct / 100)
        unit_net_price = net_total / line.quantity if line.quantity else 0.0
        margin_pct = ((unit_net_price - product.unit_cost) / unit_net_price * 100) if unit_net_price > 0 else 0.0
        r = result_by_line_id.get(line.id)
        grand_total += net_total

        line_views.append(
            QuotationLineView(
                id=line.id,
                product_id=product.id,
                product_name=product.name,
                category_name=category.name,
                quantity=line.quantity,
                unit_price=line.unit_price,
                discount_pct=line.discount_pct,
                net_total=round(net_total, 2),
                margin_pct=round(margin_pct, 2),
                overage_pts=r.overage_pts if r else 0.0,
                ceiling_pct=r.ceiling_pct if r else 0.0,
                risk_contribution=r.risk_contribution if r else 0.0,
                hard_flag=r.hard_flag if r else False,
            )
        )

    return QuotationView(
        id=quotation.id,
        customer_id=customer.id,
        customer_name=customer.name,
        rep_id=quotation.rep_id,
        status=quotation.status.value,
        blended_risk_score=assessment.blended_score,
        hard_flag=assessment.hard_flag,
        routing=assessment.routing,
        grand_total=round(grand_total, 2),
        customer_confirmed_at=quotation.customer_confirmed_at,
        lines=line_views,
    )


def list_quotations_for_rep(session: DBSession, rep_id: int) -> list[Quotation]:
    return list(
        session.execute(select(Quotation).where(Quotation.rep_id == rep_id).order_by(Quotation.id.desc())).scalars()
    )


def list_pending_for_level(session: DBSession, level: ApprovalLevel) -> list[Quotation]:
    """The approver's queue: every quotation with a currently-PENDING step
    at this level. Joins through ApprovalStep rather than trusting
    Quotation.status alone, since status is a derived summary, not the
    source of truth for "is there something for me to act on."
    """
    quotation_ids = session.execute(
        select(ApprovalStep.quotation_id).where(
            ApprovalStep.level == level, ApprovalStep.status == ApprovalStatus.PENDING
        )
    ).scalars()
    ids = list(quotation_ids)
    if not ids:
        return []
    return list(session.execute(select(Quotation).where(Quotation.id.in_(ids))).scalars())


def list_all_quotations(session: DBSession) -> list[Quotation]:
    return list(session.execute(select(Quotation).order_by(Quotation.id.desc())).scalars())


def list_approval_steps(session: DBSession, quotation_id: int) -> list[ApprovalStep]:
    return list(
        session.execute(
            select(ApprovalStep).where(ApprovalStep.quotation_id == quotation_id).order_by(ApprovalStep.id)
        ).scalars()
    )


def list_audit_log(session: DBSession, quotation_id: int) -> list[AuditLog]:
    return list(
        session.execute(
            select(AuditLog).where(AuditLog.quotation_id == quotation_id).order_by(AuditLog.id)
        ).scalars()
    )


# --- customer negotiation loop (differentiator #2) ---
#
# The rule this section exists to enforce: a customer's counter-offer goes
# through the EXACT SAME risk_engine.score_quotation call a rep's edit
# does. There is no separate, weaker check for customer-submitted changes -
# if a counter would have required Manager+Finance approval had a rep typed
# it, it requires that here too, automatically, with no rep action needed
# to notice or trigger it.


def list_quotations_for_customer(session: DBSession, customer_id: int) -> list[Quotation]:
    return list(
        session.execute(
            select(Quotation).where(Quotation.customer_id == customer_id).order_by(Quotation.id.desc())
        ).scalars()
    )


def _get_owned_quotation(session: DBSession, quotation_id: int, portal_user_id: int) -> Quotation:
    """Resolves a quotation AND verifies the calling portal user's linked
    Customer actually owns it - raises PermissionDenied rather than
    QuotationNotFound if it exists but belongs to someone else, so a
    customer can never even confirm-by-guessing whether a given quotation
    id exists for another account.
    """
    quotation = get_quotation(session, quotation_id)
    customer = customer_service.get_customer_by_portal_user(session, portal_user_id)
    if quotation.customer_id != customer.id:
        raise PermissionDenied("This quotation does not belong to your account")
    return quotation


def get_quotation_for_customer(session: DBSession, quotation_id: int, portal_user_id: int) -> QuotationView:
    _get_owned_quotation(session, quotation_id, portal_user_id)
    return get_quotation_view(session, quotation_id)


def customer_counter_offer(
    session: DBSession,
    quotation_id: int,
    portal_user_id: int,
    line_id: int,
    new_discount_pct: float,
    note: str | None = None,
) -> Quotation:
    """A customer proposes a different discount on one line, from the
    portal - not the internal app. Only allowed once the quote has cleared
    internal approval at least once (CONFIRMED) or is already mid-negotiation
    (UNDER_NEGOTIATION) - a customer can't negotiate a draft that hasn't
    even been sent, or one that's actively awaiting a Manager/Finance
    decision on the rep's own numbers.
    """
    quotation = _get_owned_quotation(session, quotation_id, portal_user_id)

    if quotation.status not in (QuotationStatus.CONFIRMED, QuotationStatus.UNDER_NEGOTIATION):
        raise InvalidTransition(
            f"Cannot negotiate a quotation in status '{quotation.status.value}' - "
            "it must be confirmed (or already under negotiation) first"
        )

    line = session.get(QuotationLine, line_id)
    if line is None or line.quotation_id != quotation.id:
        raise LineNotFound(f"No line with id {line_id} on quotation {quotation_id}")

    line.discount_pct = new_discount_pct
    quotation.status = QuotationStatus.UNDER_NEGOTIATION
    quotation.customer_confirmed_at = None  # a new counter supersedes any prior confirmation
    session.commit()

    _log(
        session,
        quotation.id,
        portal_user_id,
        "customer_countered",
        details=f"line={line.product_id} new_discount={new_discount_pct}% note={note or ''}".strip(),
    )

    # Exactly the same recompute-then-route path a rep's submit uses - see
    # submit_for_approval. This is the one function in the whole module
    # where "never trust a cached score" matters most: a naive
    # implementation might re-check the ORIGINAL routing decision instead
    # of asking fresh, which would silently let a customer widen a discount
    # past its ceiling with no new review.
    assessment = _recompute_and_persist(session, quotation)
    now = datetime.now(timezone.utc)

    if assessment.routing == risk_engine.ROUTING_NONE:
        quotation.status = QuotationStatus.CONFIRMED
        _log(session, quotation.id, portal_user_id, "auto_confirmed_after_negotiation", details=f"score={assessment.blended_score}")
    else:
        quotation.status = QuotationStatus.PENDING_MANAGER
        session.add(ApprovalStep(quotation_id=quotation.id, level=ApprovalLevel.MANAGER, created_at=now))
        _log(
            session,
            quotation.id,
            portal_user_id,
            "auto_reentered_approval",
            details=f"score={assessment.blended_score} routing={assessment.routing} hard_flag={assessment.hard_flag}",
        )

    session.commit()
    session.refresh(quotation)
    return quotation


def customer_confirm(session: DBSession, quotation_id: int, portal_user_id: int) -> Quotation:
    """The customer's one-click final confirmation. Only valid once the
    quotation is sitting in CONFIRMED with nothing pending - if a counter
    is still being reviewed, there is nothing yet to confirm.
    """
    quotation = _get_owned_quotation(session, quotation_id, portal_user_id)
    if quotation.status != QuotationStatus.CONFIRMED:
        raise InvalidTransition(
            f"Cannot confirm a quotation in status '{quotation.status.value}' - "
            "it must be fully approved with no pending negotiation first"
        )
    quotation.customer_confirmed_at = datetime.now(timezone.utc)
    session.commit()
    _log(session, quotation.id, portal_user_id, "customer_confirmed")
    session.refresh(quotation)
    return quotation
