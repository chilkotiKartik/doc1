"""Admin user-management: listing accounts and changing roles. Distinct
from auth_service.py, which stays scoped to login/signup/tokens - this is
what an already-authenticated admin does to other accounts, not part of
the login flow itself.
"""

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.user import Role, User


class UserNotFound(Exception):
    pass


def list_all_users(session: DBSession) -> list[User]:
    return list(session.execute(select(User)).scalars())


def change_user_role(session: DBSession, user_id: int, new_role: Role) -> User:
    user = session.get(User, user_id)
    if user is None:
        raise UserNotFound(f"No user with id {user_id}")
    user.role = new_role
    session.commit()
    session.refresh(user)
    return user
