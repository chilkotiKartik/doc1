"""Admin-facing governance configuration: discount tiers and the
tier-x-category ceilings the risk engine reads. This is deliberately plain
CRUD over data - the scoring logic itself lives entirely in
services/risk_engine.py, which only ever reads what's configured here.
Changing a ceiling from 10% to 12% is a data update through this service,
never a code change.
"""

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.category_ceiling import CategoryCeiling
from models.discount_tier import DiscountTier
from services import catalog_service


class TierNotFound(Exception):
    pass


class DuplicateTierName(Exception):
    pass


class CeilingAlreadyExists(Exception):
    pass


def create_tier(session: DBSession, name: str, overall_ceiling_pct: float) -> DiscountTier:
    existing = session.execute(select(DiscountTier).where(DiscountTier.name == name)).scalar_one_or_none()
    if existing is not None:
        raise DuplicateTierName(f"Tier '{name}' already exists")
    tier = DiscountTier(name=name, overall_ceiling_pct=overall_ceiling_pct)
    session.add(tier)
    session.commit()
    session.refresh(tier)
    return tier


def list_tiers(session: DBSession) -> list[DiscountTier]:
    return list(session.execute(select(DiscountTier)).scalars())


def get_tier(session: DBSession, tier_id: int) -> DiscountTier:
    tier = session.get(DiscountTier, tier_id)
    if tier is None:
        raise TierNotFound(f"No discount tier with id {tier_id}")
    return tier


def set_category_ceiling(
    session: DBSession,
    tier_id: int,
    category_id: int,
    max_discount_pct: float,
    margin_weight: float = 1.0,
) -> CategoryCeiling:
    """Create-or-update the ceiling for (tier, category) - a second call for
    the same pair updates the existing rule rather than erroring, since
    "the admin changed the Services ceiling from 10% to 12%" is the normal
    operation, not an edge case.
    """
    get_tier(session, tier_id)  # raises TierNotFound if invalid
    catalog_service.get_category(session, category_id)  # raises CategoryNotFound if invalid

    existing = session.execute(
        select(CategoryCeiling).where(
            CategoryCeiling.tier_id == tier_id, CategoryCeiling.category_id == category_id
        )
    ).scalar_one_or_none()

    if existing is not None:
        existing.max_discount_pct = max_discount_pct
        existing.margin_weight = margin_weight
        session.commit()
        session.refresh(existing)
        return existing

    ceiling = CategoryCeiling(
        tier_id=tier_id, category_id=category_id, max_discount_pct=max_discount_pct, margin_weight=margin_weight
    )
    session.add(ceiling)
    session.commit()
    session.refresh(ceiling)
    return ceiling


def list_ceilings(session: DBSession, tier_id: int | None = None) -> list[CategoryCeiling]:
    stmt = select(CategoryCeiling)
    if tier_id is not None:
        stmt = stmt.where(CategoryCeiling.tier_id == tier_id)
    return list(session.execute(stmt).scalars())
