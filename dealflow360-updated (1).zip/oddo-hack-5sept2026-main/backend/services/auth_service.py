"""JWT authentication. A token is self-contained (signed, carries user_id +
role + jti + expiry), so validating one is normally just a signature/expiry
check, not a DB lookup - except for one small exception: a revoked-token
check (see revoke_token/resolve_user_from_token), the minimum state needed
to support real logout. See ARCHITECTURE.md's "Logout" section for why.
"""

import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import jwt
from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from config.settings import JWT_ALGORITHM, JWT_EXPIRE_MINUTES, JWT_SECRET
from models.revoked_token import RevokedToken
from models.user import Role, User
from utils.security import hash_password, verify_password


class InvalidCredentials(Exception):
    pass


class InvalidToken(Exception):
    pass


class EmailAlreadyRegistered(Exception):
    pass


def signup(session: DBSession, name: str, email: str, password: str) -> User:
    """Every signup - through either surface - creates a Role.CUSTOMER
    account, immediately usable. Nobody self-declares a privileged role;
    an admin promotes an account afterward (services/user_service.py).
    """
    existing = session.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if existing is not None:
        raise EmailAlreadyRegistered(f"{email} is already registered")

    user = User(name=name, email=email, password_hash=hash_password(password), role=Role.CUSTOMER)
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


@dataclass(frozen=True)
class TokenPayload:
    user_id: int
    role: Role
    jti: str
    exp: datetime


def authenticate(session: DBSession, email: str, password: str) -> User:
    user = session.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if user is None or not verify_password(password, user.password_hash):
        raise InvalidCredentials("Invalid email or password")
    return user


def create_access_token(user: User, expires_delta: timedelta | None = None) -> str:
    expires_delta = expires_delta if expires_delta is not None else timedelta(minutes=JWT_EXPIRE_MINUTES)
    payload = {
        "sub": str(user.id),
        "role": user.role.value,
        "jti": str(uuid.uuid4()),
        "exp": datetime.now(timezone.utc) + expires_delta,
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_access_token(token: str) -> TokenPayload:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError as exc:
        raise InvalidToken("Invalid or expired token") from exc

    try:
        return TokenPayload(
            user_id=int(payload["sub"]),
            role=Role(payload["role"]),
            jti=payload["jti"],
            exp=datetime.fromtimestamp(payload["exp"], tz=timezone.utc),
        )
    except (KeyError, ValueError) as exc:
        raise InvalidToken("Malformed token payload") from exc


def revoke_token(session: DBSession, jti: str, expires_at: datetime) -> None:
    existing = session.execute(select(RevokedToken).where(RevokedToken.jti == jti)).scalar_one_or_none()
    if existing is not None:
        return
    session.add(RevokedToken(jti=jti, expires_at=expires_at))
    session.commit()


def resolve_user_from_token(session: DBSession, token: str) -> User:
    """Decode a token and load the User it refers to. Raises InvalidToken for
    a bad/expired signature, a revoked token, and also if the user it points
    to no longer exists - all the same "this token is no good" case to a
    caller.
    """
    payload = decode_access_token(token)

    revoked = session.execute(
        select(RevokedToken).where(RevokedToken.jti == payload.jti)
    ).scalar_one_or_none()
    if revoked is not None:
        raise InvalidToken("Token has been revoked")

    user = session.get(User, payload.user_id)
    if user is None:
        raise InvalidToken("Token no longer matches a known user")
    return user
