"""Shipment-minimizing warehouse allocation. A bounded greedy heuristic, not
a claim of global optimality - minimizing the number of split shipments
across warehouses is a studied NP-hard problem at scale (Catalán & Fisher,
2012), so a transparent, fast, explainable heuristic with a manual-override
escape hatch is the right engineering tradeoff for this problem's size, not
an admission of a missing feature.

Algorithm: sort warehouses cheapest-to-ship-from first (`shipping_weight`
ascending). For each line, pull from the cheapest warehouse with any stock
until either the line is fully covered or every warehouse has been tried;
whatever's left over is a backorder. Shipment count is the number of
distinct non-backorder warehouses touched across the whole order.
"""

from dataclasses import dataclass, field

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.product import Product
from models.quotation import Quotation
from models.quotation_line import QuotationLine
from models.stock_level import StockLevel
from models.warehouse import Warehouse
from models.warehouse_allocation import WarehouseAllocation

SHIPPING_COST_PER_SHIPMENT = 14.50  # a flat estimate used only for the demo's cost display


@dataclass(frozen=True)
class LineAllocation:
    quotation_line_id: int
    product_id: int
    product_name: str
    warehouse_id: int | None
    warehouse_name: str
    quantity: int
    is_backorder: bool


@dataclass(frozen=True)
class SplitPlan:
    lines: list[LineAllocation] = field(default_factory=list)
    shipment_count: int = 0
    estimated_shipping_cost: float = 0.0
    total_backordered_units: int = 0


class QuotationNotFound(Exception):
    pass


def suggest_split(session: DBSession, quotation_id: int) -> SplitPlan:
    quotation = session.get(Quotation, quotation_id)
    if quotation is None:
        raise QuotationNotFound(f"No quotation with id {quotation_id}")

    lines = list(
        session.execute(select(QuotationLine).where(QuotationLine.quotation_id == quotation_id)).scalars()
    )
    warehouses = list(session.execute(select(Warehouse).order_by(Warehouse.shipping_weight.asc())).scalars())

    if not warehouses:
        return SplitPlan(
            lines=[
                LineAllocation(
                    quotation_line_id=line.id,
                    product_id=line.product_id,
                    product_name=session.get(Product, line.product_id).name,
                    warehouse_id=None,
                    warehouse_name="Backorder - no warehouses configured",
                    quantity=line.quantity,
                    is_backorder=True,
                )
                for line in lines
            ],
            shipment_count=0,
            estimated_shipping_cost=0.0,
            total_backordered_units=sum(line.quantity for line in lines),
        )

    stock: dict[tuple[int, int], int] = {}
    for row in session.execute(select(StockLevel)).scalars():
        stock[(row.warehouse_id, row.product_id)] = row.quantity

    allocations: list[LineAllocation] = []
    warehouses_used: set[int] = set()
    total_backordered = 0

    for line in lines:
        product = session.get(Product, line.product_id)
        remaining = line.quantity

        for warehouse in warehouses:
            if remaining <= 0:
                break
            key = (warehouse.id, line.product_id)
            available = stock.get(key, 0)
            if available <= 0:
                continue
            take = min(remaining, available)
            stock[key] = available - take
            remaining -= take
            warehouses_used.add(warehouse.id)
            allocations.append(
                LineAllocation(
                    quotation_line_id=line.id,
                    product_id=line.product_id,
                    product_name=product.name,
                    warehouse_id=warehouse.id,
                    warehouse_name=warehouse.name,
                    quantity=take,
                    is_backorder=False,
                )
            )

        if remaining > 0:
            total_backordered += remaining
            allocations.append(
                LineAllocation(
                    quotation_line_id=line.id,
                    product_id=line.product_id,
                    product_name=product.name,
                    warehouse_id=None,
                    warehouse_name="Backorder",
                    quantity=remaining,
                    is_backorder=True,
                )
            )

    shipment_count = len(warehouses_used)
    return SplitPlan(
        lines=allocations,
        shipment_count=shipment_count,
        estimated_shipping_cost=round(shipment_count * SHIPPING_COST_PER_SHIPMENT, 2),
        total_backordered_units=total_backordered,
    )


def accept_allocation(session: DBSession, quotation_id: int) -> SplitPlan:
    """Recomputes the plan fresh (never trusts a plan the caller might have
    cached client-side) and persists it as WarehouseAllocation rows -
    replacing any previous acceptance for this quotation, since accepting
    again after a manual override means the override is the source of
    truth now.
    """
    plan = suggest_split(session, quotation_id)

    existing = session.execute(
        select(WarehouseAllocation).where(WarehouseAllocation.quotation_id == quotation_id)
    ).scalars()
    for row in existing:
        session.delete(row)
    session.commit()

    for allocation in plan.lines:
        session.add(
            WarehouseAllocation(
                quotation_id=quotation_id,
                quotation_line_id=allocation.quotation_line_id,
                warehouse_id=allocation.warehouse_id,
                product_id=allocation.product_id,
                quantity=allocation.quantity,
                is_backorder=allocation.is_backorder,
            )
        )
    session.commit()
    return plan


def get_accepted_allocation(session: DBSession, quotation_id: int) -> list[WarehouseAllocation]:
    return list(
        session.execute(
            select(WarehouseAllocation).where(WarehouseAllocation.quotation_id == quotation_id)
        ).scalars()
    )
