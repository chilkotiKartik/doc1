"""Deal health monitoring: rep-relative discount anomaly detection
(z-score) and stalled-deal detection. Both are read-only and both reuse
data the risk engine and quotation lifecycle already produce - no new
tables, no trained model, no training-data problem. Every flag is
explainable: "this rep's own past N deals averaged X% discount, this one
is Y%, that's Z standard deviations away" - not a black-box score.

Deliberately rep-relative, not team-wide: a rep who always discounts
aggressively isn't flagged for being consistent with themselves; a
conservative rep's first unusually large discount is. This is the same
principle as the risk engine (explainable, deterministic) applied to a
different question (is this discount unusual FOR THIS PERSON, not is it
over a fixed limit).
"""

import statistics
from dataclasses import dataclass
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session as DBSession

from models.customer import Customer
from models.quotation import Quotation, QuotationStatus
from models.quotation_line import QuotationLine
from models.user import User
from services.quotation_service import get_quotation_view

ACTIVE_STATUSES = (
    QuotationStatus.DRAFT,
    QuotationStatus.PENDING_MANAGER,
    QuotationStatus.PENDING_FINANCE,
    QuotationStatus.UNDER_NEGOTIATION,
)

STALL_DAYS_THRESHOLD = 5
ANOMALY_Z_THRESHOLD = 2.0
MIN_HISTORY_FOR_ANOMALY = 4  # below this, a z-score for this rep isn't trustworthy yet


@dataclass(frozen=True)
class DiscountAnomaly:
    quotation_id: int
    rep_id: int
    rep_name: str
    customer_name: str
    this_deal_avg_discount: float
    rep_mean_discount: float
    rep_stdev_discount: float
    z_score: float
    sample_size: int


@dataclass(frozen=True)
class StalledDeal:
    quotation_id: int
    rep_id: int
    rep_name: str
    customer_name: str
    status: str
    days_inactive: int
    grand_total: float


def _quotation_avg_discount(session: DBSession, quotation_id: int) -> float | None:
    lines = list(
        session.execute(select(QuotationLine).where(QuotationLine.quotation_id == quotation_id)).scalars()
    )
    if not lines:
        return None
    return sum(line.discount_pct for line in lines) / len(lines)


def detect_discount_anomalies(session: DBSession, lookback_limit: int = 300) -> list[DiscountAnomaly]:
    """Builds each rep's own historical discount distribution from their
    CONFIRMED deals, then flags ANY deal of theirs (confirmed or still in
    flight) whose average line discount is >= ANOMALY_Z_THRESHOLD standard
    deviations from that personal mean.
    """
    quotations = list(
        session.execute(select(Quotation).order_by(Quotation.id.desc()).limit(lookback_limit)).scalars()
    )
    by_rep: dict[int, list[Quotation]] = {}
    for q in quotations:
        by_rep.setdefault(q.rep_id, []).append(q)

    anomalies: list[DiscountAnomaly] = []
    for rep_id, reps_quotations in by_rep.items():
        confirmed = [q for q in reps_quotations if q.status == QuotationStatus.CONFIRMED]
        history = [(q.id, avg) for q in confirmed if (avg := _quotation_avg_discount(session, q.id)) is not None]

        if len(history) < MIN_HISTORY_FOR_ANOMALY:
            continue

        values = [d for _, d in history]
        mean = statistics.mean(values)
        stdev = statistics.pstdev(values)
        if stdev == 0:
            continue  # zero variation - a z-score would be undefined/meaningless

        rep = session.get(User, rep_id)

        for q in reps_quotations:
            avg = _quotation_avg_discount(session, q.id)
            if avg is None:
                continue
            z = (avg - mean) / stdev
            if abs(z) >= ANOMALY_Z_THRESHOLD:
                customer = session.get(Customer, q.customer_id)
                anomalies.append(
                    DiscountAnomaly(
                        quotation_id=q.id,
                        rep_id=rep_id,
                        rep_name=rep.name if rep else f"Rep {rep_id}",
                        customer_name=customer.name if customer else "Unknown",
                        this_deal_avg_discount=round(avg, 2),
                        rep_mean_discount=round(mean, 2),
                        rep_stdev_discount=round(stdev, 2),
                        z_score=round(z, 2),
                        sample_size=len(values),
                    )
                )

    anomalies.sort(key=lambda a: abs(a.z_score), reverse=True)
    return anomalies


def detect_stalled_deals(session: DBSession, stall_days: int = STALL_DAYS_THRESHOLD) -> list[StalledDeal]:
    """Any quotation still in an active (non-terminal) status that hasn't
    been touched in `stall_days` or more. Reads Quotation.updated_at
    directly - every line/approval/negotiation mutation in
    quotation_service already bumps this via the model's `onupdate`, so
    "hasn't been touched" is real, not inferred.
    """
    now = datetime.now(timezone.utc)
    quotations = list(session.execute(select(Quotation).where(Quotation.status.in_(ACTIVE_STATUSES))).scalars())

    stalled: list[StalledDeal] = []
    for q in quotations:
        updated = q.updated_at if q.updated_at.tzinfo else q.updated_at.replace(tzinfo=timezone.utc)
        days_inactive = (now - updated).days
        if days_inactive < stall_days:
            continue
        rep = session.get(User, q.rep_id)
        customer = session.get(Customer, q.customer_id)
        view = get_quotation_view(session, q.id)
        stalled.append(
            StalledDeal(
                quotation_id=q.id,
                rep_id=q.rep_id,
                rep_name=rep.name if rep else f"Rep {q.rep_id}",
                customer_name=customer.name if customer else "Unknown",
                status=q.status.value,
                days_inactive=days_inactive,
                grand_total=view.grand_total,
            )
        )

    stalled.sort(key=lambda s: s.days_inactive, reverse=True)
    return stalled
