from pydantic import BaseModel


class DiscountTierCreate(BaseModel):
    name: str
    overall_ceiling_pct: float


class DiscountTierResponse(BaseModel):
    id: int
    name: str
    overall_ceiling_pct: float

    model_config = {"from_attributes": True}


class CategoryCeilingCreate(BaseModel):
    tier_id: int
    category_id: int
    max_discount_pct: float
    margin_weight: float = 1.0


class CategoryCeilingResponse(BaseModel):
    id: int
    tier_id: int
    category_id: int
    max_discount_pct: float
    margin_weight: float

    model_config = {"from_attributes": True}
