from pydantic import BaseModel


class ProductCategoryCreate(BaseModel):
    name: str


class ProductCategoryResponse(BaseModel):
    id: int
    name: str

    model_config = {"from_attributes": True}


class ProductCreate(BaseModel):
    name: str
    category_id: int
    unit_cost: float
    list_price: float
    is_subscription: bool = False


class ProductResponse(BaseModel):
    id: int
    name: str
    category_id: int
    unit_cost: float
    list_price: float
    is_subscription: bool

    model_config = {"from_attributes": True}
