from pydantic import BaseModel


class DiscountAnomalyResponse(BaseModel):
    quotation_id: int
    rep_id: int
    rep_name: str
    customer_name: str
    this_deal_avg_discount: float
    rep_mean_discount: float
    rep_stdev_discount: float
    z_score: float
    sample_size: int

    model_config = {"from_attributes": True}


class StalledDealResponse(BaseModel):
    quotation_id: int
    rep_id: int
    rep_name: str
    customer_name: str
    status: str
    days_inactive: int
    grand_total: float

    model_config = {"from_attributes": True}
