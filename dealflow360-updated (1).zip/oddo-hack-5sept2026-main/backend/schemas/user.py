from pydantic import BaseModel

from models.user import Role


class ChangeRoleRequest(BaseModel):
    role: Role
