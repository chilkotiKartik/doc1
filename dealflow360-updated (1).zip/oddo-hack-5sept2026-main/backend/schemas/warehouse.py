from pydantic import BaseModel


class WarehouseCreate(BaseModel):
    name: str
    shipping_weight: float = 1.0


class WarehouseResponse(BaseModel):
    id: int
    name: str
    shipping_weight: float

    model_config = {"from_attributes": True}


class StockLevelSet(BaseModel):
    warehouse_id: int
    product_id: int
    quantity: int


class StockLevelResponse(BaseModel):
    id: int
    warehouse_id: int
    product_id: int
    quantity: int

    model_config = {"from_attributes": True}


class LineAllocationResponse(BaseModel):
    quotation_line_id: int
    product_id: int
    product_name: str
    warehouse_id: int | None
    warehouse_name: str
    quantity: int
    is_backorder: bool

    model_config = {"from_attributes": True}


class SplitPlanResponse(BaseModel):
    lines: list[LineAllocationResponse]
    shipment_count: int
    estimated_shipping_cost: float
    total_backordered_units: int

    model_config = {"from_attributes": True}
