from pydantic import BaseModel


class CustomerCreate(BaseModel):
    name: str
    tier_id: int


class CustomerResponse(BaseModel):
    id: int
    name: str
    tier_id: int
    tier_name: str

    model_config = {"from_attributes": True}
