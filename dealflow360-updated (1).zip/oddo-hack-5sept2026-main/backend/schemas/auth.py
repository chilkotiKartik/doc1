from pydantic import BaseModel

from models.user import Role


class SignupRequest(BaseModel):
    """Used by both signup surfaces. No `role` field - every signup always
    creates a Role.CUSTOMER account, forced server-side. An admin promotes
    an account to an internal role afterward (see routers/internal/users.py)
    - nobody self-declares a privileged role at signup.
    """

    name: str
    email: str
    password: str


class LoginRequest(BaseModel):
    email: str
    password: str


class UserResponse(BaseModel):
    id: int
    name: str
    email: str
    role: Role

    model_config = {"from_attributes": True}


class AuthResponse(BaseModel):
    token: str
    user: UserResponse
