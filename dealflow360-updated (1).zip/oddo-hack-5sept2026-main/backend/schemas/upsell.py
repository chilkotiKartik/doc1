from pydantic import BaseModel


class CrossSellSuggestionResponse(BaseModel):
    product_id: int
    product_name: str
    category_name: str
    list_price: float
    margin_pct: float
    lift: float
    confidence: float
    co_occurrence_count: int
    margin_delta_if_added: float

    model_config = {"from_attributes": True}
