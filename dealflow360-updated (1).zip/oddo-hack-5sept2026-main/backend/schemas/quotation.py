from datetime import datetime

from pydantic import BaseModel

from models.approval_step import ApprovalLevel, ApprovalStatus


class QuotationCreate(BaseModel):
    customer_id: int


class AddLineRequest(BaseModel):
    product_id: int
    quantity: int = 1
    discount_pct: float = 0.0


class UpdateLineRequest(BaseModel):
    quantity: int | None = None
    discount_pct: float | None = None


class ApprovalDecisionRequest(BaseModel):
    decision: ApprovalStatus  # approved | rejected | returned
    reason: str | None = None


class QuotationLineResponse(BaseModel):
    id: int
    product_id: int
    product_name: str
    category_name: str
    quantity: int
    unit_price: float
    discount_pct: float
    net_total: float
    margin_pct: float
    overage_pts: float
    ceiling_pct: float
    risk_contribution: float
    hard_flag: bool

    model_config = {"from_attributes": True}


class QuotationResponse(BaseModel):
    id: int
    customer_id: int
    customer_name: str
    rep_id: int
    status: str
    blended_risk_score: float
    hard_flag: bool
    routing: str
    grand_total: float
    customer_confirmed_at: datetime | None
    lines: list[QuotationLineResponse]

    model_config = {"from_attributes": True}


class ApprovalStepResponse(BaseModel):
    id: int
    quotation_id: int
    level: ApprovalLevel
    status: ApprovalStatus
    actor_id: int | None
    reason: str | None
    created_at: datetime
    acted_at: datetime | None

    model_config = {"from_attributes": True}


class AuditLogResponse(BaseModel):
    id: int
    quotation_id: int
    user_id: int | None
    action: str
    details: str | None
    created_at: datetime

    model_config = {"from_attributes": True}
