from pydantic import BaseModel


class CounterOfferRequest(BaseModel):
    line_id: int
    discount_pct: float
    note: str | None = None
