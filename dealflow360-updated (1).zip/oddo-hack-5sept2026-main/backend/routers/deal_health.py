from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_session, require_role
from schemas.deal_health import DiscountAnomalyResponse, StalledDealResponse
from services import deal_health

router = APIRouter(prefix="/api/deal-health", tags=["deal-health"])

_can_view = require_role(Role.MANAGER, Role.FINANCE, Role.ADMIN)


@router.get("/anomalies", response_model=list[DiscountAnomalyResponse])
def list_anomalies(session: Session = Depends(get_session), _user: User = Depends(_can_view)):
    return deal_health.detect_discount_anomalies(session)


@router.get("/stalled", response_model=list[StalledDealResponse])
def list_stalled(session: Session = Depends(get_session), _user: User = Depends(_can_view)):
    return deal_health.detect_stalled_deals(session)
