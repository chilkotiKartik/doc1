from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_current_user, get_session, require_role
from schemas.warehouse import (
    SplitPlanResponse,
    StockLevelResponse,
    StockLevelSet,
    WarehouseCreate,
    WarehouseResponse,
)
from services import catalog_service, warehouse_service, warehouse_split

router = APIRouter(tags=["warehouses"])

_admin_only = require_role(Role.ADMIN)
_can_fulfill = require_role(Role.REP, Role.FINANCE, Role.ADMIN)


@router.post("/api/warehouses", response_model=WarehouseResponse, status_code=201)
def create_warehouse(
    payload: WarehouseCreate, session: Session = Depends(get_session), _admin: User = Depends(_admin_only)
):
    try:
        return warehouse_service.create_warehouse(session, name=payload.name, shipping_weight=payload.shipping_weight)
    except warehouse_service.DuplicateWarehouseName as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/api/warehouses", response_model=list[WarehouseResponse])
def list_warehouses(session: Session = Depends(get_session), _user: User = Depends(get_current_user)):
    return warehouse_service.list_warehouses(session)


@router.put("/api/warehouses/stock", response_model=StockLevelResponse)
def set_stock(
    payload: StockLevelSet, session: Session = Depends(get_session), _admin: User = Depends(_admin_only)
):
    try:
        return warehouse_service.set_stock_level(
            session, warehouse_id=payload.warehouse_id, product_id=payload.product_id, quantity=payload.quantity
        )
    except (warehouse_service.WarehouseNotFound, catalog_service.ProductNotFound) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/api/warehouses/stock", response_model=list[StockLevelResponse])
def list_stock(
    warehouse_id: int | None = None,
    session: Session = Depends(get_session),
    _user: User = Depends(get_current_user),
):
    return warehouse_service.list_stock(session, warehouse_id=warehouse_id)


@router.get("/api/quotations/{quotation_id}/split", response_model=SplitPlanResponse)
def suggest_split(
    quotation_id: int, session: Session = Depends(get_session), _user: User = Depends(_can_fulfill)
):
    try:
        return warehouse_split.suggest_split(session, quotation_id)
    except warehouse_split.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/api/quotations/{quotation_id}/split/accept", response_model=SplitPlanResponse)
def accept_split(
    quotation_id: int, session: Session = Depends(get_session), _user: User = Depends(_can_fulfill)
):
    """Recomputes and persists the plan as the accepted fulfillment
    decision - this is the "Accept Suggested Split" action from the brief.
    Calling it again (e.g. after a manual restock) replaces the prior
    acceptance rather than appending to it.
    """
    try:
        return warehouse_split.accept_allocation(session, quotation_id)
    except warehouse_split.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
