from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_current_user, get_session, require_role
from schemas.governance import (
    CategoryCeilingCreate,
    CategoryCeilingResponse,
    DiscountTierCreate,
    DiscountTierResponse,
)
from services import catalog_service, governance_service

router = APIRouter(prefix="/api/governance", tags=["governance"])

_admin_only = require_role(Role.ADMIN)


@router.post("/tiers", response_model=DiscountTierResponse, status_code=201)
def create_tier(
    payload: DiscountTierCreate, session: Session = Depends(get_session), _admin: User = Depends(_admin_only)
):
    try:
        return governance_service.create_tier(session, name=payload.name, overall_ceiling_pct=payload.overall_ceiling_pct)
    except governance_service.DuplicateTierName as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/tiers", response_model=list[DiscountTierResponse])
def list_tiers(session: Session = Depends(get_session), _user: User = Depends(get_current_user)):
    return governance_service.list_tiers(session)


@router.put("/ceilings", response_model=CategoryCeilingResponse)
def set_ceiling(
    payload: CategoryCeilingCreate, session: Session = Depends(get_session), _admin: User = Depends(_admin_only)
):
    """PUT, not POST - setting the ceiling for a (tier, category) pair that
    already has a rule updates it in place (see governance_service), since
    that's the normal operation, not a conflict to reject.
    """
    try:
        return governance_service.set_category_ceiling(
            session,
            tier_id=payload.tier_id,
            category_id=payload.category_id,
            max_discount_pct=payload.max_discount_pct,
            margin_weight=payload.margin_weight,
        )
    except (governance_service.TierNotFound, catalog_service.CategoryNotFound) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/ceilings", response_model=list[CategoryCeilingResponse])
def list_ceilings(
    tier_id: int | None = Query(default=None),
    session: Session = Depends(get_session),
    _user: User = Depends(get_current_user),
):
    return governance_service.list_ceilings(session, tier_id=tier_id)
