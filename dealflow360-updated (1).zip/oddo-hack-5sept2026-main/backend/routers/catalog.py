from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_current_user, get_session, require_role
from schemas.catalog import ProductCategoryCreate, ProductCategoryResponse, ProductCreate, ProductResponse
from services import catalog_service

router = APIRouter(prefix="/api/catalog", tags=["catalog"])

_admin_only = require_role(Role.ADMIN)


@router.post("/categories", response_model=ProductCategoryResponse, status_code=201)
def create_category(
    payload: ProductCategoryCreate, session: Session = Depends(get_session), _admin: User = Depends(_admin_only)
):
    try:
        return catalog_service.create_category(session, name=payload.name)
    except catalog_service.DuplicateCategoryName as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/categories", response_model=list[ProductCategoryResponse])
def list_categories(session: Session = Depends(get_session), _user: User = Depends(get_current_user)):
    return catalog_service.list_categories(session)


@router.post("/products", response_model=ProductResponse, status_code=201)
def create_product(
    payload: ProductCreate, session: Session = Depends(get_session), _admin: User = Depends(_admin_only)
):
    try:
        return catalog_service.create_product(
            session,
            name=payload.name,
            category_id=payload.category_id,
            unit_cost=payload.unit_cost,
            list_price=payload.list_price,
            is_subscription=payload.is_subscription,
        )
    except catalog_service.CategoryNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/products", response_model=list[ProductResponse])
def list_products(session: Session = Depends(get_session), _user: User = Depends(get_current_user)):
    return catalog_service.list_products(session)
