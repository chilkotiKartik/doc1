from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_session, require_role
from schemas.auth import UserResponse
from schemas.user import ChangeRoleRequest
from services import user_service

router = APIRouter(prefix="/api/users", tags=["users"])

_admin_only = require_role(Role.ADMIN)


@router.get("", response_model=list[UserResponse])
def list_users(session: Session = Depends(get_session), _admin: User = Depends(_admin_only)):
    return user_service.list_all_users(session)


@router.patch("/{user_id}/role", response_model=UserResponse)
def change_role(
    user_id: int,
    payload: ChangeRoleRequest,
    session: Session = Depends(get_session),
    _admin: User = Depends(_admin_only),
):
    try:
        return user_service.change_user_role(session, user_id, payload.role)
    except user_service.UserNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
