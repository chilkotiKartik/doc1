from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.user import User
from routers.deps import get_bearer_token, get_current_user, get_session
from schemas.auth import AuthResponse, LoginRequest, SignupRequest, UserResponse
from services import auth_service

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/signup", response_model=AuthResponse, status_code=201)
def signup(payload: SignupRequest, session: Session = Depends(get_session)):
    try:
        user = auth_service.signup(
            session, name=payload.name, email=payload.email, password=payload.password
        )
    except auth_service.EmailAlreadyRegistered as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    token = auth_service.create_access_token(user)
    return AuthResponse(token=token, user=user)


@router.post("/login", response_model=AuthResponse)
def login(payload: LoginRequest, session: Session = Depends(get_session)):
    try:
        user = auth_service.authenticate(session, email=payload.email, password=payload.password)
    except auth_service.InvalidCredentials as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc

    token = auth_service.create_access_token(user)
    return AuthResponse(token=token, user=user)


@router.get("/me", response_model=UserResponse)
def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.post("/logout", status_code=204)
def logout(
    token: str = Depends(get_bearer_token),
    session: Session = Depends(get_session),
    _current_user: User = Depends(get_current_user),
):
    payload = auth_service.decode_access_token(token)
    auth_service.revoke_token(session, jti=payload.jti, expires_at=payload.exp)
