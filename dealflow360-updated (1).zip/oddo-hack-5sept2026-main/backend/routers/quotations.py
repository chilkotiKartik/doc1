from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.approval_step import ApprovalLevel, ApprovalStatus
from models.user import Role, User
from routers.deps import get_current_user, get_session, require_role
from schemas.quotation import (
    AddLineRequest,
    ApprovalDecisionRequest,
    ApprovalStepResponse,
    AuditLogResponse,
    QuotationCreate,
    QuotationResponse,
    UpdateLineRequest,
)
from schemas.upsell import CrossSellSuggestionResponse
from services import quotation_service, upsell_engine

router = APIRouter(prefix="/api/quotations", tags=["quotations"])

_rep_or_admin = require_role(Role.REP, Role.ADMIN)
_approver = require_role(Role.MANAGER, Role.FINANCE, Role.ADMIN)


def _view(session: Session, quotation_id: int) -> quotation_service.QuotationView:
    return quotation_service.get_quotation_view(session, quotation_id)


@router.post("", response_model=QuotationResponse, status_code=201)
def create_quotation(
    payload: QuotationCreate, session: Session = Depends(get_session), user: User = Depends(_rep_or_admin)
):
    quotation = quotation_service.create_quotation(session, customer_id=payload.customer_id, rep_id=user.id)
    return _view(session, quotation.id)


@router.get("/{quotation_id}", response_model=QuotationResponse)
def get_quotation(
    quotation_id: int, session: Session = Depends(get_session), _user: User = Depends(get_current_user)
):
    try:
        return _view(session, quotation_id)
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/{quotation_id}/cross-sell", response_model=list[CrossSellSuggestionResponse])
def get_cross_sell_suggestions(
    quotation_id: int, session: Session = Depends(get_session), _user: User = Depends(get_current_user)
):
    """Ranked suggestions based on what the current lines' products have
    historically been bought alongside, filtered to healthy-margin items
    only. Recomputed fresh on every call against live confirmed-order
    history - see services/upsell_engine.py.
    """
    try:
        view = _view(session, quotation_id)
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    current_product_ids = [line.product_id for line in view.lines]
    return upsell_engine.suggest_cross_sell(session, current_product_ids)


@router.get("", response_model=list[QuotationResponse])
def list_quotations(
    mine: bool = False,
    pending_manager: bool = False,
    pending_finance: bool = False,
    session: Session = Depends(get_session),
    user: User = Depends(get_current_user),
):
    """One endpoint, three views, chosen by query flag:
    - `mine=true` - a rep's own quotations.
    - `pending_manager` / `pending_finance` - an approver's queue at that
      level (built from ApprovalStep rows, not Quotation.status - see
      quotation_service.list_pending_for_level's docstring for why).
    - no flag - everything (admin/reporting view).
    """
    if mine:
        quotations = quotation_service.list_quotations_for_rep(session, user.id)
    elif pending_manager:
        quotations = quotation_service.list_pending_for_level(session, ApprovalLevel.MANAGER)
    elif pending_finance:
        quotations = quotation_service.list_pending_for_level(session, ApprovalLevel.FINANCE)
    else:
        quotations = quotation_service.list_all_quotations(session)
    return [_view(session, q.id) for q in quotations]


@router.post("/{quotation_id}/lines", response_model=QuotationResponse, status_code=201)
def add_line(
    quotation_id: int,
    payload: AddLineRequest,
    session: Session = Depends(get_session),
    user: User = Depends(_rep_or_admin),
):
    try:
        quotation_service.add_line(
            session,
            quotation_id=quotation_id,
            product_id=payload.product_id,
            quantity=payload.quantity,
            discount_pct=payload.discount_pct,
            actor_id=user.id,
        )
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.ProductNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.InvalidTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _view(session, quotation_id)


@router.patch("/{quotation_id}/lines/{line_id}", response_model=QuotationResponse)
def update_line(
    quotation_id: int,
    line_id: int,
    payload: UpdateLineRequest,
    session: Session = Depends(get_session),
    user: User = Depends(_rep_or_admin),
):
    try:
        quotation_service.update_line(
            session,
            quotation_id=quotation_id,
            line_id=line_id,
            quantity=payload.quantity,
            discount_pct=payload.discount_pct,
            actor_id=user.id,
        )
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.LineNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.InvalidTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _view(session, quotation_id)


@router.delete("/{quotation_id}/lines/{line_id}", response_model=QuotationResponse)
def remove_line(
    quotation_id: int, line_id: int, session: Session = Depends(get_session), user: User = Depends(_rep_or_admin)
):
    try:
        quotation_service.remove_line(session, quotation_id=quotation_id, line_id=line_id, actor_id=user.id)
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.LineNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.InvalidTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _view(session, quotation_id)


@router.post("/{quotation_id}/submit", response_model=QuotationResponse)
def submit_for_approval(
    quotation_id: int, session: Session = Depends(get_session), user: User = Depends(_rep_or_admin)
):
    """Recomputes the risk score fresh and either auto-confirms or routes to
    Manager (and, later, Finance if still needed on approval) - never the
    rep's choice to request or skip approval.
    """
    try:
        quotation_service.submit_for_approval(session, quotation_id=quotation_id, actor_id=user.id)
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.InvalidTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _view(session, quotation_id)


@router.post("/{quotation_id}/approvals/{level}", response_model=QuotationResponse)
def decide_approval(
    quotation_id: int,
    level: ApprovalLevel,
    payload: ApprovalDecisionRequest,
    session: Session = Depends(get_session),
    user: User = Depends(_approver),
):
    # A Manager can only decide a manager-level step; Finance only a
    # finance-level step. Admin can act at either, for testing/demo
    # purposes. This is enforced here (it depends on the `level` path
    # param, which require_role alone can't see) rather than in the
    # service, keeping the "who is allowed" check an HTTP-layer concern.
    allowed_role = {ApprovalLevel.MANAGER: Role.MANAGER, ApprovalLevel.FINANCE: Role.FINANCE}[level]
    if user.role not in (allowed_role, Role.ADMIN):
        raise HTTPException(status_code=403, detail=f"Only {allowed_role.value} (or admin) can decide a {level.value} step")

    try:
        quotation_service.decide_approval(
            session,
            quotation_id=quotation_id,
            level=level,
            decision=payload.decision,
            actor_id=user.id,
            reason=payload.reason,
        )
    except quotation_service.QuotationNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except quotation_service.InvalidTransition as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return _view(session, quotation_id)


@router.get("/{quotation_id}/approvals", response_model=list[ApprovalStepResponse])
def list_approvals(
    quotation_id: int, session: Session = Depends(get_session), _user: User = Depends(get_current_user)
):
    return quotation_service.list_approval_steps(session, quotation_id)


@router.get("/{quotation_id}/audit-log", response_model=list[AuditLogResponse])
def get_audit_log(
    quotation_id: int, session: Session = Depends(get_session), _user: User = Depends(get_current_user)
):
    return quotation_service.list_audit_log(session, quotation_id)
