from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_current_user, get_session, require_role
from schemas.customer import CustomerCreate, CustomerResponse
from services import customer_service, governance_service

router = APIRouter(prefix="/api/customers", tags=["customers"])

# Reps need to create a Customer while building a quotation for a brand new
# account, so this is rep-or-admin, unlike catalog/governance which are
# admin-only setup screens.
_rep_or_admin = require_role(Role.REP, Role.ADMIN)
_admin_only = require_role(Role.ADMIN)


@router.post("", response_model=CustomerResponse, status_code=201)
def create_customer(
    payload: CustomerCreate, session: Session = Depends(get_session), _user: User = Depends(_rep_or_admin)
):
    try:
        customer = customer_service.create_customer(session, name=payload.name, tier_id=payload.tier_id)
    except governance_service.TierNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return customer_service.get_customer_view(session, customer.id)


@router.get("", response_model=list[CustomerResponse])
def list_customers(session: Session = Depends(get_session), _user: User = Depends(get_current_user)):
    return customer_service.list_customers(session)


@router.get("/{customer_id}", response_model=CustomerResponse)
def get_customer(
    customer_id: int, session: Session = Depends(get_session), _user: User = Depends(get_current_user)
):
    try:
        return customer_service.get_customer_view(session, customer_id)
    except customer_service.CustomerNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.patch("/{customer_id}/link-portal-user", response_model=CustomerResponse)
def link_portal_user(
    customer_id: int,
    user_id: int,
    session: Session = Depends(get_session),
    _admin: User = Depends(_admin_only),
):
    """Attaches a portal (role=customer) login to a buying account, so that
    login's /api/portal/* calls resolve to this customer's quotations.
    `user_id` as a query param, not a body, since this is a single-value
    admin action, not a resource creation.
    """
    try:
        customer_service.link_portal_user(session, customer_id=customer_id, user_id=user_id)
    except customer_service.CustomerNotFound as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return customer_service.get_customer_view(session, customer_id)
