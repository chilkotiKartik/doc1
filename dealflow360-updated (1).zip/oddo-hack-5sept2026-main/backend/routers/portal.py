from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from models.user import Role, User
from routers.deps import get_session, require_role
from schemas.portal import CounterOfferRequest
from schemas.quotation import QuotationResponse
from services import customer_service, quotation_service

router = APIRouter(prefix="/api/portal", tags=["portal"])

# Everything in this router is customer-only, on purpose - this is the
# "genuinely separate, restricted view" the brief requires, not the
# internal endpoints with a different label. A rep/manager/finance/admin
# token gets a 403 from every route here, just as a customer token gets a
# 403 from every /api/quotations/* route.
_customer_only = require_role(Role.CUSTOMER)

_KNOWN_ERRORS = (
    customer_service.NoLinkedCustomerAccount,
    quotation_service.QuotationNotFound,
    quotation_service.PermissionDenied,
    quotation_service.LineNotFound,
    quotation_service.InvalidTransition,
)

_STATUS_BY_ERROR = {
    customer_service.NoLinkedCustomerAccount: 404,
    quotation_service.QuotationNotFound: 404,
    quotation_service.PermissionDenied: 403,
    quotation_service.LineNotFound: 404,
    quotation_service.InvalidTransition: 409,
}


def _as_http_error(exc: Exception) -> HTTPException:
    status_code = _STATUS_BY_ERROR[type(exc)]
    return HTTPException(status_code=status_code, detail=str(exc))


@router.get("/quotations", response_model=list[QuotationResponse])
def list_my_quotations(session: Session = Depends(get_session), user: User = Depends(_customer_only)):
    try:
        customer = customer_service.get_customer_by_portal_user(session, user.id)
    except _KNOWN_ERRORS as exc:
        raise _as_http_error(exc) from exc
    quotations = quotation_service.list_quotations_for_customer(session, customer.id)
    return [quotation_service.get_quotation_view(session, q.id) for q in quotations]


@router.get("/quotations/{quotation_id}", response_model=QuotationResponse)
def get_my_quotation(
    quotation_id: int, session: Session = Depends(get_session), user: User = Depends(_customer_only)
):
    try:
        return quotation_service.get_quotation_for_customer(session, quotation_id, user.id)
    except _KNOWN_ERRORS as exc:
        raise _as_http_error(exc) from exc


@router.post("/quotations/{quotation_id}/counter", response_model=QuotationResponse)
def counter_offer(
    quotation_id: int,
    payload: CounterOfferRequest,
    session: Session = Depends(get_session),
    user: User = Depends(_customer_only),
):
    """The WOW moment: a customer proposes a different discount, and the
    exact same Blended Discount Risk Engine that scores a rep's edits
    re-scores this one, live - if it now needs approval, the quotation
    silently re-enters the approval queue with zero rep action.
    """
    try:
        quotation_service.customer_counter_offer(
            session,
            quotation_id=quotation_id,
            portal_user_id=user.id,
            line_id=payload.line_id,
            new_discount_pct=payload.discount_pct,
            note=payload.note,
        )
        return quotation_service.get_quotation_for_customer(session, quotation_id, user.id)
    except _KNOWN_ERRORS as exc:
        raise _as_http_error(exc) from exc


@router.post("/quotations/{quotation_id}/confirm", response_model=QuotationResponse)
def confirm(quotation_id: int, session: Session = Depends(get_session), user: User = Depends(_customer_only)):
    try:
        quotation_service.customer_confirm(session, quotation_id=quotation_id, portal_user_id=user.id)
        return quotation_service.get_quotation_for_customer(session, quotation_id, user.id)
    except _KNOWN_ERRORS as exc:
        raise _as_http_error(exc) from exc
