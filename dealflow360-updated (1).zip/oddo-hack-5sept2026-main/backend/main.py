from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routers.auth import router as auth_router
from routers.catalog import router as catalog_router
from routers.customers import router as customers_router
from routers.deal_health import router as deal_health_router
from routers.governance import router as governance_router
from routers.portal import router as portal_router
from routers.quotations import router as quotations_router
from routers.users import router as users_router
from routers.warehouses import router as warehouses_router

app = FastAPI(title="DealFlow360 API")

# Dev-permissive CORS so the plain static frontend (opened via file:// or a
# simple static server on any port) can call this API. Tighten this once a
# real frontend origin/deployment exists.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(users_router)
app.include_router(catalog_router)
app.include_router(governance_router)
app.include_router(customers_router)
app.include_router(quotations_router)
app.include_router(portal_router)
app.include_router(deal_health_router)
app.include_router(warehouses_router)
