# Backend API Guide

**This is a living doc — Jivraj updates it as the backend changes.** If you're building `frontend/internal-app` or `frontend/customer-website`, this is everything you need to call the backend without reading its source.

## Current server URL

```
https://census-posing-coordinated-kernel.trycloudflare.com
```

⚠️ **This URL is NOT permanent.** It's a Cloudflare quick tunnel running on Jivraj's machine — it changes every time the tunnel or his machine restarts. **Check this section is current before assuming the URL works; ping Jivraj if requests start failing with connection errors** (as opposed to 401/403/404, which are the API correctly rejecting something — that means the URL is fine, see the reference below).

*Last updated: 2026-09-05*

## What's done so far

**Module 1 - Authentication.** One unified set of endpoints for everyone (`/api/auth/*`) - no separate internal/customer login. JWT-based (stateless), every signup creates a `customer` account, an admin promotes afterward via `PATCH /api/users/{id}/role`. Logout revokes a specific token immediately.

**Module 2 - Governance & Quotation Engine.** The actual product core:
- `/api/catalog/*` - product categories and products (admin writes, anyone authenticated can read - reps need the catalog to build quotes).
- `/api/governance/*` - discount tiers and the tier-x-category ceilings the risk engine reads (admin-only writes).
- `/api/customers` - buying accounts, each on a discount tier (rep or admin can create).
- `/api/quotations/*` - the whole quote-build-to-approval loop: add/edit/remove lines with a live-recomputed **Blended Discount Risk Score** after every mutation, auto-routing to Manager and (if still needed after Manager approves) Finance, and a full audit trail. See `services/risk_engine.py` for the actual scoring formula and `services/quotation_service.py` for the state machine.

**Module 2.5 - Customer Negotiation Portal.** `/api/portal/*` - customer-only endpoints (403 for every staff role), completely separate from `/api/quotations/*`. A customer counters a line's discount from their own portal and the SAME risk engine re-scores it live - if it now breaches thresholds, the quotation silently re-enters Manager approval with zero rep action. See `services/quotation_service.py`'s `customer_counter_offer`.

**Module 3 - Deal Health, Cross-Sell, Warehouse Split (new).**
- `/api/deal-health/anomalies` - rep-relative z-score discount anomaly detection: flags a deal whose average discount is unusual **for that specific rep's own history**, not against a fixed threshold. `/api/deal-health/stalled` - active quotations untouched for 5+ days. See `services/deal_health.py`.
- `/api/quotations/{id}/cross-sell` - margin-gated market-basket suggestions, ranked by lift, mined from real confirmed-order history (no hand-picked list, no trained model). See `services/upsell_engine.py`.
- `/api/warehouses/*` - admin warehouse/stock setup. `/api/quotations/{id}/split` and `/split/accept` - a greedy, shipment-minimizing allocation across warehouses (cheapest first), with backorder handling. Explicitly a transparent heuristic, not a claim of global optimality. See `services/warehouse_split.py`.

Not yet built: hybrid billing/subscriptions and delivery-promise slippage indicators. Those are later modules, not silently dropped scope.

Full architecture/reasoning lives in `/ARCHITECTURE.md`.

## Auth basics

- All requests/responses are JSON. Set `Content-Type: application/json` on POST bodies.
- After login/signup, you get a `token`. Send it on every subsequent request as:
  ```
  Authorization: Bearer <token>
  ```
- Tokens expire after 24 hours. There's no refresh endpoint yet — expired tokens just need a fresh login.
- Roles: `rep`, `manager`, `finance`, `admin`, `customer`. All five live in the same `User` table - there's no separate "customer" model.

## Auth endpoints (used by both `frontend/internal-app` and `frontend/customer-website`)

### `POST /api/auth/signup`

Request:
```json
{ "name": "Rita Rep", "email": "rita@example.com", "password": "hunter2" }
```
No `role` field - every signup always creates a `customer` account, immediately usable, regardless of which frontend called it.

Response `201`:
```json
{
  "token": "eyJhbG...",
  "user": { "id": 1, "name": "Rita Rep", "email": "rita@example.com", "role": "customer" }
}
```

**Important:** signing up does NOT grant internal/staff access by itself. Every new account starts as `customer` - an admin has to promote it (see `PATCH /api/users/{id}/role` below) before it can do anything staff-only. If `frontend/internal-app` uses this same signup for "request staff access," frame it to the user as a request, not "sign up and start working" - there's a real waiting step.

Errors: `409` if the email is already registered.

### `POST /api/auth/login`

Request:
```json
{ "email": "rita@example.com", "password": "hunter2" }
```

Response `200`: same shape as signup's response, `role` reflects whatever the account's current role actually is.

Errors: `401` — wrong email/password. That's the only failure case - login itself never rejects based on role; it always succeeds for correct credentials regardless of what role the account has.

### `GET /api/auth/me`

Header: `Authorization: Bearer <token>`

Response `200`:
```json
{ "id": 1, "name": "Rita Rep", "email": "rita@example.com", "role": "rep" }
```

Errors: `401` if the token is missing/invalid/expired/revoked/for a deleted user.

Use this on app launch to restore a session from a stored token — if it 401s, clear the stored token and send the user back to login.

### `POST /api/auth/logout`

Header: `Authorization: Bearer <token>`. No body.

Response `204` (no content). Revokes only the token used to call this - other tokens for the same user (e.g. logged in on a second device) are unaffected. Any further request with the logged-out token gets `401` ("Token has been revoked").

Errors: `401` if the token is missing/invalid/expired/already-revoked.

## User management endpoints — **admin only**

### `GET /api/users`

Header: `Authorization: Bearer <admin token>`

Response `200`: array of every user, any role - this is how an admin finds who to promote (there's no separate "pending" concept; a not-yet-promoted account is indistinguishable from a "real" customer at the data level - both are just `role: "customer"`).

Errors: `403` if the caller isn't an admin.

### `PATCH /api/users/{user_id}/role`

Header: `Authorization: Bearer <admin token>`. Body: `{ "role": "rep" }` (any of `rep`/`manager`/`finance`/`admin`/`customer` - this is also how you'd demote someone back to customer).

Response `200`: the updated user object.

Errors: `403` if the caller isn't an admin. `404` if `user_id` doesn't exist.

## Demo accounts (seeded, work on the tunnel right now)

| Email | Password | Role |
|---|---|---|
| `rep@dealflow.test` | `rep123` | rep |
| `manager@dealflow.test` | `manager123` | manager |
| `finance@dealflow.test` | `finance123` | finance |
| `admin@dealflow.test` | `admin123` | admin |
| `customer@dealflow.test` | `customer123` | customer |

These were seeded directly with their real role (bypassing the normal customer-signup-then-admin-promotes flow) - that's the only bootstrap path for an admin account to exist at all, since nobody can self-provision a privileged role via the API. Use `admin@dealflow.test` to test the list-users/change-role flow against any new signup you create.

## Catalog endpoints (`/api/catalog/*`)

Roles: category/product creation is **admin-only**. Any authenticated role can list.

### `POST /api/catalog/categories` (admin only)
```json
{ "name": "Hardware" }
```
`201` -> `{ "id": 1, "name": "Hardware" }`. `409` if the name already exists.

### `GET /api/catalog/categories`
`200` -> array of `{ id, name }`.

### `POST /api/catalog/products` (admin only)
```json
{ "name": "EliteBook Pro G10", "category_id": 1, "unit_cost": 800, "list_price": 1200, "is_subscription": false }
```
`201` -> the created product. `404` if `category_id` doesn't exist.

### `GET /api/catalog/products`
`200` -> array of products.

## Governance endpoints (`/api/governance/*`)

This is the data the **Blended Discount Risk Engine** reads - see `backend/services/risk_engine.py` for the actual formula. Writes are admin-only.

### `POST /api/governance/tiers` (admin only)
```json
{ "name": "Gold", "overall_ceiling_pct": 15.0 }
```
`201` -> the created tier. `overall_ceiling_pct` is display/reference only - the engine never checks a line against it directly, only against the tier+category-specific ceiling below.

### `GET /api/governance/tiers`
`200` -> array of tiers.

### `PUT /api/governance/ceilings` (admin only)
The actual per-tier-per-category rule. **PUT, not POST** - calling this again for the same `(tier_id, category_id)` pair updates the existing rule rather than erroring, since changing a ceiling is the normal operation.
```json
{ "tier_id": 3, "category_id": 2, "max_discount_pct": 10.0, "margin_weight": 1.5 }
```
`margin_weight` scales how heavily an overage in this category counts toward the *cumulative* score - thinner-margin categories (Services) should weigh more than healthy-margin ones (Hardware). `200` -> the ceiling row. `404` if `tier_id` or `category_id` doesn't exist.

### `GET /api/governance/ceilings?tier_id=<optional>`
`200` -> array of ceilings, optionally filtered to one tier.

## Customer endpoints (`/api/customers`)

Rep or admin can create (a rep needs to add a brand-new buying account while building a quote). Any authenticated role can read.

### `POST /api/customers` (rep or admin)
```json
{ "name": "Acme Corporation", "tier_id": 3 }
```
`201` -> `{ "id": 1, "name": "Acme Corporation", "tier_id": 3, "tier_name": "Gold" }`. `404` if `tier_id` doesn't exist.

### `GET /api/customers` / `GET /api/customers/{id}`
Same shape as above.

## Quotation endpoints (`/api/quotations/*`) - the core loop

Every response is a `QuotationResponse`: the quote plus every line, each carrying its **live risk breakdown** (`overage_pts`, `ceiling_pct`, `risk_contribution`, `hard_flag`), plus the order-level `blended_risk_score`, `hard_flag`, and `routing` (`"none" | "manager" | "manager_finance"`). This is recomputed **fresh on every single call that touches the quote** - never cached, never trusted from an earlier response.

### `POST /api/quotations` (rep or admin)
```json
{ "customer_id": 1 }
```
`201` -> a new quotation in `draft` status, created by the calling user (`rep_id` is taken from the token, not the request body).

### `GET /api/quotations/{id}`
Full current state, freshly scored.

### `GET /api/quotations?mine=true` / `?pending_manager=true` / `?pending_finance=true`
Three views behind one endpoint:
- `mine=true` - the calling rep's own quotations.
- `pending_manager` / `pending_finance` - that approver's queue (quotations with a currently-pending `ApprovalStep` at that level - not just a status guess).
- no flag - everything (admin/reporting view).

### `POST /api/quotations/{id}/lines` (rep or admin)
```json
{ "product_id": 3, "quantity": 1, "discount_pct": 18.0 }
```
`201` -> the whole quotation, recomputed. `409` if the quotation isn't in `draft` (you can't edit a quote that's mid-approval - return it first).

### `PATCH /api/quotations/{id}/lines/{line_id}`
```json
{ "discount_pct": 10.0 }
```
Either field optional. Same recompute-and-return behavior.

### `DELETE /api/quotations/{id}/lines/{line_id}`
Removes the line, recomputes, returns the quotation.

### `POST /api/quotations/{id}/submit` (rep or admin)
No body. Recomputes one final time and routes based on what the engine says **right now**:
- `routing: "none"` -> status jumps straight to `confirmed`. No `ApprovalStep` is ever created - the absence of any approval row *is* the "didn't need approval" signal.
- otherwise -> status becomes `pending_manager` and a Manager `ApprovalStep` is created. Whether Finance is *also* needed is decided later, at the moment Manager actually approves - not decided here and trusted.

### `POST /api/quotations/{id}/approvals/{level}` (level = `manager` or `finance`)
```json
{ "decision": "approved", "reason": "optional text" }
```
`decision` is one of `approved` / `rejected` / `returned`. Role-checked against `level` - a Manager token can only act on a `manager` step (`403` otherwise); same for Finance. Admin can act at either level, for testing.
- `approved` at `manager`: the engine is **re-asked** right now; if it still says Finance is needed, a Finance `ApprovalStep` is created and status becomes `pending_finance`. Otherwise status becomes `confirmed` immediately - Manager-only approval doesn't wait around for a Finance step that was never going to exist.
- `approved` at `finance`: status becomes `confirmed`.
- `rejected`: status becomes `rejected`, terminal.
- `returned`: status goes back to `draft` - the rep can edit lines again and resubmit.

`409` if there's no pending step at that level for this quotation (e.g. Finance hasn't been reached yet, or the quote was already decided).

### `GET /api/quotations/{id}/approvals`
Every `ApprovalStep` for the quote, in order - `[{ level, status, actor_id, reason, created_at, acted_at }, ...]`.

### `GET /api/quotations/{id}/audit-log`
Full append-only history - `quotation_created`, `line_added`, `line_updated`, `line_removed`, `routed_for_approval`, `approved`, `approved_final`, `rejected`, `returned_for_revision`, `auto_confirmed` - each with `user_id`, `details`, `created_at`.

## Seed data for local development

`python manage.py reset` now seeds a full demo scenario, not just users: 3 categories (Hardware/Services/Software), 3 tiers (Bronze/Silver/Gold) each with their own per-category ceilings, 5 products, and 3 customers (Acme Corporation and Globex Corp on Gold, Initech Ltd on Bronze). This reproduces the problem statement's own worked example immediately: log in as `rep@dealflow.test`, quote Acme Corporation a Laptop at 12% (fine) and Setup Service at 18% (hard-flags to Manager+Finance).

## Known gaps (don't build around these as if they're permanent)

- No password reset / forgot-password flow yet.
- Logout revokes one token, not "all sessions for this user" - there's no "log out everywhere" endpoint.
- No way to tell "pending promotion" apart from "genuinely a customer" from the API alone - both just look like a `customer`-role account.
- Tunnel URL is ephemeral (see top of this doc).
- No rate-limiting on login/signup.
