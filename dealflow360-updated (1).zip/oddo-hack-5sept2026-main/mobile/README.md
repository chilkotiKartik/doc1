# Mobile

Expo (React Native) app for DealFlow360, targeting the Rep Workspace and Approver Console on the go (quote review, approvals, deal-health alerts).

See `/doc` at repo root for the full PRD and architecture.
